/**********************************************************************************************
	* @Author: Monali Nagpure
	* @Date: 03/09/2020        
    * @Description: JS file for Add Member quick action 
	* @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
***********************************************************************************************/
({
    /**
    * Method Name : init
    * Parameters  : None
    * Description : Load columns values of datatable 
    * Created By  : Monali Nagpure
    * Created On  : 07/09/2020
    **/
    init: function (Component, event, helper) {
        console.log('Get Record ID:-',Component.get('v.sObjectName'));
        if(Component.get('v.objectName') && Component.get('v.objectName') == 'ContractMemberChangeRequest'){
            Component.set('v.isContractManangChangeObjcet',true);
        }else{
            Component.set('v.isContractManangChangeObjcet',false);
        }
        Component.set('v.mycolumns', [
            { label: 'Account Name', fieldName: 'name', type: 'text' },
            { label: 'Postcode', fieldName: 'postcode', type: 'text' },
            { label: 'Email', fieldName: 'personEmail', type: 'email' },
            { label: 'Phone', fieldName: 'phone', type: 'phone' },
            { label: 'Mobile', fieldName: 'personMobilePhone', type: 'text' },
        ]);
    },

    /**
    * Method Name : getSelectedPDRContacts
    * Parameters  : None
    * Description : Get selected member from datatable to relate it to current opportunity
    * Created By  : Monali Nagpure
    * Created On  : 07/09/2020
    **/
    getSelectedPDRContacts: function (component, event) {
        var selectedRows = event.getParam('selectedRows');
        component.set('v.selectedPDRContacts', selectedRows[0].id);
    },

    /**
    * Method Name : relateMember
    * Parameters  : None
    * Description : relate selected member to current opportunity
    * Created By  : Monali Nagpure
    * Created On  : 07/09/2020
    **/
    relateMember: function (component, event, helper) {
        let selectedPDRContacts = component.get('v.selectedPDRContacts');
        if (selectedPDRContacts) {
            helper.relateMember(component, event, helper);
        }
        else {
            helper.showToast('Error', 'Please select member', 'error');
        }
    },

    /**
    * Method Name : searchRecords
    * Parameters  : None
    * Description : To search duplicate records based on parameters provided in search form
    * Created By  : Monali Nagpure
    * Created On  : 03/09/2020
    **/
    searchRecords: function (component, event, helper) {
        
        var params = {
            firstName: component.get('v.firstName'),
            lastName: component.get('v.lastName'),
            email: component.get('v.email'),
            postcode: component.get('v.postcode'),
            phone: component.get('v.phone'),
            mobile: component.get('v.mobile')
        };
        component.set('v.params', JSON.stringify(params));
        component.set('v.title', 'Member Results');
        
        console.log('objectName::>>', component.get('v.objectName'));
        //$A.get('e.force:closeQuickAction').fire();

        // Hide Search form
        component.set('v.divHeight', '5');
        var ComponentTarget = component.find('memberSearchHideUnhide');
        $A.util.removeClass(ComponentTarget, 'slds-visible');
        $A.util.addClass(ComponentTarget, 'slds-hidden');
        // var cardButton = component.find('cardButton');
        // cardButton.set('v.iconName', 'utility:up');
        
        
        component.set('v.showSpinner', true);
        helper.getPDRContactsData(component);
        
    },

    /**
    * Method Name : hideUnhideSearch
    * Parameters  : None
    * Description : To hide/unhide search form
    * Created By  : Monali Nagpure
    * Created On  : 03/09/2020
    **/
    hideUnhideSearch: function (component, event, helper) {
        helper.hideUnhideSearch(component,event,helper);
    },

    /**
    * Method Name : searchRecords
    * Parameters  : None
    * Description : Hide member search
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    hideMemberSearch: function (component, event, helper) {
        component.set('v.params', '');
        component.set('v.selectedPDRContacts','');
        helper.hideUnhideSearch(component, event, helper);
    },

    /**
    * Method Name : closeAddMemberQuickAction
    * Parameters  : None
    * Description : To close Add member quick action
    * Created By  : Monali Nagpure
    * Created On  : 03/09/2020
    **/
    closeAddMemberQuickAction: function (component, event, helper) {
        $A.get('e.force:closeQuickAction').fire();
    },

    /**
    * Method Name : checkSearchButton
    * Parameters  : None
    * Description : To enable/disbale search button
    * Created By  : Monali Nagpure
    * Created On  : 03/09/2020
    **/
    checkSearchButton: function (component, event, helper) {
        helper.searchButton(component, event, helper);
    },

    /**
    * Method Name : handlesaveAndNewClicked
    * Parameters  : None
    * Description : Event handler method to handle "Save And New" button from child component
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    handlesaveAndNewClicked: function (component, event, helper) {

        var buttonClicked = event.getParam('saveAndNewClicked');
        
        if (buttonClicked) {
            component.set('v.isOpen', false);
            component.set('v.isModalOpen', false);
            component.set('v.isModalClose', true);
        }
        
        component.set('v.params', '');
        component.set('v.pDRContactsCounts', 0);
        component.set('v.firstName','');
        component.set('v.lastName','');
        component.set('v.email','');
        component.set('v.postcode','');
        component.set('v.phone','');
        component.set('v.mobile','');
        helper.searchButton(component, event, helper);
        helper.hideUnhideSearch(component, event, helper);
    }

});