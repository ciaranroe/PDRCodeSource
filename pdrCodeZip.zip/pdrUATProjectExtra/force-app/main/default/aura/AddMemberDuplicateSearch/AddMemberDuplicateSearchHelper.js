/**********************************************************************************************
	* @Author: Monali Nagpure
	* @Date: 03/07/2020        
  * @Description: JS helper file for Add Member quick action 
	* @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
***********************************************************************************************/
({
  /**
  * Method Name : searchButton
  * Parameters  : None
  * Description : To enable/disbale search button based on user inputs 
  * Created By  : Monali Nagpure
  * Created On  : 03/09/2020
  **/
  searchButton: function (component, event, helper) {
    let lastName = component.get('v.lastName');
    let email = component.get('v.email');
    let postcode = component.get('v.postcode');
    let phone = component.get('v.phone');
    let mobile = component.get('v.mobile');
    var validity = component.find("email").get("v.validity");

    if (lastName && (email || phone || mobile || email || postcode) && (validity.valid)) {
      component.set('v.isSearchButtonActive', false);
    }
    else {
      component.set('v.isSearchButtonActive', true);
    }
  },

  /**
  * Method Name : getPDRContactsData
  * Parameters  : None
  * Description : To load data into datatable from backend 
  * Created By  : Monali Nagpure
  * Created On  : 03/09/2020
  **/
  getPDRContactsData: function (component) {
    let firstName = component.get('v.firstName');
    let lastName = component.get('v.lastName');
    let email = component.get('v.email');
    let postcode = component.get('v.postcode');
    let phone = component.get('v.phone');
    let mobile = component.get('v.mobile');
    var action = component.get('c.getAccounts');
    action.setParams({ firstName: firstName, lastName: lastName, email: email, postcode: postcode, phone: phone, mobile: mobile });
    action.setCallback(this, $A.getCallback(function (response) {
      var state = response.getState();
        if (state === 'SUCCESS') {
            component.set('v.mydata', response.getReturnValue());
            if (response.getReturnValue().length > 0) {
                component.set('v.pDRContactsCounts', response.getReturnValue().length);
            }
            else {
                var cmcrObjcet = component.get('v.isContractManangChangeObjcet'); 
                if(cmcrObjcet){ 
                    //isModalOpen
                    component.set('v.isModalOpen', false);
                    $A.get('e.force:closeQuickAction').fire();
                }else{
                    component.set('v.isModalOpen', true);
                    component.set('v.isModalClose', false);
                } 
            }

        component.set('v.showSpinner', false);
      } else if (state === 'ERROR') {
        this.showToast('Error', 'Somthing went wrong', 'error');
        component.set('v.showSpinner', false);
      }
    }));
    $A.enqueueAction(action);
  },

  /**
  * Method Name : relateMember
  * Parameters  : None
  * Description : To relate selected member to current the current opportunity
  * 			  Rohini - Added Spinner for relate member
  * Created By  : Monali Nagpure
  * Created On  : 08/09/2020
  **/
  relateMember: function (component, event, helper) {
    component.set('v.showSpinner', true);
    let opportunityId = component.get('v.recordId');
    let selectedPDRContacts = component.get('v.selectedPDRContacts');
    var action = component.get('c.relateMembersToOpportunity');
    action.setParams({ selectedPDRContacts: selectedPDRContacts, oppId: opportunityId });
    action.setCallback(this, $A.getCallback(function (response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var status = response.getReturnValue();
        if (status == 'inserted') {
          this.showToast('Success', 'Selected member is added to the current Opportunity', 'success');
          component.set('v.params', '');
          component.set('v.pDRContactsCounts', 0);
          component.set('v.firstName','');
          component.set('v.lastName','');
          component.set('v.email','');
          component.set('v.postcode','');
          component.set('v.phone','');
          component.set('v.mobile','');
          component.set('v.selectedPDRContacts','');
          this.hideUnhideSearch(component, event, helper);
          component.set('v.showSpinner', false);
          $A.get('e.force:refreshView').fire();
        }
        else if (status == 'exists') {
          this.showToast('Error', 'Selected member already exists under the current Opportunity', 'error');
          component.set('v.showSpinner', false);
        }
        else {
          this.showToast('Error', status , 'error');
		  component.set('v.showSpinner', false);
        }
      } else if (state === 'ERROR') {
        this.showToast('Error', 'Somthing went wrong', 'error');
		component.set('v.showSpinner', false);
      }
    }));
    $A.enqueueAction(action);
  },

  /**
  * Method Name : showToast
  * Parameters  : None
  * Description : To show toast msg
  * Created By  : Monali Nagpure
  * Created On  : 07/09/2020
  **/
  showToast: function (title, message, type) {
    var toastEvent = $A.get('e.force:showToast');
    toastEvent.setParams({
      title: title,
      message: message,
      duration: ' 5000',
      key: 'info_alt',
      type: type,
      mode: 'dismissible'
    });
    toastEvent.fire();
  },

  /**
  * Method Name : hideUnhideSearch
  * Parameters  : None
  * Description : To hide/unhide search form
  * Created By  : Monali Nagpure
  * Created On  : 03/09/2020
  **/
   hideUnhideSearch: function (component, event, helper) {
    var currentButton = component.find('cardButton');
    var iconName = currentButton.get('v.iconName');

    if (iconName == 'utility:up') {
        currentButton.set('v.iconName', 'utility:down');
        component.set('v.divHeight', '400');
        var ComponentTarget = component.find('memberSearchHideUnhide');
        $A.util.removeClass(ComponentTarget, 'slds-hidden');
        $A.util.addClass(ComponentTarget, 'slds-visible');
    }
    else {
        currentButton.set('v.iconName', 'utility:up');
        component.set('v.divHeight', '5');
        var ComponentTarget = component.find('memberSearchHideUnhide');
        $A.util.removeClass(ComponentTarget, 'slds-visible');
        $A.util.addClass(ComponentTarget, 'slds-hidden');
    }
  },
});