({
    
  // helper function to run an apex method
  // callback returns callback(err, res)
  runApex: function($C, method, params, callback) {
    var action = $C.get("c." + method);
    action.setParams(params);
    console.log("Running RelatedRecordsController." + method + "() method with the following parameters: ", params);
    action.setCallback(this, function(response) {

      console.log("c." + method,response.getState(), response.getReturnValue() );

      var status = response.getState();
      if (status === "SUCCESS") {
        return callback(null, response.getReturnValue());
      } else {
        console.error(response);
        return callback(response.getError(), null);
      }
    })
    $A.enqueueAction(action);
  }
    
})