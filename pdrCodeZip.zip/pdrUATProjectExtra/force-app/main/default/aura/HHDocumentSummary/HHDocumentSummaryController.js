({
    
  // get document list
  doInit : function($C, $E, $H) {
      
    $C.set("v.documentData", "");
    $C.set("v.documentType", "");
      
    var accountId = window.location.search.split('?accountId=')[1];
    $H.runApex($C, "getDocumentList", { accountId: accountId }, function(err, res) {
      if (err) return console.error(err);

      if (res.Documents && res.Documents.length){
        res.Documents.forEach(function(doc){
          if (doc.ContentDocumentLinks && doc.ContentDocumentLinks.length){
            doc.ContentDocumentId = doc.ContentDocumentLinks[0].ContentDocumentId;
          }
        });
      }
      $C.set("v.documentsList", res.Documents);
      $C.set("v.filesList", res.Files);
      console.log(res);
    })
  },
    
  // set document type from picklist
  setDocumentType: function($C, $E, $H) {
    var type = $C.find("documentTypeSelect").get("v.value");
    $C.set("v.documentType", type);
  },
    
  // get document data from file input
  setDocumentData: function($C, $E, $H) {
    var files = $E.currentTarget.files;
    if (files && files.length > 0) {
      var file = files[0];
	  console.log(file);
      $C.set("v.documentContentType", file.type);
      $C.set("v.fileName", file.name);
      var reader = new FileReader();
      reader.onloadend = function() {
        var dataURL = reader.result;
        var content = dataURL.match(/,(.*)$/)[1];
        $C.set("v.documentData", content);
      }
      reader.readAsDataURL(file);
    }
  },
    
  // toggle upload popup
  openPopup: function($C, $E, $H) {
    $C.set("v.popupOpen", true);
  },
  closePopup: function($C, $E, $H) {
    $C.set("v.popupOpen", false);
  },
    
  // open already uploaded document
  viewDocument: function($C, $E, $H) {
    
      
    $H.runApex($C, "getDocumentURL", { documentId: $E.currentTarget.getAttribute("data-id") }, function(err, res) {
      if (err) console.error(err);
      console.log(res);
      var url = '/s/contentdocument/' + res; // preview
      
      window.open(url);   
    })
      
  },
    
  // upload the document we have
  uploadDocument: function($C, $E, $H) {
    var data = {
      accountId: window.location.search.split('?accountId=')[1],
      documentType: $C.get("v.documentType"),
      base64: $C.get("v.documentData"),
      contentType: $C.get("v.documentContentType"),
      filename: $C.get("v.fileName")
    }
    $C.set("v.loading", true);
    console.log("Uploading", data);
    $H.runApex($C, "uploadDocumentRecord", data, function(err, res) {
      if (err) console.error(err);
      console.log("Uploaded!", res);
      // reset
      $C.set("v.documentData", "");
      $C.set("v.documentType", "");
      $C.set("v.documentContentType", "");
      $C.set("v.fileName", "");
      // refresh list
      setTimeout(function() { window.location.reload(); }, 1000);
    })
  }
    
})