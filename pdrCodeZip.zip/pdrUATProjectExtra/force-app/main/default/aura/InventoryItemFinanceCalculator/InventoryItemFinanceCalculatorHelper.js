({
    
    getInvItemDetails: function($C, $E, $H) { 
        
        var recordId = $C.get('v.recordId');
        var action = $C.get('c.getInventoryItem');
        
        action.setParams({"recordId": recordId});
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                console.log('response state of getInvItemDetails ', state);
                console.log('response of getInvItemDetails ', response.getReturnValue());
                
                var invItem = response.getReturnValue();
                
                if(invItem != null & invItem != 'undefined') {
                    
                    console.log('invItem.Available_for_Finance__c : ', invItem.Available_for_Finance__c);
                    
                    if(invItem.Available_for_Finance__c === false) {
                        $C.set("v.unavailable", true);
                    }
                    
                    else {
                        $C.set("v.unavailable", false); 
                        
                        $C.set("v.inventoryItem", invItem);
                        $C.set("v.inventoryItemId", invItem.Id);
                        $C.set("v.totalPackagePrice", invItem.Total_Sales_Price__c);
                        $C.set("v.modelYearValue", invItem.Model_Year__c ); 
                        //$C.set("v.minimumDeposit", (invItem.Total_Sales_Price__c * (invItem.Minimum_Deposit__c / 100)));
                        
                        if(invItem.Type__c == 'Caravan' || invItem.Type__c == 'Lodge') {
                            $C.set("v.selectedTypeOption", invItem.Type__c);
                        }
                        
                        if(invItem.Location__r.Preferred_Finance_Provider__c != null && 
                           invItem.Location__r.Preferred_Finance_Provider__c != 'undefined') {
                            $C.set("v.financeProviderId", invItem.Location__r.Preferred_Finance_Provider__c);
                            console.log('Finance Prov = ', invItem.Location__r.Preferred_Finance_Provider__c);
                        }
                        
                        // Get Finance Calculator rules
                        this.getFinanceCalcRules($C, invItem);
                    } // End of Else
                } 
            }
        });
        
        $A.enqueueAction(action);
    },
    
    getFinanceCalcRules: function($C, inventryItem) { 
        
        var action = $C.get('c.getFinanceCalculatorRules');        
        action.setParams({
            "financeProvId":  $C.get('v.financeProviderId'),
            "parkId": inventryItem.Location__c,
            "invntryType":  inventryItem.Type__c,
            "modelYear": inventryItem.Model_Year__c                       
        }); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();
                console.log('resultMap of getFinanceCalcRules is: ', resultMap);
                console.log('maxIvntryItemAge is: ', resultMap.InvntryItemAgeMax);
                console.log('minIvntryItemAge is: ', resultMap.InvntryItemAgeMin);
                console.log('maximumLengthofTerm is: ', resultMap.MaxTermMonths);
                
                if(resultMap.MaxTermMonths != null && resultMap.MaxTermMonths != 'undefined' &&
                   resultMap.InvntryItemAgeMax != null && resultMap.InvntryItemAgeMax != 'undefined' &&
                   resultMap.InvntryItemAgeMin != null && resultMap.InvntryItemAgeMin != 'undefined') {
                    $C.set("v.maximumLengthofTerm", resultMap.MaxTermMonths);
                    $C.set("v.maxIvntryItemAge", resultMap.InvntryItemAgeMax);
                    $C.set("v.minIvntryItemAge", resultMap.InvntryItemAgeMin);
                    this.prepopulateValues($C);
                }
                else{
                    alert('Finance Calculator Rules are not configured for the selected Finance Provider and Park. Please contact your administrator.');
                    $C.set("v.maximumLengthofTerm", 84);
                    $C.set("v.maxIvntryItemAge", 2020);
                    $C.set("v.minIvntryItemAge", 2006);
                    this.prepopulateValueswithoutFP($C);
                } 
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    prepopulateValueswithoutFP: function($C) {
        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositThreshold = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var interestRateVar = $C.get('v.interestRate');
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var paymentMonths = $C.get('v.selectedTermMonth');
        
        var initDepCalculated = minDepositThreshold;
        
        var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100));
        
        if(minDepositCalculated > minDepositThreshold) {
            
            initDepCalculated = minDepositCalculated ;
        }
        
        //$C.set("v.minimumDeposit", minDepositThreshold);
        //$C.set("v.totalDeposit", initDepCalculated);
        $C.set("v.minimumDeposit", minDepositCalculated);
        $C.set("v.totalDeposit", minDepositCalculated); 
        
        console.log('calculated initial deposit is : ', initDepCalculated);
        
        var balToFinance = totalpackageprice - initDepCalculated  ;
        console.log('balancetoFinance : ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        this.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,paymentMonths);
    },
    
    prepopulateValues: function($C) {
        
        var inventryItem = $C.get('v.inventoryItem');
        var action = $C.get('c.getValuesfromFP');
        
        action.setParams({"financeProviderId": $C.get('v.financeProviderId')}); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            console.log('response of prepopulateValues ', response.getReturnValue());
            
            var paymentYear;
            var maxPaymentYear;
            
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();
                var paymentMonths = $C.get('v.maximumLengthofTerm');
                var totalpackageprice =  $C.get('v.totalPackagePrice');
                var minDepositThreshold = $C.get('v.minimumDeposit');
                var optPurchaseFee = Number(resultMap.Option_to_Purchase_Fee__c); 
                var initDepCalculated = minDepositThreshold;
                
                console.log('value of interest rate is : ', resultMap.Interest_Rate__c);
                console.log('value of minimumDeposit % is : ', resultMap.Minimum_Deposit__c);
                console.log('value of maximumLengthofTerm in months is : ', paymentMonths);
                console.log('minDepositThreshold on UI is : ', minDepositThreshold);
                
                if(resultMap.Minimum_Deposit__c !== null) {
                    
                    var minDepPercent = resultMap.Minimum_Deposit__c ;
                    
                    console.log('totalPackagePrice on UI is : ', totalpackageprice);
                    
                    var minDepositCalculated = (totalpackageprice * (minDepPercent / 100));
                    
                    if(minDepositCalculated > minDepositThreshold) {
                        
                        initDepCalculated = minDepositCalculated ;
                    }
                    
                    //$C.set("v.minimumDeposit", minDepositThreshold);
                    //$C.set("v.totalDeposit", initDepCalculated);
                    $C.set("v.minimumDeposit", minDepositCalculated);
                    $C.set("v.totalDeposit", minDepositCalculated); 
                    
                    console.log('calculated initial deposit is : ', initDepCalculated);
                }
                
                else {
                    $C.set("v.minimumDeposit", initDepCalculated); 
                    $C.set("v.totalDeposit", initDepCalculated);
                } 
                
                var balToFinance = totalpackageprice - initDepCalculated  ;
                console.log('balancetoFinance : ', balToFinance) ;
                $C.set("v.balancetoFinance", balToFinance.toFixed(2));
                
                
                $C.set("v.minimumDepositPercent", resultMap.Minimum_Deposit__c);
                $C.set("v.OptiontoPurchaseFee", optPurchaseFee);
                $C.set("v.interestRate", resultMap.Interest_Rate__c);
                $C.set("v.representativeAPR", resultMap.APR__c);
                
                if(paymentMonths == null || paymentMonths === null || paymentMonths === 'undefined') {
                    paymentMonths = 84;
                    $C.set("v.selectedTermMonth", 84);    
                    $C.set("v.maximumLengthofTerm", 84);
                }
                else { 
                    $C.set("v.maximumLengthofTerm", (paymentMonths));
                    $C.set("v.selectedTermMonth", (paymentMonths)); 
                }
                
                this.paymentCalculation($C,balToFinance,resultMap.APR__c,optPurchaseFee,paymentMonths);
                
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    /* onPackageAmountChange: function($C) {
        
        console.log('Inside onPackageAmountChange in helper');
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositAmount = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var paymentYear = (paymentMonths / 12 );
        var APRVal = $C.get('v.representativeAPR');
        
        console.log('minDepositAmount in onPackageAmountChange : ', minDepositAmount);
        console.log('paymentMonths in onPackageAmountChange : ', minDepositAmount);
        
        var initDepCalculated = minDepositAmount;
        
        if(minDepositPercent !== null) {
            
            var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100));
            
            if(minDepositCalculated > minDepositAmount) {
                
                initDepCalculated = minDepositCalculated ;
            }
            
            $C.set("v.totalDeposit", initDepCalculated); 
            
            console.log('calculated initial deposit is : ', initDepCalculated);
        }
        
        else { 
            $C.set("v.totalDeposit", initDepCalculated);
        } 
        
        var balToFinance = totalpackageprice - initDepCalculated  ;
        console.log('balancetoFinance in onPackageAmountChange: ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        var totalrepayment = (balToFinance * (Math.pow(( 1 + (APRVal / 100) / 1), (paymentYear * 1))));        
        console.log('final totalrepayment in onPackageAmountChange: ', totalrepayment) ;
        
        $C.set("v.totalRepayment", totalrepayment.toFixed(2));
        
        var monthlypaymentamount = totalrepayment / paymentMonths ;
        $C.set("v.monthlyPaymentAmount", monthlypaymentamount.toFixed(2));
        
        $C.set("v.totalCostToCredit", (totalrepayment - balToFinance).toFixed(2));
        
    }, */
    
    onDepositAmountChange: function($C, selectedDeposit){
        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositAmount = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var interestratevar = $C.get('v.interestRate');
        var aprValue =  $C.get('v.representativeAPR');
        var optionToPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var initDepCalculated = minDepositAmount;
        var finalDeposit;
        
        console.log('selected cash deposit in onDepositAmountChange : ', selectedDeposit);
        
        if(minDepositPercent !== null) {
            
            var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100)) ;
            
            if(minDepositCalculated > minDepositAmount) {
                
                initDepCalculated = minDepositCalculated ;
            }
            console.log('calculated initial deposit is : ', initDepCalculated);
        }
        
        if(selectedDeposit < initDepCalculated && selectedDeposit >= minDepositAmount) {
            console.log('selected deposit is less than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
        }
        else if(selectedDeposit > initDepCalculated && selectedDeposit <= totalpackageprice) {
            console.log('selected deposit is greater than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
        }
            else{
                finalDeposit = initDepCalculated ;
                console.log('selected deposit is greater');
            }

        finalDeposit = parseFloat(finalDeposit); // PDR-2676
        
        $C.set("v.totalDeposit", finalDeposit.toFixed(2));  
        console.log('finalDeposit in onDepositAmountChange : ', finalDeposit.toFixed(2));
        
        var balToFinance = totalpackageprice - finalDeposit  ;
        console.log('balancetoFinance : ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        this.paymentCalculation($C,balToFinance,aprValue,optionToPurchaseFee,paymentMonths); 
    },
    
    // PaymentCalculation: Reusable method to calculate Total Repayment, Monthly Payment & Cost of Credit
    paymentCalculation: function($C,balToFinance, aprValue, optionToPurchaseFee, paymentMonths) {
        
        console.log('paymentCalculation : ' );
        
        var apr = Number(aprValue/100);
        console.log('apr value is : ', apr);
        
        var aer = (Math.pow((apr+1), (1/12) )-1)*12 ; 
        aer = aer.toFixed(4);
        $C.set("v.aerValue", aer);
        console.log('aerValue value is : ', aer);
        
        var firstMonthPayment = ((balToFinance) * (aer/12) ) / (1 - Math.pow( (1 + aer/12), -paymentMonths) );
        firstMonthPayment = Number(firstMonthPayment).toFixed(2);
        
        var finalMonthPayment = 0; 
        
        if(optionToPurchaseFee != null && optionToPurchaseFee != 'undefined' 
           && optionToPurchaseFee != 0 && optionToPurchaseFee != 'NaN') {
            console.log('optionToPurchaseFee in If condition : ', optionToPurchaseFee);
            finalMonthPayment = Number(firstMonthPayment) + Number(optionToPurchaseFee);
        }
        else{
            finalMonthPayment = Number(firstMonthPayment);
        }
        
        $C.set("v.firstPaymentAmount",firstMonthPayment); 
        $C.set("v.monthlyPaymentAmount", firstMonthPayment);
        $C.set("v.finalPaymentAmount", finalMonthPayment.toFixed(2));
        console.log('firstMonthPayment value is : ' , firstMonthPayment);
        console.log('finalPaymentAmount value is : ' , finalMonthPayment);
        
        var repaymentMonth = Number(firstMonthPayment) * (Number(paymentMonths)-2) ;
        $C.set("v.regularMonth", (Number(paymentMonths)-2));
        
        var totalrepayment = (Number(firstMonthPayment) + repaymentMonth + Number(finalMonthPayment));
        console.log('total value of totalrepayment : ', totalrepayment) ;
        $C.set("v.totalRepayment", totalrepayment);
        
        $C.set("v.totalCostToCredit", (totalrepayment - balToFinance).toFixed(2)); 
    },
    
})