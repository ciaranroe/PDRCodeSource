({
    // gets the initial values
    getInitialValues: function($C, $E, $H) {
        
        $H.getInvItemDetails($C, $E, $H);
    },
    
    // Update values when Finance Provider is changed
    onFinanceProvChange: function($C, $E, $H) {
        
        var lookupId = $E.getParam("value")[0];
        var inventryItem = $C.get('v.inventoryItem');
        
        $C.set('v.financeProviderId', lookupId);
        console.log('Finance Provider on change', lookupId) ;
        
        if(lookupId == null || lookupId == undefined || lookupId === 'undefined' || lookupId === null) {
            
            // / Reset values when Finance Provider is set to nll
            var defaultMinDepPercent = 10;
            var defaultInterestRate = 4.75;
            $C.set('v.representativeAPR', $A.get("$Label.c.APR"));
            $C.set("v.minimumDepositPercent", defaultMinDepPercent);
            $C.set("v.interestRate", defaultInterestRate);
            
            $H.prepopulateValueswithoutFP($C);
        }
        else {
             $H.getFinanceCalcRules($C,inventryItem);
        }
    },
    
    // change Total package price
  /*  changePackageAmount: function($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var packageamount = $C.get('v.totalPackagePrice');
        var newPackageAmount = Number($C.get('v.totalPackagePrice'));
        if (type == 'add') newPackageAmount += 500;
        if (type == 'subtract') newPackageAmount -= 500;
        if (type == undefined) newPackageAmount = Number($C.find('amountRange').get('v.value'));
        if (newPackageAmount < 0) newPackageAmount = 10000;
        if (newPackageAmount > 500000) newPackageAmount = 500000;
        $C.set('v.totalPackagePrice', newPackageAmount.toFixed(2));
        $H.onPackageAmountChange($C);
    }, */
    
    // changes the term values
    changeTerm: function($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var maximumTerm = $C.get('v.maximumLengthofTerm');
        var newTerm = Number($C.get('v.selectedTermMonth'));
        var interestRateVal = $C.get('v.interestRate');
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var balToFinance = $C.get('v.balancetoFinance');
        
        console.log('newTerm value is : ', newTerm);
        if (type == 'add') newTerm += 12;
        console.log('newTerm value after add is : ', newTerm);
        if (type == 'subtract') newTerm -= 12;
        console.log('newTerm value after subtract is : ', newTerm);
        
        if (newTerm > maximumTerm) newTerm = maximumTerm;
        if (newTerm < 12) newTerm = 12;

        $C.set('v.selectedTermMonth', newTerm);    
        $H.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,newTerm);  
    },
    
    // changes the deposit values
    changeDeposit: function($C, $E, $H) {
        console.log('chanage deposit');
        var type = $E.getSource().get('v.name');
        var minimumDeposit = $C.get('v.minimumDeposit');
        var newDeposit = Number($C.get('v.totalDeposit'));
        var maxDeposit = Number($C.get('v.totalPackagePrice'));
        console.log('change deposit type is : ', type);
        
        if (type == 'add') newDeposit += 500;
        if (type == 'subtract') newDeposit -= 500;
        if (type == undefined) newDeposit =  Number($C.find('depositRange').get('v.value'));
        if (newDeposit < minimumDeposit) newDeposit = minimumDeposit;
        if (newDeposit > maxDeposit) newDeposit = maxDeposit;
        newDeposit = Number(newDeposit);
        if (!isNaN(newDeposit)) newDeposit = Number(newDeposit.toFixed(2));

        console.log('deposit is in change deposit: ', newDeposit);        
        $H.onDepositAmountChange($C, newDeposit);
    },
    
})