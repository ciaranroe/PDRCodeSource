({
  //This function is being called to find out the user's team at onInit
  findUserParkTeam: function(component, event, helper) {
    helper.callServer(
      component,
      "c.getUserParkTeam",
      function(result) {
        var parsedResult = JSON.parse(result);
        
        if (parsedResult.hasError) {
          console.log("Error: " + parsedResult.message);
        } else {//check message contains user's team name
            if(parsedResult.message){
                component.set('v.userTeam',parsedResult.message)
            }
            console.log('userTeam: ' + component.get('v.userTeam'));
        }
      },
      {
        
      }
    );
  },
  updateColumnSorting: function(cmp, event, helper, currentData) {
    cmp.set("v.isSortLoading", true);
    
    // We use the setTimeout method here to simulate the async
    // process of the sorting data, so that user will see the
    // spinner loading when the data is being sorted.
    setTimeout(
      $A.getCallback(function() {
        var fieldName = event.getParam("fieldName");
        var sortDirection = event.getParam("sortDirection");
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection, currentData);
        cmp.set("v.isSortLoading", false);
      }),
      0
    );
  },
  sortData: function(cmp, fieldName, sortDirection, currentData) {
    var data = cmp.get(currentData);
    var reverse = sortDirection !== "asc";

    data = Object.assign(
      [],
      data.sort(this.sortBy(fieldName, reverse ? -1 : 1))
    );

    cmp.set(currentData, data);
  },
  sortBy: function(field, reverse, primer) {
    var key = primer
      ? function(x) {
          return primer(x[field]);
        }
      : function(x) {
          return x[field];
        };

    return function(a, b) {
      var A = key(a);
      var B = key(b);
      return reverse * ((A > B) - (B > A));
    };
  },
  handleResultSuccess: function(component, event, helper, results) {
    console.log(results);
      
      if(results.holidayMakers){
         console.log('Holiday count:' + results.holidayMakers.length)
    	 component.set("v.holidayMakersCount", results.holidayMakers.length);
         component.set("v.holidayMakersColumns", [
              {label: 'PrimaryId', initialWidth: 14, cellAttributes:{ iconName: { fieldName: 'primaryIdIconName' }, 
                                          iconLabel: { fieldName: 'primaryIdIconLabel' }, iconPosition: 'right' }},
              { label: "Name", fieldName: "name", type: "text", sortable: true },
              { label: "Postcode", fieldName: "postcode", type: "text", sortable: true },
              { label: "Email", fieldName: "email", type: "email", sortable: true },
              { label: "Phone", fieldName: "phone", type: "text", sortable: true },
              { label: "Mobile", fieldName: "mobile", type: "text", sortable: true },
              {
                label: "Convert",
                type: "button",
                initialWidth: 135,
                typeAttributes: {
                  label: "Convert",
                  name: "convert",
                  title: "Convert Lead"
                }
              }
            ]);
           	results.holidayMakers = results.holidayMakers.map(function(rowData) {
                if (rowData.primaryId) {
                   rowData.primaryIdIconName = 'utility:success';
                } else {
                   rowData.primaryIdIconName = 'utility:error';
               }
            	return rowData;
       		 });
            component.set("v.holidayMakersData", results.holidayMakers);
      }
      if(results.leads){
           
           component.set("v.leadsCount", results.leads.length);
           component.set("v.leadColumns", [
              {label: 'PrimaryId', initialWidth: 14, cellAttributes:{ iconName: { fieldName: 'primaryIdIconName' }, 
                                                            iconLabel: { fieldName: 'primaryIdIconLabel' }, iconPosition: 'right' }},
              { label: "Name", fieldName: "name", type: "text", sortable: true },
              { label: "Postcode", fieldName: "postcode", type: "text", sortable: true },
              { label: "Email", fieldName: "email", type: "email", sortable: true },
              { label: "Phone", fieldName: "phone", type: "text", sortable: true },
              { label: "Mobile", fieldName: "mobile", type: "text", sortable: true },
              {
                label: "View",
                type: "button",
                initialWidth: 135,
                typeAttributes: {
                  label: "View Details",
                  name: "view_lead_details",
                  title: "Click to View Details"
                }
              }
           ]);
           results.leads = results.leads.map(function(rowData) {
            if (rowData.primaryId) {
               rowData.primaryIdIconName = 'utility:success';
            } else {
               rowData.primaryIdIconName = 'utility:error';
           }
            return rowData;
        });

           component.set("v.leadData", results.leads);
      }
      if(results.contacts){
          component.set("v.contactsCount", results.contacts.length);
           component.set("v.contactColumns", [
              {label: 'PrimaryId', initialWidth: 14, cellAttributes:{ iconName: { fieldName: 'primaryIdIconName' }, 
                                      iconLabel: { fieldName: 'primaryIdIconLabel' }, iconPosition: 'right'}},
			  { label: "Name", fieldName: "name", type: "text", sortable: true },
              {
                label: "Postcode",
                fieldName: "postcode",
                type: "text",
                sortable: true
              },
              { label: "Email", fieldName: "email", type: "email", sortable: true },
              { label: "Phone", fieldName: "phone", type: "text", sortable: true },
              { label: "Mobile", fieldName: "mobile", type: "text", sortable: true },
              {
                label: "View",
                type: "button",
                initialWidth: 135,
                typeAttributes: {
                  label: "View Details",
                  name: "view_contact_details",
                  title: "Click to View Details"
                }
              }
            ]);
               results.contacts = results.contacts.map(function(rowData) {
                if (rowData.primaryId) {
                   rowData.primaryIdIconName = 'utility:success';
                } else {
                   rowData.primaryIdIconName = 'utility:error';
               }
            	return rowData;
       		 });
            component.set("v.contactData", results.contacts);     
      }        
    var totalCount = component.get("v.contactsCount") + component.get("v.leadsCount") + component.get("v.holidayMakersCount");      
    component.set("v.totalCount", totalCount);    
  },
   setPrimaryIdIcon: function(data){
          data = data.map(function(rowData) {
            if (rowData.primaryId) {
               rowData.primaryIdIconName = 'utility:success';
            } else {
               rowData.primaryIdIconName = 'utility:error';
           }
            return rowData;
        });
   },
  showContactOrLeadDetails: function(component, event, helper,recordId) {
      var team=component.get('v.userTeam');
       //controlling user error message
        component.set("v.serverError",'');
      if(team !='Central'){
		   helper.updateRecord(component, event, helper, recordId,'SHARING');
      }
      else{
      		console.log('Central user. No need to add in the sharing.');
          	helper.handleNavigateRecord(component, event, helper, recordId);
      }
  },
  changeRecordType: function(component, event, helper, recordId) {
       var team=component.get('v.userTeam');
        //controlling user error message
        component.set("v.serverError",'');
      if(team !='Central'){
		   	helper.updateRecord(component, event, helper, recordId,'RECORDTYPE_AND_SHARING');
      }
      else{
          	helper.updateRecord(component, event, helper, recordId,'RECORDTYPE');
      }
  },
  updateRecord: function(component, event, helper, recordId, action) {
       var params = {
              Id: recordId,
              action: action
 	   };
        helper.callServer(
          component,
          "c.updateRecord",
          function(resultStr) {
            var results = JSON.parse(resultStr);
            if (results.hasError) {
                console.log('Error: ' + results.message);
                //Display the user error message
                component.set("v.serverError",results.message);
                // result received. Stop the spinner
                component.set("v.isResultLoaded",false);
            } else {//Sucess
                	// result received. Stop the spinner
                    component.set("v.isResultLoaded",false);
                  
                    //handle navigate record
                    if(results.isRecordNavigable){
                        //Close the utility bar
                      	helper.closeUtilityBar(component, event, helper);
                       
                        console.log('Success. Opening the record page. Result message:' + results.message);
                        helper.handleNavigateRecord(component, event, helper, recordId);
                    }
                    else{
                        console.log('Sharing is not updated. Message: ' + results.message);
                        component.set("v.serverError",'Sharing is not updated. Message: ' + results.message);
                    }
            }
          },
          {
            parameterString: JSON.stringify(params)
          }
        );  
    },
  handleNavigateRecord: function(component, event, helper, recordId) {
    component.set("v.isResultLoaded",false);
    var navigation = $A.get("e.force:navigateToSObject");
    navigation.setParams({
      recordId: recordId
    });
    navigation.fire();
    helper.closeUtilityBar(component, event, helper);
  },
  //This function is called in Controller at onInit and onSearchInputChange
  callBack: function(component, event, helper, params) {
    helper.callServer(
      component,
      "c.searchRecords",
      function(resultStr) {
        var results = JSON.parse(resultStr);
        if (results.hasError) {
          console.log("Error: " + results.message);
          //Display the user error message
          component.set("v.serverError",results.message);
          // result received. Stop the spinner
          component.set("v.isResultLoaded",false);
        } else {
          // result received. Stop the spinner
		    component.set("v.isResultLoaded",false);
          helper.handleResultSuccess(component, event, helper, results);
        }
      },
      {
        parameterString: params
      }
    );
  },
  closeUtilityBar: function(component, event, helper){
         var utilityAPI = component.find("utilitybar");
       utilityAPI.minimizeUtility();
  },
  resetForm: function(component, event, helper){
      component.set("v.holidayMakersCount","0");
      component.set("v.leadsCount", "0");
      component.set("v.contactsCount", "0");
      component.set("v.isResultLoaded",false);
       $A.get('e.force:refreshView').fire();
  },
   showToast : function(component, event, helper,title,message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message
        });
        toastEvent.fire();
	},
});