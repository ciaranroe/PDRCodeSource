({
  doInit: function(component, event, helper) {
    var params = component.get("v.params");
    var title = component.get("v.title");
    var results = component.get("v.results");
    component.set('v.title',title);
    component.set("v.serverError",'');
    component.set('v.userTeam','')
    
    console.log("params at Init:" + params);
    //Get user's team
    helper.findUserParkTeam(component, event, helper); 
	
    if(params){//Call when input parameters are sent from parent component 
        //Run the spinner only when parameter are received. 
        //In case of else if when the result is received already, the spinner is loaded in the parent 
        component.set("v.isResultLoaded",true);
        console.log('param at OnInit: ' + params);
   		helper.callBack(component, event, helper, params);
    }
    else if(results){// call when parent sent the result
        helper.handleResultSuccess(component, event, helper, JSON.parse(results));
    }
  },
  onParamInputChange: function(component, event, helper) {
    component.set("v.isResultLoaded",true);
    var oldValue = event.getParam("oldValue");
    var params = event.getParam("value");
	console.log("params at onParamInputChange:" + params);
    if(params){
  	  helper.callBack(component, event, helper, params);
    }
  },
  onResultInputChange: function(component, event, helper) {
    var oldValue = event.getParam("oldValue");

    var results = event.getParam("value");
	console.log("params at onResultInputChange:" + results);
    if(results){
    	 helper.handleResultSuccess(component, event, helper, JSON.parse(results));
    }
  },
  handleContactOrLeadRowAction: function(cmp, event, helper) {
    var action = event.getParam("action");
    var row = event.getParam("row");
    cmp.set("v.isResultLoaded",true);
      
    switch (action.name) {
      case "view_contact_details":
        helper.showContactOrLeadDetails(cmp, event, helper,row.accountId);
        break;
     case "view_lead_details":
       helper.showContactOrLeadDetails(cmp, event, helper,row.Id);     
       break;
     default:
        //helper.showRowDetails(row);
        break;
    }
  },
  handleHolidayMakerRowAction: function(cmp, event, helper) {
    cmp.set("v.isResultLoaded",true);
    var action = event.getParam("action");
    var row = event.getParam("row");
    switch (action.name) {
      case "convert":
        helper.changeRecordType(cmp, event,helper, row.Id);
        break;
      default:
        //helper.showRowDetails(row);
        break;
    }
  },
   updateContactColumnSorting: function (cmp, event, helper) {
       var currentData = "v.contactData";
       helper.updateColumnSorting(cmp, event, helper,currentData);
   },
    updateHolidayMakerColumnSorting: function (cmp, event, helper) {
       var currentData = "v.holidayMakersData";
       helper.updateColumnSorting(cmp, event, helper,currentData);
   },
   updateLeadColumnSorting: function (cmp, event, helper) {
       var currentData = "v.leadData";
       helper.updateColumnSorting(cmp, event, helper,currentData);
   },
});