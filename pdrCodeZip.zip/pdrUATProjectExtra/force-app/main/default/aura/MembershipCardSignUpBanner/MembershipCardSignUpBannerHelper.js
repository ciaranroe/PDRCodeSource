({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },
    
    displayMembershipNumber : function(component, event, helper) {
      
        var action = component.get("c.showMembershipNumber");
        action.setParams({
            "accountId":component.get("v.accountId")  
        });
        
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.membershipNumber", response.getReturnValue());   
                
                //Quuery the parameters to append in the redirectURL
                this.queryAccountParameters(component, event, helper);

            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action);

    },
    
    queryAccountParameters: function(component, event, helper){
        
        var action = component.get("c.getAccountDetails");
        action.setCallback(this, function (response){

            var state = response.getState();
            
            if (state === "SUCCESS") {
                
                component.set("v.acctDetails", response.getReturnValue());

            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }	
        });
        $A.enqueueAction(action);
    },
    
    redirectToSignUpPage: function(component, event, helper){
        
        var acct = component.get("v.acctDetails");
        console.log('---->ACCTDetails2 ' + acct.Name);
        var firstName = acct.FirstName;
        var lastName = acct.LastName;
        var accountNumber = acct.AccountNumber;
        var email = acct.PersonEmail;
        var membershipNumber = component.get("v.membershipNumber");
        
        var address = $A.get("$Label.c.Membership_Sign_Up_URL") + '?acctNum=' + accountNumber + '&membershipNum=' + membershipNumber +'&fn=' + firstName + '&ln=' + lastName + '&email=' + email;
        console.log('URL-------> '+ address);
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isRedirect": false
        });
        urlEvent.fire();        
    }
})