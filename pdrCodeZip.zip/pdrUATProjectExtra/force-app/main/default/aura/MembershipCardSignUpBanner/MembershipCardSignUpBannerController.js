({
	doInit : function(component, event, helper) {
        helper.parsePageUrlParameter(component, event, helper);
		helper.displayMembershipNumber(component, event, helper);
    },
    
    redirectToSignUpPage: function(component, event, helper){
        helper.redirectToSignUpPage(component, event, helper);
    }
})