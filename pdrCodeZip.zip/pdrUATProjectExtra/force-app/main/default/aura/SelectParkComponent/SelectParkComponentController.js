({
	doInit : function(component, event, helper) {
        helper.fetchOptions(component, event, helper);
	},
    handleOptionChange : function(component, event, helper) {
        helper.updateParkSelection(component, event, helper);
    }
})