({
    fetchOptions : function(component, event, helper) {
        var params = {
            "selectMode" : "userParks",
            "userId" : component.get('v.recordId')
        }
        helper.callServer(component,
                          "c.fetchAttributes",
                          function(resultStr) {
                              var resultWrapper = JSON.parse(resultStr);
                              if (resultWrapper.hasError) {
                                  console.log("Error: " + resultWrapper.message);
                                  
                              }
                              else {
                                  this.handleOptions(component, event, helper, resultWrapper);
                              }
                          },
                          {
                              "parameterString": JSON.stringify(params)
                          }
                         );
    },
    handleOptions : function (component, event, helper, resultWrapper) {
        console.log(resultWrapper.optionsList);
        console.log('default value' + resultWrapper.defaultValue);
        component.set('v.options', resultWrapper.optionsList);
        component.set('v.value', resultWrapper.defaultValue);
        component.set('v.isDisabled', resultWrapper.isDisabled);
        if (resultWrapper.optionsList && resultWrapper.optionsList.length > 1) {
            component.set('v.show', true);
        }
    },
    updateParkSelection : function(component, event, helper) {
        var params = {
            "selectedPark" : component.get('v.value'),
            "userId" : component.get('v.recordId')
        }
        helper.callServer(component,
                          "c.updateSelectedPark",
                          function(resultStr) {
                              var resultWrapper = JSON.parse(resultStr);
                              if (resultWrapper.hasError) {
                                  console.log("Error: " + resultWrapper.message);
                                  
                              }
                              else {
                                  if (resultWrapper.selectedChanged && component.get('v.refreshViewOnChange')) {
                                      this.refreshView(component, event, helper);
                                  }
                                  
                              }
                          },
                          {
                              "parameterString": JSON.stringify(params)
                          }
                         );    
    },
    refreshView : function (component, event, helper) {
        $A.get('e.force:refreshView').fire();
    }
})