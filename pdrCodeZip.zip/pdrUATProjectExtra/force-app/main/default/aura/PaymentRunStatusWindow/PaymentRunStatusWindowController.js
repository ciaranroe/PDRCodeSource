({
    init : function(component, event, helper) {
        var paymentData = component.get("v.paymentData");
        component.set("v.TotalPayment", paymentData.totalAmount);
        component.set("v.AccountName", paymentData.contractName);
        component.set("v.MemberName", component.find("sharedMethods").getFullName(paymentData.firstName, paymentData.lastName)); 

        helper.addLineToLog(component, "paymentStart", "Payment transaction - New record", "info");
        
        if (paymentData.totalAmount > 0) {
            component.find("sharedMethods").doShowLogWindow();
            component.find("sharedMethods").doPaymentAuthorization(paymentData.contractId, paymentData.memberId, paymentData.totalAmount, 
                                paymentData.firstName, paymentData.lastName, paymentData.street, paymentData.city, paymentData.country, 
                                paymentData.postalCode, paymentData.phone, paymentData.email);
        } else {
            helper.addLineToLog(component, "paymentStart", "Total Payment Amount must be greater than 0!");
        }
    },
    doEventAction : function(component, event, helper) {
        var key = event.getParam("key");
        var type = event.getParam("type");
        var data = event.getParam("data");
        
        console.log("Event Called In PaymentRunStatusWindowController", key, type, data);

        console.log('doEventAction',key,type,JSON.parse(JSON.stringify(data)));

        if (type === "dmlStatus") {
            if (data.Msg != undefined && data.Msg.Messages != undefined && data.Msg.Messages.length > 0) {
                for (var i = 0; i < data.Msg.Messages.length; i++) {
                    component.set("v.statusMessage", data.Msg.Messages[i][0]);
                    component.set("v.paymentStatus", "statusMessage " + data.Msg.Messages[i][1].toLowerCase());
                    helper.addLineToLog(component, key, data.Msg.Messages[i][2], data.Msg.Messages[i][1].toLowerCase());
                    setTimeout(function(){  }, 3000);
                    if (data.Msg.Messages[i][1] == "Error") {
                        return;
                    }
                }
            }
            if (key == "showLogWindow") {
                component.set("v.showLog", data.ShowLog);
                component.set("v.modalHeight", component.get("v.showLog") ? '425px' : '285px');
            } else if (key === "paymentAuthorization") {
                if (data.PaymentTransactionId != undefined && data.PaymentTransactionId != null && data.PaymentTransactionId != "") {
                    component.set("v.paymentTransactionId", data.PaymentTransactionId);
                    helper.addLineToLog(component, key, "Authorization has done. Payment Transaction Id = " + data.PaymentTransactionId, "info");

                    var paymentData = component.get("v.paymentData");
                    component.set("v.paymentNumber", 1);

                    if (paymentData.paymentLines.length > 0 && component.get("v.runPayment")) {
                        component.find("sharedMethods").doPaymentCreate(1, paymentData.paymentLines.length, data.PaymentTransactionId, paymentData.paymentLines[0].amount, paymentData.paymentLines[0].invoiceType, paymentData.paymentLines[0].invoiceId);
                    }
                } else {
                    helper.addLineToLog(component, key, "Payment Transaction Id is empty!", "error");
                }
            } else if (key === "paymentCreate") {
                helper.addLineToLog(component, key, "Payment record has been created. Amount = " + data.amount + ". Invoice Type = '" + data.invoiceType + "'. (Aura controller)", "info");

                var paymentData = component.get("v.paymentData");
                var paymentNumber = component.get("v.paymentNumber");
                if (component.get("v.runPayment")) {
                    if (paymentNumber < paymentData.paymentLines.length) {
                        component.set("v.paymentNumber", paymentNumber + 1);
                        component.find("sharedMethods").doPaymentCreate(component.get("v.paymentNumber"), paymentData.paymentLines.length, component.get("v.paymentTransactionId"), paymentData.paymentLines[paymentNumber].amount, paymentData.paymentLines[paymentNumber].invoiceType, paymentData.paymentLines[paymentNumber].invoiceId);
                    } else {
                        component.find("sharedMethods").doPaymentSession(component.get("v.paymentTransactionId"), paymentData.firstName, paymentData.lastName, paymentData.street, paymentData.city, paymentData.country, paymentData.postalCode, paymentData.phone, paymentData.email);
                    }
                }
            } else if (key === "paymentSession" && component.get("v.runPayment")) {
                helper.addLineToLog(component, key, "Payment session has initialized.");

                component.set("v.iframeUrl", data.iframeUrl);
                component.set("v.agentAccessToken", data.AgentAccessToken);
                component.set("v.agentRefreshToken", data.AgentRefreshToken);

                component.find("closeButton").set("v.disabled", true);
                component.find("closeButton").set("v.label", "Cancel");
                setTimeout(function(){ 
                    document.getElementById("initForm").submit();
                }, 1000);

                setTimeout(function(){ 
                    component.find("sharedMethods").doPaymentStatus(component.get("v.paymentTransactionId"), component.get("v.paymentData").paymentLines);
                }, 1000);
            } else if (key === "paymentStatus") {
                if (data.canBeClosed) {
                    console.log('******* DATA CAN BE CLOSED');
                    console.log(JSON.stringify(data));
                    console.log(Object.keys(data));
                    console.log(Object.values(data));
                    if (data.isDone) {
                        component.find("sharedMethods").doPaymentAllocation(component.get("v.paymentTransactionId"), component.get("v.paymentData").paymentLines);
                    } else {
                        component.set("v.runPayment", false);
                        component.find("closeButton").set("v.disabled", false);
                        component.find("closeButton").set("v.label", "Close");
                        component.find("closeButton").set("v.title", "Close");
                    }
                } else {
                    setTimeout(function(){ 
                        component.find("sharedMethods").doPaymentStatus(component.get("v.paymentTransactionId"), component.get("v.paymentData").paymentLines);
                    }, 1000);
                }
            } else if (key === "paymentAllocation") {
                component.set("v.runPayment", false);
                component.find("closeButton").set("v.disabled", false);
                component.find("closeButton").set("v.label", "Close");
                component.find("closeButton").set("v.title", "Close");
            }
        }
    },
    closeWindow : function(component, event, helper) {
        if (component.get("v.runPayment")) {
            helper.addLineToLog(component, "User Input", "Canceled!", "error");
        } else {
            component.find("sharedMethods").closeWindow();
        }
    }
})