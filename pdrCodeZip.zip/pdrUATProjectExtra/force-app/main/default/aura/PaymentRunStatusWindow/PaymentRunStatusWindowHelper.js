({
    addLineToLog : function(component, key,  message ,status) {
        var currentTime = new Date().toLocaleTimeString();
        var paymentlog = component.get("v.paymentlog");

        if ((typeof message) != "string") {
            message = "Something is wrong!";
        }

        paymentlog.push({
            "key":key,
            "message": "[" + key + '|' + currentTime + "] " +  message,
            "status":status
        });
        component.set("v.paymentlog", paymentlog);

        if (status == "error") {
            component.set("v.runPayment", false); 
            component.find("closeButton").set("v.label", "Cancel");
            component.find("closeButton").set("v.title", "Cancel");
            component.find("closeButton").set("v.disabled", false);
        }
    }
})