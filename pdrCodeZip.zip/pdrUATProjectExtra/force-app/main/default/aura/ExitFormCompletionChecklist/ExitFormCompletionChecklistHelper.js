({
    getExitFormRecord: function($C, $E, $H) { 
        
        var getRecordApex = $C.get('c.getRecordApex');
        getRecordApex.setParams({recordId : $C.get('v.recordId')});
        getRecordApex.setCallback(this, function(response){
            console.log('response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var record = response.getReturnValue();
                
                //PDR-1944 & PDR-2059
                if(record.RecordType.Name == 'Repossession' || 
                   record.RecordType.Name == 'In Lien' || 
                   record.RecordType.Name == 'Voluntary Termination'){ 
                    $C.set('v.isOwnerDetailsVisible',false);
                }else{
                    $C.set('v.isOwnerDetailsVisible',true);
                } 
                //PDR-2059
                if(record.Payable_By_Parkdean_Resorts__c <= 0){
                    console.log('isPayableByPDRLessOrGreaterThanZero::>> True');
                    $C.set('v.isPayableByPDRLessOrGreaterThanZero',true);
                }
                
                console.log('TEST ExitForm::>>',JSON.stringify(record)); 
                //2021-05-25
                
                var date = new Date(); // Now
                date.setDate(date.getDate() + 3); // Set now + 3 days as the new date
                console.log('TEST ExitForm CurrentDate',date);
                
                var month = 1;
                if(date.getMonth() != 12 ){
                    month = date.getMonth()+1;
                    if(month < 10){
                        month = '0'+month.toString();
                    }
                }

                var day = date.getUTCDate();
                if(day < 10){
                    day = '0'+day.toString();
                }

                var tmpDate = date.getFullYear()+'-'+month+'-'+day;
                console.log('tmpDate::',tmpDate);
                $C.set('v.addDateThreeDaysToCurrentDate',tmpDate);
                $C.set('v.ExitForm',record);
            }

            $H.getWeaverTemplate($C, $E, $H);
        });
        $A.enqueueAction(getRecordApex);
    },

    getWeaverTemplate: function($C, $E, $H) { 

        console.log('getWeaverTemplate');
        
        let getTemplatesApex = $C.get('c.getWeaverAndEmailTemplatesApex');
        getTemplatesApex.setParams({recordId : $C.get('v.recordId')});
        getTemplatesApex.setCallback(this, function(response){
            console.log('getWeaverTemplate response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                let record = response.getReturnValue();
                console.log('getWeaverTemplate, record:');
                console.log(record);
                $C.set('v.WeaverTemplate',record.WeaverTemplate);
                $C.set('v.RequestTemplate',record.RequestTemplate);
                $C.set('v.FinishedTemplate',record.FinishedTemplate);
            }
        });
        $A.enqueueAction(getTemplatesApex);
    },
    
 /*   getChargesNRefunds: function($C, $E, $H) {
        
        var getChrgNRefund = $C.get('c.checkChargesNRefunds');
        getChrgNRefund.setParams({recordId : $C.get('v.recordId')});
        getChrgNRefund.setCallback(this, function(response){
         console.log('response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var isApplied = response.getReturnValue();
                $C.set('v.ChargesRefundsApplied',isApplied);
            }
        });
        $A.enqueueAction(getChrgNRefund);
    } */
})