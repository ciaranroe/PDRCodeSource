({
    doInit : function($C, $E, $H) {

        $H.getExitFormRecord($C, $E, $H);
        // $H.getWeaverTemplate($C, $E, $H);
       // $H.getChargesNRefunds($C, $E, $H);
    },

    startSignatureProcess : function($C,$E,$H){ 
        var exitForm = $C.get('v.ExitForm');
        var weaverTemplate = $C.get('v.WeaverTemplate');
        var requestTemplate = $C.get('v.RequestTemplate');
        var finishedTemplate = $C.get('v.FinishedTemplate');

        var linkUrl = '/apex/aptk_weaver_s__WeaverSignWizard?recordId='+ exitForm.Id 
                        + '&amp;templateId=' + weaverTemplate.Id
                        + '&amp;requestTemplate=' + requestTemplate.Id
                        + '&amp;finishedTemplate=' + finishedTemplate.Id
                        + '&amp;signees=' + exitForm.Contact_Ids_For_Signature__c;

        // window.open("https://www.w3schools.com");

        var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
            "url": linkUrl
        });
        urlEvent.fire();
    }

 /*   setPendingExport : function($C,$E,$H){
        $C.set('v.ResponsePending',true);
        var setPendingExportApex = $C.get('c.setPendingExportApex');
        setPendingExportApex.setParams({recordId : $C.get('v.recordId')});
        setPendingExportApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            if (response.getState() === 'SUCCESS'){
                if (response.getReturnValue() === 'success'){
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": 'Request now pending export to Proactis'
                    }).fire();
                    $A.get('e.force:refreshView').fire();
                } else {
                    $A.get("e.force:showToast").setParams({
                        "title": "Error!",
                        "type": "error",
                        "message": response.getReturnValue()
                    }).fire();
                }
            }
        });
        $A.enqueueAction(setPendingExportApex);
    } */
})