({
    processAccounts: function ($C, accounts, processedIds) {

        var filter = $C.get('v.Filter');

        accounts.forEach(function (account) {

            account.Approval_Status__c = account.Holiday_Home_Grade__c && account.Holiday_Home_Grade_Date__c ? 'Eligible' : 'Ineligible';

            if (account.Subhire_Invitations__r && account.Subhire_Invitations__r.length) {

                account.Invitation = account.Subhire_Invitations__r[0];
                account.Approval_Status__c = account.Invitation.Approval_Status__c;
            }

            account.Selected = false;
            account.Show = processedIds.includes(account.Id) || !filter || account.Approval_Status__c == filter;
            account.Processing = false;

        });


    },
    filterRecords: function ($C) {

        var accounts = $C.get('v.Accounts');
        var filter = $C.get('v.Filter');
        var pageSize = $C.get('v.pageSize');
        var filteredList = [];
        var paginationList = [];

        accounts.forEach(function (account) {
            if (!filter || account.Approval_Status__c == filter) {
                account.Show = true;
                filteredList.push(account);
            }
            account.Processing = false;
        });
        $C.set('v.start', 0);
        $C.set('v.end', pageSize - 1);

        for (var i = 0; i < pageSize; i++) {
            paginationList.push(filteredList[i]);
        }

        $C.set('v.paginationList', paginationList);
        $C.set('v.filteredList', filteredList);
        $C.set('v.filteredList', filteredList);
        $C.set('v.totalSize', filteredList.length);
    }
})