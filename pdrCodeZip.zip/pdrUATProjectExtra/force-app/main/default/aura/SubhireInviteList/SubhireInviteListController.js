({
    doInit: function ($C, $E, $H) {

        console.log('getAccountsApex init called');

        $C.set('v.ResponsePending', true);
        var pageSize = $C.get('v.pageSize');
        var getAccountsApex = $C.get('c.getAccountsApex');
        var sObjectName = $C.get('v.sObjectName');

        getAccountsApex.setParams({ recordId: $C.get('v.recordId'), sObjectType: sObjectName });
        getAccountsApex.setCallback(this, function (response) {
            console.log('recordId: ' + $C.get('v.recordId') + ' sObjectType: ' + sObjectName);
            console.log('getAccountsApex', response.getState(), response.getReturnValue());

            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS') {

                var content = response.getReturnValue();
                var accounts = content.Accounts;
                var paginationList = [];

                $H.processAccounts($C, accounts, []);
                $C.set('v.Accounts', accounts);
                $C.set('v.filteredList', accounts);
                $C.set('v.totalSize', $C.get('v.Accounts').length);
                $C.set('v.start', 0);
                $C.set('v.displayStart', 1);
                var end = 0;

                pageSize <= accounts.length ? end = pageSize - 1 : end = accounts.length - 1;
                if (accounts.length - 1 < pageSize) {
                    end = accounts.length - 1;
                }

                $C.set('v.end', end);
                $C.set('v.displayEnd', end + 1);

                for (var i = 0; i < pageSize; i++) {
                    paginationList.push(accounts[i]);
                }

                $C.set('v.paginationList', paginationList);
                $C.set('v.Season', content.Season);
                // $C.set('v.OwnerCount', content.OwnerCount[0].expr0);
            }

        });
        $A.enqueueAction(getAccountsApex);

    },
    nextPage: function ($C, $E, $H) {

        var accList = $C.get('v.filteredList');
        var end = $C.get('v.end');
        var start = $C.get('v.start');
        var pageSize = $C.get('v.pageSize');
        var paginationList = [];
        var counter = 0;

        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (accList.length > end) {
                paginationList.push(accList[i]);
                counter++;
            }
        }

        start += counter;
        end += counter;
        if (end >= accList.length) {
            end = accList.length - 1
        }

        $C.set('v.start', start);
        $C.set('v.displayStart', start + 1);
        $C.set('v.end', end);
        $C.set('v.displayEnd', end + 1);
        $C.set('v.paginationList', paginationList);
    },
    previousPage: function ($C, $E, $H) {

        var accList = $C.get('v.filteredList');
        var end = $C.get('v.end');
        var start = $C.get('v.start');
        var pageSize = $C.get('v.pageSize');
        var paginationList = [];
        var counter = 0;

        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                paginationList.push(accList[i]);
                counter++;
            }
            else {
                start++;
            }
        }

        start = - counter;
        if (start < 0) { start = 0 }
        end = - counter;

        $C.set('v.start', start);
        $C.set('v.displayStart', start + 1);
        $C.set('v.end', end);
        $C.set('v.displayEnd', end + 1);

        $C.set('v.paginationList', paginationList);
    },
    filterRecords: function ($C, $E, $H) {

        var accounts = $C.get('v.Accounts');
        var filter = $C.get('v.Filter');
        var pageSize = $C.get('v.pageSize');
        var filteredList = [];
        var paginationList = [];

        accounts.forEach(function (account) {
            if (!filter || account.Approval_Status__c == filter) {
                account.Show = true;
                filteredList.push(account);
            }
            account.Processing = false;
        });

        var end = 0;

        pageSize <= filteredList.length ? end = pageSize - 1 : end = filteredList.length - 1;
        if (filteredList.length - 1 < pageSize) {
            end = filteredList.length - 1;
        }

        $C.set('v.start', 0);
        $C.set('v.displayStart', 1);
        $C.set('v.end', end);
        $C.set('v.displayEnd', end + 1);

        for (var i = 0; i < pageSize; i++) {
            paginationList.push(filteredList[i]);
        }

        $C.set('v.paginationList', paginationList);
        $C.set('v.filteredList', filteredList);
        $C.set('v.totalSize', filteredList.length);
    },
    selectAccount: function ($C, $E, $H) {

        var accountIds = [];

        var accounts = $C.get('v.Accounts');
        accounts.forEach(function (account) {
            if (account.Approval_Status__c == 'Eligible' && account.Selected) {
                accountIds.push(account.Id);
                account.Processing = true;
            } else {
                account.Processing = false;
            }
        });

        $C.set('v.Selected', accountIds.length);

    },
    togglSelectAllEligible: function ($C, $E, $H) {

        var accountIds = [];

        var selectAll = $C.get('v.SelectAll');

        var accounts = $C.get('v.filteredList');
        var pageList = $C.get('v.paginationList');

        accounts.forEach(function (account) {
            if (account.Approval_Status__c == 'Eligible') {
                if (selectAll) {
                    account.Selected = true;
                    // account.Processing = true;
                    accountIds.push(account.Id);
                } else {
                    account.Selected = false;
                }
            }
        });

        $C.set('v.Selected', accountIds.length);
        $C.set('v.filteredList', accounts);
        $C.set('v.paginationList', pageList);
    },

    inviteAccounts: function ($C, $E, $H) {

        $C.set('v.ResponsePending', true);
        var pageSize = $C.get('v.pageSize');
        var accountIds = [];
        var accounts = $C.get('v.Accounts');

        console.log('accounts', accounts.length, accounts);

        accounts.forEach(function (account) {
            if (account.Approval_Status__c == 'Eligible' && account.Selected) {
                accountIds.push(account.Id);
                account.Processing = true;
            }
        });

        $C.set('v.Accounts', accounts);

        var inviteAccountsApex = $C.get('c.inviteAccountsApex');

        inviteAccountsApex.setParams({ recordId: $C.get('v.recordId'), accountIds: accountIds, easyLet: $C.get('v.EasyLet'), GI: $C.get('v.GI'), sObjectType: $C.get('v.sObjectName') });
        inviteAccountsApex.setCallback(this, function (response) {

            console.log('getAccountsApex', response.getState(), response.getReturnValue());

            var returnedAccounts = response.getReturnValue();

            $C.set('v.ResponsePending', false);
            console.log('returnedAccounts:        ' + returnedAccounts);
            $H.processAccounts($C, returnedAccounts, accountIds);
            $C.set('v.Accounts', returnedAccounts);
            $H.filterRecords($C);

            $C.set('v.Selected', 0);
        });
        $A.enqueueAction(inviteAccountsApex);

    },
    display: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;

        console.log('display called', dataset.id);
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    },
    displayOut: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    }
})