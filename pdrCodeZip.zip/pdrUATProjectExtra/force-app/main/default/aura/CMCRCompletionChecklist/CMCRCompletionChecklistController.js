({

    doInit : function($C, $E, $H) {

        $H.getRecord($C, $E, $H);
    },

    startSignatureProcess : function($C,$E,$H){ 
        var cmcr = $C.get('v.CMCR');
        var weaverTemplate = $C.get('v.WeaverTemplate');
        var requestTemplate = $C.get('v.RequestTemplate');
        var finishedTemplate = $C.get('v.FinishedTemplate');

        var linkUrl = '/apex/aptk_weaver_s__WeaverSignWizard?recordId='+ cmcr.Id 
                        + '&amp;templateId=' + weaverTemplate.Id
                        + '&amp;requestTemplate=' + requestTemplate.Id
                        + '&amp;finishedTemplate=' + finishedTemplate.Id
                        + '&amp;signees=' + cmcr.Contact_Ids_For_Signature__c;

        var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
            "url": linkUrl
        });
        urlEvent.fire();
    }

})