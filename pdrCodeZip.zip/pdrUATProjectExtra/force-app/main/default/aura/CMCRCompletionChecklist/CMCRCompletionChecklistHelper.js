({
    getRecord: function($C, $E, $H) { 
        
        var getRecordApex = $C.get('c.getRecordApex');
        getRecordApex.setParams({recordId : $C.get('v.recordId')});
        getRecordApex.setCallback(this, function(response){
            console.log('response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var record = response.getReturnValue();
                
                $C.set('v.CMCR',record);
            }

            $H.getWeaverTemplate($C, $E, $H);
        });
        $A.enqueueAction(getRecordApex);
    },

    getWeaverTemplate: function($C, $E, $H) { 
    
        console.log('getWeaverTemplate');
        
        let getTemplatesApex = $C.get('c.getWeaverAndEmailTemplatesApex');
        getTemplatesApex.setParams({recordId : $C.get('v.recordId')});
        getTemplatesApex.setCallback(this, function(response){
            console.log('getWeaverTemplate response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                let record = response.getReturnValue();
                console.log('getWeaverTemplate, record:');
                console.log(record);
                $C.set('v.WeaverTemplate',record.WeaverTemplate);
                $C.set('v.RequestTemplate',record.RequestTemplate);
                $C.set('v.FinishedTemplate',record.FinishedTemplate);
            }
        });
        $A.enqueueAction(getTemplatesApex);
    }
    
})