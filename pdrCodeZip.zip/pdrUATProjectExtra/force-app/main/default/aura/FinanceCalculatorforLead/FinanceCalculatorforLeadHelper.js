/**********************************************************************************************
    * @Author: Akansha Bhardwaj
    * @Date: 01/12/2020        
    * @Description: Helper class for FinanceCalculatorforLeadController
    * @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
************************************************************************************************/
({
    // get Finance Provider
    getFinanceProviderNParkId: function ($C, $E, $H) {
        console.log('Entered in helper.getFinanceProviderNParkId '); 
        
        var action = $C.get('c.getFinanceProviderNPark');
        
        //action.setParams({ "recordId": recordId });
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            if (state == 'SUCCESS') {
                
                var resultMap = response.getReturnValue();
                
                if(resultMap !== null) { 
                    
                    var modelYr = $C.get("v.selectedTypeOption");
                    var invntryType = $C.get("v.modelYearValue");
                    
                    if(resultMap.financeProvId !== null && resultMap.park !== null) {
                        console.log('Both Park & finance prov are present')
                        $C.set("v.financeProviderId", resultMap.financeProvId);
                        $C.set("v.parkId", resultMap.park);
                        
                        if(modelYr != null && invntryType != null) {
                            console.log('Type & Model Year not null');
                            this.getFinanceCalcRules($C);
                        }
                    }
                    
                    else {
                        console.log('Finance Provider is null');
                        this.prepopulateValueswithoutFP($C);
                    }
                }
                
                else {
                    console.log('Finance Provider is null');
                    this.prepopulateValueswithoutFP($C);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    // get Finance Calculator Rules
    getFinanceCalcRules: function($C) { 
        console.log('Entered in helper.getFinanceCalcRules '); 
        
        var modelYear = $C.get('v.modelYearValue');
        var inventoryitemType =  $C.get('v.selectedTypeOption');
        
        var action = $C.get('c.getFinanceCalculatorRules');        
        action.setParams({
            "financeProvId":  $C.get('v.financeProviderId'),
            "parkId": $C.get('v.parkId')                    
        }); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();
                console.log('resultMap of getFinanceCalcRules is: ', resultMap);

               if(resultMap.LodgeMaxTermMonths != null && resultMap.CaravanMaxTermMonths != null) {
                    var lodgeDetails = {
                        maxAge : resultMap.LodgeMaxAge,
                        minAge : resultMap.LodgeMinAge,
                        maxTerm : resultMap.LodgeMaxTermMonths
                    };
                    $C.set("v.lodgeInvntryType", lodgeDetails);
                    console.log('lodgeDetails obj : ', lodgeDetails);
                    
                    var caravanDetails = {
                        maxAge : resultMap.CaravanMaxAge,
                        minAge : resultMap.CaravanMinAge,
                        maxTerm : resultMap.CaravanMaxTermMonths
                    };
                    $C.set("v.caravanInvntryType", caravanDetails);
                    console.log('caravanDetails obj : ', caravanDetails);
                    
                    if(inventoryitemType === 'Caravan') {
                        console.log('Caravan : ');
                        this.setMaxTermMonths($C, caravanDetails, modelYear);
                    }
                    if(inventoryitemType === 'Lodge') {
                        console.log('Lodge : ');
                        this.setMaxTermMonths($C, lodgeDetails, modelYear)
                    }
                    this.prepopulateValues($C);
                }
                
                else{
                    alert('Finance Calculator Rules are not configured for the selected Finance Provider and Park. Please contact your administrator.');
                    var lodgeDetails = {maxAge : 2010,minAge : 2006,maxTerm : 84};    
                    $C.set("v.lodgeInvntryType", lodgeDetails);

                    var caravanDetails = {maxAge : 2010,minAge : 2006,maxTerm : 84};
                    $C.set("v.caravanInvntryType", caravanDetails);

                    this.setMaxTermMonths($C, caravanDetails, modelYear);
                    this.prepopulateValueswithoutFP($C);
                } 
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    // set value of MaxTermMonths
    setMaxTermMonths: function($C, typeDetails, modelYear) {
        
        console.log('setMaxTermMonths :') ;
         console.log('modelYear in setMaxTermMonths : ', modelYear) ;
        
        if(modelYear >= typeDetails.maxAge) {
            $C.set("v.maximumLengthofTerm", typeDetails.maxTerm);
            $C.set('v.selectedTermMonth', typeDetails.maxTerm); 
        }
        
        if(modelYear < typeDetails.maxAge && modelYear >= typeDetails.minAge) {
            
            var yearDifference = typeDetails.maxAge -  modelYear ;
            console.log('yearDifference is : ', yearDifference);
            var maxTermLength = typeDetails.maxTerm - (yearDifference*12)  ;
            console.log('new maxTermLength is : ' , maxTermLength);
            
            $C.set("v.maximumLengthofTerm", maxTermLength);
            $C.set('v.selectedTermMonth', maxTermLength); 
        }        
    },
    
    //get Type picklist Value
    getTypeOptions: function($C) { 
        console.log('Entered in helper.getTypeOptions '); 
        var action = $C.get("c.getTypePickval");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                $C.set("v.typeOptionList", result);
                $C.find("typePicklistId").set("v.value", result[0]);
                $C.set("v.selectedTypeOption", result[0]);
                
                console.log('Selected Type in getTypeOptions: ' , $C.get('v.selectedTypeOption'));
            }
        });
        $A.enqueueAction(action);
    },
    
    //get Type picklist Value
    getModelYearOptions: function($C) { 
        console.log('Entered in helper.getModelYearOptions '); 
        var action = $C.get("c.getModelYearPickval");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                $C.set("v.modelYearList", result);
                
                //Set the default value
                $C.find("modelYearPicklistId").set("v.value", result[0]);
                $C.set("v.modelYearValue", result[0]);
                
                console.log('Selected ModelYear : ' , $C.get('v.modelYearValue'));
            }
        });
        $A.enqueueAction(action);
    },

    // Calculate and populate values when Finance Provider is not present
    prepopulateValueswithoutFP: function($C) {
        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositThreshold = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var interestRateVar = $C.get('v.interestRate');
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var paymentMonths = $C.get('v.selectedTermMonth');

         var initDepCalculated = minDepositThreshold;
        
        var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100)) ;
        
        if(minDepositCalculated > minDepositThreshold) {
            
            initDepCalculated = minDepositCalculated ;
        }
        
        $C.set("v.minimumDeposit", minDepositThreshold);
        $C.set("v.totalDeposit", initDepCalculated); 
        
        console.log('calculated initial deposit is : ', initDepCalculated);
        
        var balToFinance = totalpackageprice - initDepCalculated  ;
        console.log('balancetoFinance : ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        this.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,paymentMonths);
    },
    
    // Calculate and populate values when Finance Provider is present
    prepopulateValues: function ($C) {
        
        var action = $C.get('c.getValuesfromFP');
        
        action.setParams({ "financeProviderId": $C.get('v.financeProviderId') });
        
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();
                var totalpackageprice = $C.get('v.totalPackagePrice');
                var minDepositThreshold = $C.get('v.minimumDeposit');
                var initDepCalculated = minDepositThreshold;
                var paymentMonths =  $C.get('v.maximumLengthofTerm');
                var optPurchaseFee = Number(resultMap.Option_to_Purchase_Fee__c); 

                if (resultMap.Minimum_Deposit__c !== null) {
                    var minDepPercent = resultMap.Minimum_Deposit__c;
                    var minDepositCalculated = (totalpackageprice * (minDepPercent / 100));
                    
                    if (minDepositCalculated > minDepositThreshold) {
                        initDepCalculated = minDepositCalculated;
                    }
                    $C.set("v.minimumDeposit", minDepositThreshold);
                    $C.set("v.totalDeposit", initDepCalculated);
                }
                else {
                    $C.set("v.minimumDeposit", initDepCalculated);
                    $C.set("v.totalDeposit", initDepCalculated);
                }

                console.log('totalDeposit in prepopulate', initDepCalculated);
                console.log('totalpackageprice in prepopulate', totalpackageprice);
                
                var balToFinance = totalpackageprice - initDepCalculated;
                console.log('balToFinance in prepopulate', balToFinance);
                $C.set("v.balancetoFinance", balToFinance.toFixed(2));

                $C.set("v.minimumDepositPercent", (resultMap.Minimum_Deposit__c));
                $C.set("v.OptiontoPurchaseFee", optPurchaseFee);
                $C.set("v.interestRate", resultMap.Interest_Rate__c);
                $C.set("v.representativeAPR", resultMap.APR__c);

                if (paymentMonths === null || paymentMonths === 'undefined') {
                    //if Maximum_Term_Months__c is null set maximum term length and selected term length as default value
                    paymentMonths = 84;
                    $C.set("v.maximumLengthofTerm", 84);
                    $C.set("v.selectedTermMonth", 84);
                }
                else { 
                    $C.set("v.maximumLengthofTerm", (paymentMonths));
                    $C.set("v.selectedTermMonth", (paymentMonths)); 
                }
                
                this.paymentCalculation($C,balToFinance,resultMap.APR__c,optPurchaseFee,paymentMonths);
            }
        });
        $A.enqueueAction(action);
    },
    
    // PaymentCalculation: Reusable method to calculate Total Repayment, Monthly Payment & Cost of Credit
    paymentCalculation: function($C,balToFinance, aprValue, optionToPurchaseFee, paymentMonths) {
        
        console.log('paymentCalculation : ' );
        
        var apr = Number(aprValue/100);
        console.log('apr value is : ', apr);
        
        var aer = (Math.pow((apr+1), (1/12) )-1)*12 ; 
        aer = aer.toFixed(4);
        $C.set("v.aerValue", aer);
        console.log('aerValue value is : ', aer);
        
        var firstMonthPayment = ((balToFinance) * (aer/12) ) / (1 - Math.pow( (1 + aer/12), -paymentMonths) );
        firstMonthPayment = Number(firstMonthPayment).toFixed(2);
        
        var finalMonthPayment = 0; 
        
        if(optionToPurchaseFee != null && optionToPurchaseFee != 'undefined' 
           && optionToPurchaseFee != 0 && optionToPurchaseFee != 'NaN') {
            console.log('optionToPurchaseFee in If condition : ', optionToPurchaseFee);
            finalMonthPayment = Number(firstMonthPayment) + Number(optionToPurchaseFee);
        }
        else{
            finalMonthPayment = Number(firstMonthPayment);
        }
        
        $C.set("v.firstPaymentAmount",firstMonthPayment); 
        $C.set("v.monthlyPaymentAmount", firstMonthPayment);
        $C.set("v.finalPaymentAmount", finalMonthPayment);
        console.log('firstMonthPayment value is : ' , firstMonthPayment);
        console.log('finalPaymentAmount value is : ' , finalMonthPayment);
        
        var repaymentMonth = Number(firstMonthPayment) * (Number(paymentMonths)-2) ;
        $C.set("v.regularMonth", (Number(paymentMonths)-2));
        
        var totalrepayment = (Number(firstMonthPayment) + repaymentMonth + Number(finalMonthPayment));
        console.log('total value of totalrepayment : ', totalrepayment) ;
        $C.set("v.totalRepayment", totalrepayment);
        
        $C.set("v.totalCostToCredit", (totalrepayment - balToFinance).toFixed(2)); 
        
    },
    
    // Action on Type or Model Year picklist value change
    typeOrModelYrChange:  function($C,selectedModelYr,selectedType) { 
        
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var lodgeDetails = $C.get("v.lodgeInvntryType");
        var caravanDetails  = $C.get("v.caravanInvntryType");
        var maxAgeYear;
        var minAgeYear;
        var maxTermVal;
        var newMaxTermValue;
        
        if(selectedType === 'Lodge') {
            this.setMaxTermMonths($C, lodgeDetails, selectedModelYr);
        }
        else {
            this.setMaxTermMonths($C, caravanDetails, selectedModelYr);
        }
        
        $C.set("v.modelYearValue", selectedModelYr);
        
        var balToFinance = $C.get('v.balancetoFinance');

        this.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,$C.get('v.selectedTermMonth'));
    }, 

    // Recalculate of other values based on packageAmountChange
    onPackageAmountChange: function($C) {            
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositAmount = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var initDepCalculated = minDepositAmount;
        
        if(minDepositPercent !== null) {            
            var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100));            
            if(minDepositCalculated > minDepositAmount) {                
                initDepCalculated = minDepositCalculated ;
            }            
            $C.set("v.totalDeposit", initDepCalculated); 
        }        
        else { 
            $C.set("v.totalDeposit", initDepCalculated);
        }  
        var balToFinance = totalpackageprice - $C.get("v.totalDeposit");
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        this.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,paymentMonths);
    },
    
    // Recalculate of other value based on cash deposit chnaged
    onDepositAmountChange: function($C, selectedDeposit){        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var minDepositAmount = $C.get('v.minimumDeposit');
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var aprValue =  $C.get('v.representativeAPR');
        var optionToPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var initDepCalculated = minDepositAmount;
        var finalDeposit;
        
        if(minDepositPercent !== null) {            
            var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100));            
            if(minDepositCalculated > minDepositAmount) {                
                initDepCalculated = minDepositCalculated ;
            }
        }
        console.log('initDepCalculated on change deposit : ' , initDepCalculated);
        if(selectedDeposit < initDepCalculated && selectedDeposit >= minDepositAmount) {
            console.log('selected deposit is less than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
        }
        else if(selectedDeposit > initDepCalculated && selectedDeposit <= totalpackageprice) {
            console.log('selected deposit is greater than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
        }
            else{
                finalDeposit = initDepCalculated ;
                console.log('selected deposit is greater');
            }

        finalDeposit = parseFloat(finalDeposit); // PDR-2676
        
        $C.set("v.totalDeposit", finalDeposit.toFixed(2));  
        console.log('new deposit : ', $C.get("v.totalDeposit"));
        var balToFinance = totalpackageprice - (finalDeposit.toFixed(2))  ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        this.paymentCalculation($C,balToFinance,aprValue,optionToPurchaseFee,paymentMonths);
    },
    
    // Create calculator record and open flow to genereate document
    getCalculatorResult: function ($C, parameters) {
        var action = $C.get('c.saveCalculation');
        console.log(parameters);
        action.setParams(parameters);
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            var resultMap = response.getReturnValue();
            var calculatorId = resultMap.CalculatorId;
            var errormsg = resultMap.Error;
            var result = response.getReturnValue();
            
            if (state === "SUCCESS") {
                if (resultMap.Success === 'Calculations Saved') {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success",
                        "message": "Calculation Saved successfully"
                    });
                    toastEvent.fire();
                    
                    $C.set("v.isFlowModalOpen", true);
                    //Find lightning flow from component
                    var flow = $C.find("FinanceCalculationDocumentFlow");
                    //Put input variable values
                    var inputVariables = [
                        {
                            name: "CalculatorId",
                            type: "String",
                            value: calculatorId
                        }
                    ];
                    //Reference flow's Unique Name
                    flow.startFlow("FinanceCalculationDocumentFlow", inputVariables);
                }
                else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": result
                    });
                    toastEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    // Get Lead record
    getLeadName: function ($C) {
        console.log('Inside Method');
        var action = $C.get('c.getLeadName');
        action.setParams({ "leadId" : $C.get('v.recordId')});
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            var result = response.getReturnValue();
            console.log('State '+ state);
            console.log('Result '+ result);
            if (state === "SUCCESS") {
                $C.set("v.leadName", result);
                console.log('Lead Name '+ $C.get("v.leadName"));
            }
        });
        $A.enqueueAction(action);
    }
})