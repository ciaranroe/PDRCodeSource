/**********************************************************************************************
    * @Author: Akansha Bhardwaj
    * @Date: 01/12/2020        
    * @Description: Controller for FinanceCalculatorforLead Aura Component
    * @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
************************************************************************************************/
({
    /**
    * Method Name : getInitialValues
    * Parameters  : Component, Event, Helper
    * Description : gets the initial values based on Finance provider
    * Created By  : Akansha Bhardwaj
    * Created On  : 01/12/2020
    **/
    getInitialValues: function ($C, $E, $H) {
        $H.getLeadName($C);
        $H.getModelYearOptions($C);
        $H.getTypeOptions($C);
        $H.getFinanceProviderNParkId($C, $E, $H);
    },
    
    /**
    * Method Name : onFinanceProvChange
    * Parameters  : Component, Event, Helper
    * Description : Update values when Finance Provider is changed
    * Created By  : Akansha Bhardwaj
    * Created On  : 02/12/2020
    **/
    onFinanceProvChange: function ($C, $E, $H) {
        var lookupId = $E.getParam("value")[0];
        $C.set('v.financeProviderId', lookupId);
        console.log('Finance Provider on change', lookupId) ;
        
        if(lookupId == null || lookupId == undefined || lookupId === 'undefined' || lookupId === null) {
            // Reset values when Finance Provider is set to nll
            var defaultMinDepPercent = 10;
            var defaultInterestRate = 4.75;
            $C.set('v.representativeAPR', $A.get("$Label.c.APR"));
            $C.set("v.minimumDepositPercent", defaultMinDepPercent);
            $C.set("v.interestRate", defaultInterestRate);
            
            $H.prepopulateValueswithoutFP($C);
        }
        else {
            $H.getFinanceCalcRules($C); 
        }
    },
    
    /**
    * Method Name : changePackageAmount
    * Parameters  : Component, Event, Helper
    * Description : chnage Total package price
    * Created By  : Akansha Bhardwaj
    * Created On  : 02/12/2020
    **/
    changePackageAmount: function ($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var newPackageAmount = Number($C.get('v.totalPackagePrice'));
        if (type == 'add') newPackageAmount += 500;
        if (type == 'subtract') newPackageAmount -= 500;
        if (type == undefined) newPackageAmount = Number($C.find('amountRange').get('v.value'));
        if (newPackageAmount < 10000) newPackageAmount = 10000;
        if (newPackageAmount > 500000) newPackageAmount = 500000;
        $C.set('v.totalPackagePrice', newPackageAmount);
        $H.onPackageAmountChange($C);
    },
    
    /**
    * Method Name : changeTerm
    * Parameters  : Component, Event, Helper
    * Description : changes the term values
    * Created By  : Akansha Bhardwaj
    * Created On  : 02/12/2020
    **/
    changeTerm: function ($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var maximumTerm = $C.get('v.maximumLengthofTerm');
        var newTerm = Number($C.get('v.selectedTermMonth'));
        var balToFinance = $C.get('v.balancetoFinance');
        var aprValue =  $C.get('v.representativeAPR');
        var optPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        
        if (type == 'add') newTerm += 12;
        if (type == 'subtract') newTerm -= 12;
        if (newTerm > maximumTerm) newTerm = maximumTerm;
        if (newTerm < 12) newTerm = 12;
        
        $C.set('v.selectedTermMonth', newTerm);
        $H.paymentCalculation($C,balToFinance,aprValue,optPurchaseFee,newTerm);  
    },
    
    /**
    * Method Name : changeDeposit
    * Parameters  : Component, Event, Helper
    * Description : changes the deposit values
    * Created By  : Akansha Bhardwaj
    * Created On  : 02/12/2020
    **/
    changeDeposit: function ($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var minimumDeposit = $C.get('v.minimumDeposit');
        var newDeposit = Number($C.get('v.totalDeposit'));
        var maxDeposit = $C.get('v.totalPackagePrice');
        
        if (type == 'add') newDeposit += 500;
        if (type == 'subtract') newDeposit -= 500;
        if (type == undefined) newDeposit = Number($C.find('depositRange').get('v.value'));
        console.log('type is : ', type);
        if (newDeposit < minimumDeposit) newDeposit = minimumDeposit;
        if (newDeposit > maxDeposit) newDeposit = maxDeposit;
        newDeposit = Number(newDeposit);
        if (!isNaN(newDeposit)) newDeposit = Number(newDeposit.toFixed(2));
        console.log('newDeposit in controller changeDeposit is: ', newDeposit);
        
        $H.onDepositAmountChange($C, newDeposit);
    },
    
    // On Inventory Type Change
    InvntryTypeChange : function($C, $E, $H){ 
        var selectedType =  $E.getSource().get("v.value");
        var selectedYearOption = $C.get("v.modelYearValue");
        
        $C.set("v.selectedTypeOption", selectedType);
        
        console.log('selectedTypeOption : ', selectedType);
        console.log('selectedYearOption on Type change: ', selectedYearOption);
        
        $H.typeOrModelYrChange($C,selectedYearOption,selectedType);
    },
    
    // change the model year value
    changeModelYear: function($C, $E, $H) {  
        var selectedYearOption = $E.getSource().get("v.value"); 
        var selectedType = $C.get("v.selectedTypeOption");
        $H.typeOrModelYrChange($C,selectedYearOption,selectedType);
    },
    
    /**
    * Method Name : saveResult
    * Parameters  : Component, Event, Helper
    * Description : Save result as a new Calculator record
    * Created By  : Akansha Bhardwaj
    * Created On  : 03/12/2020
    **/
    saveResult: function ($C, $E, $H) {
        
        // var totalAmountPayable = $C.get('v.totalDeposit') + $C.get('v.totalPackagePrice') + $C.get('v.totalCostToCredit') ;
        var totalAmountPayable = $C.get('v.totalPackagePrice');
        
        var calculation = {
            Name: $C.get('v.leadName'),
            Lead__c: $C.get('v.recordId'),
            Balance_to_Finance__c: $C.get('v.balancetoFinance'),
            APR__c: $C.get('v.representativeAPR'),
            Deposit__c: $C.get('v.totalDeposit'),
            Finance_Provider__c: $C.get('v.financeProviderId'),
            Monthly_Repayment__c: $C.get('v.monthlyPaymentAmount'),
            Months_To_Pay_Back__c: $C.get('v.selectedTermMonth'),
            Option_to_Purchase_Fee__c: $C.get('v.OptiontoPurchaseFee'),
            Total_Repayment__c: $C.get('v.totalRepayment'),
            Total_Cost_Of_Credit__c: $C.get('v.totalCostToCredit'),
            Total_Amount_Payable__c: totalAmountPayable,
            InventoryType__c: $C.get('v.selectedTypeOption'),
            Location__c: $C.get('v.parkId'),
            Model_Year__c: $C.get('v.modelYearValue'),
            Type__c: 'Finance',
            Initial_Payment__c : $C.get('v.firstPaymentAmount')
        };
        var params = {
            result: calculation
        };
        
        $H.getCalculatorResult($C, params);
    },
    
    /**
    * Method Name : handleFlowStatusChange
    * Parameters  : Component, Event, Helper
    * Description : Close flow modal and redirect user to quote record
    * Created By  : Akansha Bhardwaj
    * Created On  : 03/12/2020
    **/
    handleFlowStatusChange: function ($C, $E, $H) {
        if ($E.getParam("status") === "FINISHED") {
            var urlEvent = $A.get("e.force:navigateToSObject");
            urlEvent.setParams({
                "recordId": $C.get('v.quoteId'),
                "isredirect": "true"
            });
            urlEvent.fire();
            $C.set("v.isFlowModalOpen", false);
        }
    }
})