({
    getRates: function ($C) {
        return {
            StarterPitchFeeThisYear: 0,
            StandardPitchFeeThisYear: 0,
            PremiumPitchFeeThisYear: 0,
            PlatinumPitchFeeThisYear: 0,
            StarterPitchFeeNextYear: 0,
            StandardPitchFeeNextYear: 0,
            PremiumPitchFeeNextYear: 0,
            PlatinumPitchFeeNextYear: 0,
            RatesThisYear: 0,
            RatesNextYear: 0
        };
    },
    getMonthInt: function (monthString) {

        var monthInt;

        if (monthString == 'January') {
            monthInt = 0;
        } else if (monthString == 'February') {
            monthInt = 1;
        } else if (monthString == 'March') {
            monthInt = 2;
        } else if (monthString == 'April') {
            monthInt = 3;
        } else if (monthString == 'May') {
            monthInt = 4;
        } else if (monthString == 'June') {
            monthInt = 5;
        } else if (monthString == 'July') {
            monthInt = 6;
        } else if (monthString == 'August') {
            monthInt = 7;
        } else if (monthString == 'September') {
            monthInt = 8;
        } else if (monthString == 'October') {
            monthInt = 9;
        } else if (monthString == 'November') {
            monthInt = 10;
        } else if (monthString == 'December') {
            monthInt = 11;
        }

        return monthInt;

    },
    getMultiplier: function (monthInt, parkCompany, dayInt) {

        var multiplier = 1;

        if (parkCompany.startsWith('Parkdean')) {
            if (monthInt == 3) {
                multiplier = 0.9;
            } else if (monthInt == 4) {
                multiplier = 0.8;
            } else if (monthInt == 5) {
                multiplier = dayInt < 16 ? 0.7 : 0.6;
            } else if (monthInt == 6) {
                multiplier = dayInt < 16 ? 0.45 : 0.3;
            } else if (monthInt == 7) {
                multiplier = dayInt < 16 ? 0.2 : 0.1;
            } else if (monthInt >= 8) {
                multiplier = 0;
            }
        } else if (parkCompany.startsWith('Park Resorts')) {
            if (monthInt == 4) {
                multiplier = 0.9;
            } else if (monthInt == 5) {
                multiplier = 0.75;
            } else if (monthInt == 6) {
                multiplier = 0.6;
            } else if (monthInt == 7) {
                multiplier = 0.45;
            } else if (monthInt == 8) {
                multiplier = 0.3;
            } else if (monthInt == 9) {
                multiplier = 0.15;
            } else if (monthInt >= 10) {
                multiplier = 0;
            }
        }

        return multiplier;
    },
    getDays: function (sDate, eDate) {
        // To set two dates to two variables
        var startDate = new Date(sDate);
        var endDate = new Date(eDate);
        // To calculate the time difference of two dates
        var timeDifference = endDate.getTime() - startDate.getTime();
        // To calculate the no. of days between two dates
        var daysDifference = timeDifference / (1000 * 3600 * 24);
        return daysDifference;
    },
    getPolicyDefIndex: function (insPolDefs, selectedUnit, basisOfCover, $H) {
        var insuranceCategory = '';
        if (selectedUnit.Inventory_Item__r.Type__c == 'Lodge') {
            insuranceCategory = 'Lodge';
        } else if (selectedUnit.Inventory_Item__r.Type__c == 'Chalet') {
            insuranceCategory = 'Chalet';
        } else {
            insuranceCategory = selectedUnit.Inventory_Item__r.Width__c + 'ft';
        }
        let expectedValidationDate = new Date(selectedUnit.Presentation__r.CloseDate);
        let itemAge = selectedUnit.Age__c;
        var insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, selectedUnit.Presentation__r.Park__r.Park_Company__r.Name,
            selectedUnit.Presentation__r.Park__r.Name, basisOfCover, expectedValidationDate, itemAge);
        if (insPolDefIndex == -1) {
            insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, 'All Companies',
                selectedUnit.Presentation__r.Park__r.Name, basisOfCover, expectedValidationDate, itemAge);
            if (insPolDefIndex == -1) {
                insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', selectedUnit.Presentation__r.Park__r.Park_Company__r.Name,
                    selectedUnit.Presentation__r.Park__r.Name, basisOfCover, expectedValidationDate, itemAge);
                if (insPolDefIndex == -1) {
                    insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', 'All Companies',
                        selectedUnit.Presentation__r.Park__r.Name, basisOfCover, expectedValidationDate, itemAge);
                    if (insPolDefIndex == -1) {
                        insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, selectedUnit.Presentation__r.Park__r.Park_Company__r.Name,
                            'All Parks', basisOfCover, expectedValidationDate, itemAge);
                        if (insPolDefIndex == -1) {
                            insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, 'All Companies',
                                'All Parks', basisOfCover, expectedValidationDate, itemAge);
                            if (insPolDefIndex == -1) {
                                insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', 'All Companies',
                                    'All Parks', basisOfCover, expectedValidationDate, itemAge);
                                if (insPolDefIndex == -1) {
                                    insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', selectedUnit.Presentation__r.Park__r.Park_Company__r.Name,
                                        'All Parks', basisOfCover, expectedValidationDate, itemAge);
                                }
                            }
                        }
                    }
                }
            }
        }
        return insPolDefIndex;
    },
    getPolIndex: function (insPolDefs, insuranceCategory, parkCompany, parkName, basisOfCover, startDate, age) {
        if (basisOfCover == 'Market Value') {
            return insPolDefs.findIndex(polDef => polDef.Category__c === insuranceCategory
                && polDef.Company__c === parkCompany
                && polDef.Park__c === parkName
                && polDef.Basis_of_Cover__c === basisOfCover
                && new Date(polDef.Period_Charges_Applicable_To__c) >= startDate
                && new Date(polDef.Period_Charges_Applicable_From__c) <= startDate
                && polDef.Max_Unit_Age__c >= age
                && polDef.Minimum_Unit_Age__c <= age
            );
        }
        else return insPolDefs.findIndex(polDef => polDef.Category__c === insuranceCategory
            && polDef.Company__c === parkCompany && polDef.Park__c === parkName
            && polDef.Basis_of_Cover__c === basisOfCover
            && new Date(polDef.Period_Charges_Applicable_To__c) >= startDate
            && new Date(polDef.Period_Charges_Applicable_From__c) <= startDate
        );
    },
    getInsuranceDetails: function (selectedUnit, $C, $H) {
        var insPolDefs = $C.get('v.InsurancePolicyDefinitions');

        var newForOldIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'New For Old', $H);

        var newForOldInsProRataNetPrice = 0;
        var newForOldContentProRataNetPrice = 0;
        var alarmProRataNetPrice = 0;
        var newForOldId;
        var marketValueId;

        //New For Old - record found
        if (newForOldIndex != -1) {
            var insPolDef = insPolDefs[newForOldIndex];
            var insNumOfDays = ($H.getDays(selectedUnit.Presentation__r.CloseDate, insPolDef.Period_Charges_Applicable_To__c) + 1);
            var insTotalNumOfDays = ($H.getDays(insPolDef.Period_Charges_Applicable_From__c, insPolDef.Period_Charges_Applicable_To__c) + 1);
            newForOldInsProRataNetPrice = insNumOfDays * (insPolDef.Net_Selling_Price__c / insTotalNumOfDays);
            newForOldId = insPolDef.Id;

            if (insPolDef.Add_On__c) {
                newForOldContentProRataNetPrice = insNumOfDays * (insPolDef.Add_On__r.Net_Selling_Price__c / insTotalNumOfDays);
            }
            //Check the Alarm discount in PBE
            var alarmPBE = $C.get('v.AlarmPBE');
            if (alarmPBE) {
                var alarmIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'Alarm Discount', $H);
                if (alarmIndex != -1) {
                    var alarmPolDef = insPolDefs[alarmIndex];
                    alarmProRataNetPrice = insNumOfDays * (alarmPolDef.Net_Selling_Price__c / insTotalNumOfDays);
                }
            }
        }
        var marketValueIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'Market Value', $H);
        var marketValueInsProRataNetPrice = 0;
        var marketValueContentProRataNetPrice = 0;

        if (marketValueIndex != -1) {
            var insPolDef = insPolDefs[marketValueIndex];
            marketValueId = insPolDef.Id;
            var proRataNumOfDays = ($H.getDays(selectedUnit.Presentation__r.CloseDate, insPolDef.Period_Charges_Applicable_To__c) + 1);
            var insTotalNumOfDays = ($H.getDays(insPolDef.Period_Charges_Applicable_From__c, insPolDef.Period_Charges_Applicable_To__c) + 1);
            marketValueInsProRataNetPrice = proRataNumOfDays * (insPolDef.Net_Selling_Price__c / insTotalNumOfDays);
            //Market Value Content Price 
            if (insPolDef.Add_On__c) {
                marketValueContentProRataNetPrice = proRataNumOfDays * (insPolDef.Add_On__r.Net_Selling_Price__c / insTotalNumOfDays);
            }
        }

        //Total Insurance Price
        var totalInsPrice = newForOldInsProRataNetPrice + alarmProRataNetPrice;
        var insuranceDetails = {
            NewForOldInsProRataNetPrice: newForOldInsProRataNetPrice,
            AlarmProRataNetPrice: alarmProRataNetPrice,
            NewForOldId: newForOldId,
            MarketValueId: marketValueId,
            TotalInsPrice: totalInsPrice,
            NewForOldContentProRataNetPrice: newForOldContentProRataNetPrice,
            MarketValueInsProRataNetPrice: marketValueInsProRataNetPrice,
            MarketValueContentProRataNetPrice: marketValueContentProRataNetPrice
        };
        return insuranceDetails;
    },
    configurePitchFees: function (opp, pitchFees, loyaltyDiscount, rates, $H, $C) {

        var closeDate = opp.Expected_Handover_Date__c ? new Date(opp.Expected_Handover_Date__c) : new Date(opp.CloseDate);
        opp.ThisYear = closeDate.getFullYear() < new Date().getFullYear() ? new Date().getFullYear() : closeDate.getFullYear();
        opp.NextYear = opp.ThisYear + 1;

        var pitchCloseDateMonth = closeDate.getFullYear() < new Date().getFullYear() ? new Date().getMonth() : closeDate.getMonth();
        var rateCloseDateMonth = closeDate.getFullYear() < new Date().getFullYear() ? new Date().getMonth() : closeDate.getMonth();

        var pitchStartMonth = $H.getMonthInt(opp.Park__r.Pitch_Fee_Billing_Start_Date_Month__c);
        if (pitchStartMonth > pitchCloseDateMonth) {
            pitchCloseDateMonth += 12;
        }

        var pitchMonthIncrmt = pitchCloseDateMonth - pitchStartMonth;
        var pitchDayInt = closeDate.getDate();
        var rateStartMonth = $H.getMonthInt(opp.Park__r.Rate_Billing_Period_Start_Date_Month__c);

        console.log('rate start date month is ', rateStartMonth, ' rateCloseDateMonth ', rateCloseDateMonth);

        if (rateStartMonth > rateCloseDateMonth) {
            rateCloseDateMonth += 12;
        }

        var rateMonthIncrmt = rateCloseDateMonth - rateStartMonth;

        console.log('rateMonthIncrmt  = rateCloseDateMonth - rateStartMonth', rateMonthIncrmt);

        var ratesThisYear = 0;
        var ratesNextYear = 0;
        var ratesProducts = {};

        var pitchMultiplier = $H.getMultiplier(pitchMonthIncrmt, opp.Park__r.Park_Company_Name__c, pitchDayInt);

        $C.set('v.PitchMultiplier', pitchMultiplier);


        if (loyaltyDiscount.ThisYear) {
            var currentYearRefund = loyaltyDiscount.ThisYear * pitchMultiplier;
            loyaltyDiscount.ThisYearRefund = currentYearRefund;
        }

        if (loyaltyDiscount.NextYear) {
            loyaltyDiscount.NextYearRefund = loyaltyDiscount.NextYear;
        }

        pitchFees.forEach(function (fee) {

            var loyaltyDiscountAmt = loyaltyDiscount.Discount ? loyaltyDiscount.Discount : 0;

            var pitchBandingPrice = fee.UnitPrice - loyaltyDiscountAmt;
            // console.log('@@BEFORE LOYALTY',pitchBandingPrice,loyaltyDiscountAmt);      

            if (loyaltyDiscountAmt > 0){
                var vatRate = fee.Product2.VAT_Rate_Fx__c ? fee.Product2.VAT_Rate_Fx__c : 0;
                var pitchBandingVAT = (fee.UnitPrice / (100 + vatRate)) * vatRate;
                var pitchBandingNet = fee.UnitPrice - pitchBandingVAT;
                var discountedNet = pitchBandingNet - loyaltyDiscountAmt;
                pitchBandingPrice = discountedNet + (discountedNet * (vatRate / 100));
                console.log('@@AFTER LOYALTY',vatRate, pitchBandingVAT, pitchBandingNet, discountedNet, pitchBandingPrice);
            }

            // pitch fee products
            if (fee.Product_Name__c == 'Starter Pitch Fees This Year') {
                rates.StarterPitchFeeThisYear = pitchMultiplier != null ? pitchBandingPrice * pitchMultiplier : pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Standard Pitch Fees This Year') {
                rates.StandardPitchFeeThisYear = pitchMultiplier != null ? pitchBandingPrice * pitchMultiplier : pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Premium Pitch Fees This Year') {
                rates.PremiumPitchFeeThisYear = pitchMultiplier != null ? pitchBandingPrice * pitchMultiplier : pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Platinum Pitch Fees This Year') {
                rates.PlatinumPitchFeeThisYear = pitchMultiplier != null ? pitchBandingPrice * pitchMultiplier : pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Lodge Pitch Fees This Year') {
                rates.LodgePitchFeeThisYear = pitchMultiplier != null ? pitchBandingPrice * pitchMultiplier : pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Starter Pitch Fees Next Year') {
                rates.StarterPitchFeeNextYear = pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Standard Pitch Fees Next Year') {
                rates.StandardPitchFeeNextYear = pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Premium Pitch Fees Next Year') {
                rates.PremiumPitchFeeNextYear = pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Platinum Pitch Fees Next Year') {
                rates.PlatinumPitchFeeNextYear = pitchBandingPrice;
            } else if (fee.Product_Name__c == 'Lodge Pitch Fees Next Year') {
                rates.LodgePitchFeeNextYear = pitchBandingPrice;
            }

            // rates products
            if (fee.Product_Name__c == 'Business Rates This Year') {
                var rateAmount = rateMonthIncrmt != null && fee.UnitPrice ? $H.calcGeneralRates(fee.UnitPrice, rateMonthIncrmt) : 0;
                ratesThisYear += rateAmount;
                ratesProducts['THIS-YEAR::' + fee.Id] = rateAmount;
            } else if (fee.Product_Name__c == 'Business Rates Next Year') {
                var rateAmount = fee.UnitPrice ? fee.UnitPrice : 0;
                ratesNextYear += rateAmount;
                ratesProducts['NEXT-YEAR::' + fee.Id] = rateAmount;
            } else if (fee.Product_Name__c == 'Water & Sewage This Year') {
                var rateAmount = rateMonthIncrmt != null && fee.UnitPrice ? $H.calcGeneralRates(fee.UnitPrice, rateMonthIncrmt) : 0;
                ratesThisYear += rateAmount;
                ratesProducts['THIS-YEAR::' + fee.Id] = rateAmount;
            } else if (fee.Product_Name__c == 'Water & Sewage Next Year') {
                var rateAmount = fee.UnitPrice ? fee.UnitPrice : 0;
                ratesNextYear += rateAmount;
                ratesProducts['NEXT-YEAR::' + fee.Id] = rateAmount;
            } else if (fee.Product_Name__c == 'Refuse This Year') {
                var rateAmount = rateMonthIncrmt != null && fee.UnitPrice ? $H.calcGeneralRates(fee.UnitPrice, rateMonthIncrmt) : 0;
                ratesThisYear += rateAmount;
                ratesProducts['THIS-YEAR::' + fee.Id] = rateAmount;
            } else if (fee.Product_Name__c == 'Refuse Next Year') {
                var rateAmount = fee.UnitPrice ? fee.UnitPrice : 0;
                ratesNextYear += rateAmount;
                ratesProducts['NEXT-YEAR::' + fee.Id] = rateAmount;
            }
        });

        rates.RatesThisYear = ratesThisYear;
        rates.RatesNextYear = ratesNextYear;
        rates.RatesProducts = ratesProducts;

        if (loyaltyDiscount.RatesThisYear) {
            loyaltyDiscount.ThisYearRatesRefund = ratesThisYear;
        }

        if (loyaltyDiscount.RatesNextYear) {
            loyaltyDiscount.NextYearRatesRefund = loyaltyDiscount.RatesNextYear;
        }
    },
    processPitchSelections: function ($C, pitchSelections, pitchSelectionItems, pitchPromotions, accountId) {

        var rates = $C.get('v.Rates');

        pitchSelections.forEach(function (pitch) {

            var available = pitch.Available__c;
            var primary = pitch.Primary__c;

            if (pitchSelectionItems[pitch.Pitch__c]) {
                delete pitchSelectionItems[pitch.Pitch__c].Id;
                Object.assign(pitch, pitch, pitchSelectionItems[pitch.Pitch__c]);

                pitch.Available__c = available;
                pitch.Primary__c = primary;

                if (pitch.Banding__c) {
                    if (rates[pitch.Banding__c + 'PitchFeeThisYear'] != null) {
                        pitch.Price = rates[pitch.Banding__c + 'PitchFeeThisYear'];
                    }
                    if (rates[pitch.Banding__c + 'PitchFeeNextYear'] != null) {
                        pitch.PriceNextYear = rates[pitch.Banding__c + 'PitchFeeNextYear'];
                    }
                }

                pitch.Promotions = [];
                if (pitchPromotions && pitchPromotions.length) {
                    pitchPromotions.forEach(function (promo) {
                        if (promo.Pitch_Numbers__c.includes(pitch.Pitch__r.Name)) {
                            pitch.Promotions.push(promo);
                        }
                    });
                }
            }
        });
    },
    configureUnitFilters: function ($C, opp, inventoryItems) {

        var unitFilters = $C.get('v.UnitFilters');
        var unitSettings = $C.get('v.UnitSettings');

        if (!unitFilters) {
            unitFilters = {};
        }

        var Locations = [opp.Park__r.Name]; //, opp.Park__r.Region__c];

        var regions = $C.get('v.Regions');

        if (regions) {
            Array.prototype.push.apply(Locations, regions);
        }

        Locations.push('Manufacturer');

        var Manufacturer = new Set();
        var defaultManufacturer;
        var Model = new Set();
        var ModelsTemp = new Set();
        var defaultModel;
        var Onwership = new Set();
        var Statuses = new Set();
        var HomeTypes = new Set();
        var Prices = new Set();
        var Widths = new Set();
        var Lengths = new Set();
        var Bedrooms = new Set();
        var Berths = new Set();
        var Age = new Set();

        inventoryItems.forEach(function (item) {
            if (item.Manufacturer__c) Manufacturer.add(item.Manufacturer__c);
            if (!defaultManufacturer) defaultManufacturer = item.Manufacturer__c;
            if (item.Model__c && !ModelsTemp.has(item.Model__c)) Model.add({ Name: item.Model__c, Manufacturer: item.Manufacturer__c }); // THIS ONE NEEDS TO BE AN OBJECT
            if (item.Model__c) ModelsTemp.add(item.Model__c);
            if (!defaultModel && item.Manufacturer__c == defaultManufacturer) defaultModel = item.Model__c;
            if (item.Ownership_FX__c) Onwership.add(item.Ownership_FX__c);
            if (item.Usage_State__c) Statuses.add(item.Usage_State__c);
            if (item.Type__c) HomeTypes.add(item.Type__c);
            if (item.Total_Sales_Price__c) Prices.add((item.Total_Sales_Price__c / 5000).toFixed() * 5000);
            if (item.Width__c) Widths.add(item.Width__c);
            if (item.Length__c) Lengths.add(item.Length__c);
            if (item.Bedrooms__c) Bedrooms.add(item.Bedrooms__c);
            if (item.Berths__c) Berths.add(item.Berths__c);
            if (item.Age__c) Age.add(parseInt(item.Age__c));
        });

        unitFilters.Locations = unitFilters.Locations ? unitFilters.Locations : Locations;
        unitFilters.Manufacturer = Array.from(Manufacturer).sort();
        unitFilters.Model = Array.from(Model).sort();
        unitFilters.Onwership = Array.from(Onwership).sort();
        unitFilters.Statuses = Array.from(Statuses).sort();
        unitFilters.HolidayHomeTypes = Array.from(HomeTypes).sort();
        unitFilters.PriceFrom = Array.from(Prices).sort();
        unitFilters.PriceTo = Array.from(Prices).sort();
        unitFilters.WidthFrom = Array.from(Widths).sort();
        unitFilters.WidthTo = Array.from(Widths).sort();
        unitFilters.LengthFrom = Array.from(Lengths).sort();
        unitFilters.LengthTo = Array.from(Lengths).sort();
        unitFilters.Bedrooms = Array.from(Bedrooms).sort();
        unitFilters.Berths = Array.from(Berths).sort();
        unitFilters.Accessibility = ['Yes', 'No'];
        unitFilters.Age = Array.from(Age).sort();

        $C.set('v.UnitFilters', unitFilters);
        $C.set('v.UnitSettings', {
            Location: unitSettings ? unitSettings.Location : opp.Park__r.Name,
            Manufacturer: 'Any', //unitSettings && unitSettings.Location == 'Manufacturer' ? defaultManufacturer : 'Any',
            Model: 'Any', // unitSettings && unitSettings.Location == 'Manufacturer' ? defaultModel : 'Any',
            Onwership: 'Any',
            Status: 'Any',
            HolidayHomeType: 'Any',
            PriceFrom: 'Any',
            PriceTo: 'Any',
            WidthFrom: 'Any',
            WidthTo: 'Any',
            LengthFrom: 'Any',
            LengthTo: 'Any',
            Bedrooms: 'Any',
            Berths: 'Any',
            Accessibility: 'Any',
            Age: 'Any',
        });
    },
    configurePitchFilters: function ($C, pitches) {

        var pitchFilters = {};

        var Status = new Set();
        var Banding = new Set();
        var Area = new Set();
        var View = new Set();

        pitches.forEach(function (pitch) {
            if (pitch.Search_Status__c) Status.add(pitch.Search_Status__c);
            if (pitch.Banding__c) Banding.add(pitch.Banding__c);
            if (pitch.Areas__r.Name) Area.add(pitch.Areas__r.Name);
            if (pitch.View__c) View.add(pitch.View__c);
        });

        pitchFilters.Status = Array.from(Status);
        pitchFilters.Banding = Array.from(Banding).sort();
        pitchFilters.Area = Array.from(Area).sort();
        pitchFilters.View = Array.from(View).sort();

        $C.set('v.PitchFilters', pitchFilters);
        $C.set('v.PitchSettings', {
            Status: 'Vacant',
            Banding: 'Any',
            Area: 'Any',
            View: 'Any'
        });
    },
    loadPXFilters: function ($C) {

        var activeBuyIn = $C.get('v.ActiveBuyIn');

        var pxFilters = {};

        pxFilters.Year = [];
        pxFilters.Length = [];
        pxFilters.Width = [];
        pxFilters.Bedrooms = [];
        pxFilters.Models = [];

        var loadPXMakesApex = $C.get('c.loadPXMakesApex');
        loadPXMakesApex.setCallback(this, function (response) {
            if (response.getState() === 'SUCCESS') {
                $C.set('v.PXFiltersLoaded', true);
                pxFilters.Make = response.getReturnValue();

                var buyInMake = '';

                pxFilters.Make.forEach(function (make) {
                    if (make == activeBuyIn.Make__c) {
                        buyInMake = activeBuyIn.Make__c;
                    }
                });

                $C.set('v.PXFilters', pxFilters);
                $C.set('v.PXSettings', {
                    Make: buyInMake,
                    Model: '',
                    Year: '',
                    Bedrooms: '',
                    Length: '',
                    Width: '',
                });

                if (buyInMake) {
                    $A.enqueueAction($C.get('c.getPXValuations'));
                }
            }
        });

        $A.enqueueAction(loadPXMakesApex);

    },
    evalPromoCompatibility: function (salePromotions, stockPromtions, subscriptionPromotions) {

        var salePromos = salePromotions;
        var subscriptionPromos = subscriptionPromotions;
        var stockPromos = [];

        Object.keys(stockPromtions).forEach(function (promoId) {
            stockPromos.push(stockPromtions[promoId]);
        });

        salePromos.forEach(function (promo) {
            var incompatiblePromos = '';
            if (promo.Promotion_Outputs__r && promo.Promotion_Outputs__r.length) {
                promo.Promotion_Outputs__r.forEach(function (output) {
                    // if (output.Exclusive__c) {
                    salePromos.forEach(function (otherPromo) {
                        if (!incompatiblePromos.includes(otherPromo.Id)) {
                            if (otherPromo.Id !== promo.Id) {
                                if (otherPromo.Promotion_Outputs__r && otherPromo.Promotion_Outputs__r.length) {
                                    otherPromo.Promotion_Outputs__r.forEach(function (otherOutput) {
                                        if (otherOutput.RecordTypeId === output.RecordTypeId) {
                                            if (output.Output_Type__c == 'Pitch Fees') {
                                                if (output.Output_Type__c == otherOutput.Output_Type__c && output.Year__c == otherOutput.Year__c) {
                                                    incompatiblePromos += otherPromo.Id + ' ';
                                                }
                                            } else if (output.Output_Type__c == 'Product Giveaway') {
                                                if (output.Product__c == otherOutput.Product__c) {
                                                    incompatiblePromos += otherPromo.Id + ' ';
                                                }
                                            } else {
                                                incompatiblePromos += otherPromo.Id + ' ';
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    });
                    stockPromos.forEach(function (otherPromo) {
                        if (!incompatiblePromos.includes(otherPromo.Id)) {
                            if (otherPromo.Id !== promo.Id) {
                                if (otherPromo.Promotion_Outputs__r && otherPromo.Promotion_Outputs__r.length) {
                                    otherPromo.Promotion_Outputs__r.forEach(function (otherOutput) {
                                        if (otherOutput.RecordTypeId === output.RecordTypeId) {
                                            incompatiblePromos += otherPromo.Id + ' ';
                                        }
                                    });
                                }
                            }
                        }
                    });
                    subscriptionPromos.forEach(function (otherPromo) {
                        if (!incompatiblePromos.includes(otherPromo.Id)) {
                            if (output.Output_Type__c === 'Pitch Fees' && output.Subscription_Year__c == otherPromo.Year__c) {
                                incompatiblePromos += otherPromo.Id + ' ';
                            }
                        }
                    });
                    // }
                });
            }

            promo.IncompatiblePromos = incompatiblePromos;
        });

        stockPromos.forEach(function (promo) {
            var incompatiblePromos = '';
            if (promo.Promotion_Outputs__r && promo.Promotion_Outputs__r.length) {
                promo.Promotion_Outputs__r.forEach(function (output) {
                    if (output.Exclusive__c) {
                        salePromos.forEach(function (otherPromo) {
                            if (!incompatiblePromos.includes(otherPromo.Id)) {
                                if (otherPromo.Id !== promo.Id) {
                                    if (otherPromo.Promotion_Outputs__r && otherPromo.Promotion_Outputs__r.length) {
                                        otherPromo.Promotion_Outputs__r.forEach(function (otherOutput) {
                                            if (otherOutput.RecordTypeId === output.RecordTypeId) {
                                                incompatiblePromos += otherPromo.Id + ' ';
                                            }
                                        });
                                    }
                                }
                            }
                        });
                    }
                });
            }

            promo.IncompatiblePromos = incompatiblePromos;
        });

        subscriptionPromotions.forEach(function (promo) {
            var incompatiblePromos = '';

            salePromos.forEach(function (otherPromo) {
                if (!incompatiblePromos.includes(otherPromo.Id)) {
                    if (otherPromo.Id !== promo.Id) {
                        if (otherPromo.Promotion_Outputs__r && otherPromo.Promotion_Outputs__r.length) {
                            otherPromo.Promotion_Outputs__r.forEach(function (otherOutput) {
                                if (otherOutput.Output_Type__c === 'Pitch Fees' && otherOutput.Subscription_Year__c == promo.Year__c) {
                                    incompatiblePromos += otherPromo.Id + ' ';
                                }
                            });
                        }
                    }
                }
            });

            promo.IncompatiblePromos = incompatiblePromos;
        });
    },
    evalUnitPromos: function (invItem, promos) {
        promos.forEach(function (promo) {

            var compatible = true;

            if (invItem.SalePromotions.length) {
                invItem.SalePromotions.forEach(function (relatedPromo) {
                    if (relatedPromo.Record_Type__c === 'Stock_Promotion') {
                        if (relatedPromo.IncompatiblePromos.includes(promo.Id)) {
                            compatible = false;
                        }
                    }
                });
            }

            if (compatible) {

                var model = !promo.Models__c || (invItem.Model__c && promo.Models__c.includes(invItem.Model__c.toString()));
                var modelYears = !promo.Model_Years__c || (invItem.Model_Year__c && promo.Model_Years__c.includes(invItem.Model_Year__c.toString()));
                var usageStatus = !promo.Usage_Status__c || (invItem.Usage_State__c && promo.Usage_Status__c.includes(invItem.Usage_State__c.toString()));
                var unitType = !promo.Unit_Type__c || (invItem.Type__c && promo.Unit_Type__c.includes(invItem.Type__c.toString()));
                var daysFrom = !promo.Days_In_Stock_From__c || invItem.Days_In_Stock__c >= promo.Days_In_Stock_From__c;
                var daysTo = !promo.Days_In_Stock_To__c || invItem.Days_In_Stock__c <= promo.Days_In_Stock_To__c;
                var sivFrom = !promo.SIV_From__c || invItem.SIV__c >= promo.SIV_From__c;
                var sivTo = !promo.SIV_To__c || invItem.SIV__c <= promo.SIV_To__c;
                var serialNos = !promo.Serial_Numbers__c || (invItem.SN_Fx__c && promo.Serial_Numbers__c.includes(invItem.SN_Fx__c.toString()));
                console.log('x-model', 'Promo: ' + promo.Models__c, 'Inv Item: ' + invItem.Model__c, model);

                if (model && modelYears && usageStatus && unitType && daysFrom && daysTo && sivFrom && sivTo && serialNos) {
                    if (!promo.Pitch_Numbers__c) {
                        invItem.SalePromotions.push(promo);
                    } else {
                        invItem.PitchPromotions.push(promo);
                    }
                }
            }
        });
    },
    getTenure: function (invItem, opp) {

        var caravanMin = opp.Park__r.Caravan_Minimum_Tenure_Years__c;
        var caravanMax = opp.Park__r.Caravan_Maximum_Tenure_Years__c;
        var lodgeMin = opp.Park__r.Lodge_Minimum_Tenure_Years__c;
        var lodgeMax = opp.Park__r.Lodge_Maximum_Tenure_Years__c;

        if (invItem.Type__c == 'Caravan') {
            if (invItem.Usage_State__c == 'New') {
                invItem.Tenure = caravanMax;
                invItem.TenureCalculation = 'Maximum tenure for caravans at ' + opp.Park__r.Name + ' (' + caravanMax + ')';
            } else {
                if (caravanMax - invItem.Age__c > caravanMin) {
                    invItem.Tenure = caravanMax - invItem.Age__c;
                    invItem.TenureCalculation = 'Maximum tenure for caravans at ' + opp.Park__r.Name + ' (' + caravanMax + ')' +
                        ', less holiday home age (' + invItem.Age__c +
                        (invItem.Age__c == 1 ? ' year)' : ' years)');
                } else {
                    invItem.Tenure = caravanMin;
                    invItem.TenureCalculation = 'Minumum tenure for caravans at ' + opp.Park__r.Name + ' (' + caravanMin + ')';
                }
            }
        } else if (invItem.Type__c == 'Lodge') {
            if (invItem.Usage_State__c == 'New') {
                invItem.Tenure = lodgeMax;
                invItem.TenureCalculation = 'Maximum tenure for lodges at ' + opp.Park__r.Name + ' (' + lodgeMax + ')';
            } else {
                if (lodgeMax - invItem.Age__c > lodgeMin) {
                    invItem.Tenure = lodgeMax - invItem.Age__c;
                    invItem.TenureCalculation = 'Maximum tenure for lodges at ' + opp.Park__r.Name + ' (' + lodgeMax + ')' +
                        ', less holiday home age (' + invItem.Age__c +
                        (invItem.Age__c == 1 ? ' year)' : ' years)');
                } else {
                    invItem.Tenure = lodgeMin;
                    invItem.TenureCalculation = 'Minumum tenure for lodges at ' + opp.Park__r.Name + ' (' + lodgeMin + ')';
                }
            }
        }
    },
    calcGeneralRates: function (unitPrice, monthInt) {
        console.log('calc general rates', unitPrice, monthInt);

        var remainingMonthInt = 12 - (monthInt + 1);
        var adjustedPrice = (unitPrice / 12 * (remainingMonthInt + 1));
        console.log('calc general rates', unitPrice, monthInt, adjustedPrice);
        return adjustedPrice;
    },
    clearBuyInForm: function ($C) {

        $C.find('type').set('v.value', '');
        $C.find('make').set('v.value', '');
        $C.find('model').set('v.value', '');
        $C.find('year').set('v.value', '');
        $C.find('bedrooms').set('v.value', '');
        $C.find('length').set('v.value', '');
        $C.find('width').set('v.value', '');

    },
    showQuoteResponse: function (response) {

        var content = response.getReturnValue();

        if (response.getState() === 'SUCCESS' && !content.startsWith('error')) {
            $A.get("e.force:showToast").setParams({
                "title": "Success!",
                "type": "success",
                "message": "Quote created"
            }).fire();
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({ "recordId": content });
            navEvt.fire();
        } else {
            $A.get("e.force:showToast").setParams({
                "title": "Error!",
                "type": "error",
                "message": response.getReturnValue()
            }).fire();
        }
    },

    /** 
    * build table data based on current page selection 
    */
    buildData : function(component, helper) {
        var pendingPriceIds = component.get('v.PendingPriceIds');

        let data = [];
        let pageNumber = component.get("v.currentPageNumber");
        let pageSize = component.get("v.pageSize");
        let allData = component.get("v.AvailableInventoryItems");
        let x = (pageNumber-1)*pageSize;
        
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++) {
            if(allData[x]) {
                data.push(allData[x]);

                if (allData[x].In_Simulation__c) {
                    pendingPriceIds.push(allData[x].Id);
                }
            }
        }
        console.log('VisibleInventoryItems: ', data);
        component.set("v.VisibleInventoryItems", data);

        console.log('pendingPriceIds.length: ', pendingPriceIds.length);
        if (pendingPriceIds.length) {
            helper.pollInventoryItems(component, helper);
        }
        
        helper.generatePageList(component, pageNumber);
    },

    /** 
     * generate page list
    */
    generatePageList : function(component, pageNumber) {
        pageNumber = parseInt(pageNumber);
        let pageList = [];
        let totalPages = component.get("v.totalPages");
        if(totalPages > 1) {
            if(totalPages <= 10){
                let counter = 2;
                for(; counter < (totalPages); counter++) {
                    pageList.push(counter);
                } 
            } else{
                if(pageNumber < 5) {
                    pageList.push(2, 3, 4, 5, 6);
                } else{
                    if(pageNumber>(totalPages-5)) {
                        pageList.push(totalPages-5, totalPages-4, totalPages-3, totalPages-2, totalPages-1);
                    } else{
                        pageList.push(pageNumber-2, pageNumber-1, pageNumber, pageNumber+1, pageNumber+2);
                    }
                }
            }
        }
        component.set("v.pageList", pageList);
    },

    pollInventoryItems: function ($C, $H) {

        console.log('POLL CALLED');
        $C.set('v.Polling', true);
        var pendingPriceIds = $C.get('v.PendingPriceIds');

        if (pendingPriceIds.length) {

            var opportunity = $C.get('v.Opportunity');
            var pollInventoryApex = $C.get('c.pollInventoryApex');
            pollInventoryApex.setParams({ parkId: opportunity.Park__c, inventoryIds: pendingPriceIds });
            pollInventoryApex.setCallback(this, function (response) {

                var parkPrices = response.getReturnValue();

                if (parkPrices.length) {

                    var inventoryItems = $C.get('v.VisibleInventoryItems');

                    parkPrices.forEach(function (parkPrice) {
                        var invItem = JSON.parse(parkPrice.State__c);
                        invItem.In_Simulation__c = false;
                        delete invItem.Quote_Lines_Holiday_Home__r;
                        delete invItem.Location__r.Name;

                        if (pendingPriceIds.indexOf(invItem.Id) != 1) {

                            for (var x = 0; x < inventoryItems.length; x++) {
                                if (inventoryItems[x].Id == invItem.Id) {
                                    var mergedItem = Object.assign(inventoryItems[x], invItem);
                                    mergedItem.In_Simulation__c = false;
                                    inventoryItems[x] = mergedItem;
                                    inventoryItems[x].Location__r.Name = inventoryItems[x].Simulation_Origin__c;
                                }
                            }

                            pendingPriceIds.splice(pendingPriceIds.indexOf(invItem.Id), 1);
                        }
                    });

                    $C.set('v.PendingPriceIds', pendingPriceIds);
                    $C.set('v.VisibleInventoryItems', inventoryItems);
                }

                if (pendingPriceIds.length) {
                    window.setTimeout(
                        $A.getCallback(function () {
                            $H.pollInventoryItems($C, $H);
                        }), 5000
                    );
                } else {
                    console.log('POLL TERMINATED');
                }
            });
            $A.enqueueAction(pollInventoryApex);
        } else {
            console.log('POLL TERMINATED');
        }
    },

    processSelectedUnit: function($C, $E, $H) {
        let defaultImage    = $C.get('v.DefaultImage');
        let unitSettings    = $C.get('v.UnitSettings');
        let unitSelections  = $C.get('v.UnitSelections');
        let inventoryItems  = $C.get('v.InventoryItems');
        let unitIndex;
        let unitId;
        const inventoryItem   = $C.get('v.CurrentSelectedUnit');

        let i = 0;
        for(i; i < inventoryItems.length; i++) {
            if(inventoryItems[i].Id === inventoryItem.Id) {
                unitIndex = i;
                unitId = inventoryItem.Id;
            }
        }

        console.info('unitIndex: ', unitIndex);
        console.info('unitId: ', unitId);

        if(unitIndex == null || !unitId) {
             $A.get("e.force:showToast").setParams({ "title": "Error", "type": "error", "message": `There was an error processing your selection. Please contact the IT department`}).fire();
             return;
        }

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Adding holiday home to your selections...');

        var opportunity = $C.get('v.Opportunity');

        var target = {};
        var itemState = Object.assign(target, inventoryItems[unitIndex]);
        itemState.IncludeTransport = unitSettings.Location != opportunity.Park__r.Name && unitSettings.Location != 'Manufacturer';
        delete itemState.Id;
        var unitJSON = JSON.stringify(itemState);

        var selectUnitApex = $C.get('c.selectUnitApex');

        selectUnitApex.setParams({
            unitId: unitId,
            unitJSON: unitJSON,
            recordId: $C.get('v.recordId'),
            locationId: opportunity.Park__c, accountId: opportunity.AccountId,
            stageName: opportunity.StageName
        });
        selectUnitApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');
            if (response.getState() === 'SUCCESS') {

                console.log('unit selection response', response.getReturnValue());

                if (response.getReturnValue().UnitSelections) {

                    var newUnitSelections = response.getReturnValue().UnitSelections;
                    var pitchSelectionItems = response.getReturnValue().PitchSelectionItems;

                    inventoryItems[unitIndex].Selected = true;
                    $C.set('v.InventoryItems', inventoryItems);

                    var unitSelection = newUnitSelections[0];
                    delete unitSelection.Inventory_Item__r.Id;

                    var inventoryItemClone = JSON.parse(JSON.stringify(inventoryItems[unitIndex]));
                    delete inventoryItemClone.Id;

                    Object.assign(unitSelection, unitSelection, inventoryItemClone);
                    $H.getTenure(unitSelection, $C.get('v.Opportunity'));

                    if (unitSelection.Stock_Images__r && unitSelection.Stock_Images__r.length) {
                        unitSelection.ActiveIndex = 0;
                    } else {
                        unitSelection.Thumbnail_Image__c = defaultImage;
                    }

                    if (unitSelection.Pitch_Selections__r && unitSelection.Pitch_Selections__r.length) {
                        $H.processPitchSelections($C, unitSelection.Pitch_Selections__r, pitchSelectionItems, inventoryItems[unitIndex].PitchPromotions);
                    }

                    unitSelections.push(unitSelection);

                    delete unitSelection.State__c;
                    var unitJSON = JSON.stringify(unitSelection);
                    unitSelection.State__c = unitJSON;

                    var updateSelectionStateApex = $C.get('c.updateSelectionStateApex');
                    updateSelectionStateApex.setParams({ selectionId: unitSelection.Id, unitJSON: unitJSON });
                    updateSelectionStateApex.setCallback(this, function (response) {
                        console.log(response.getReturnValue());
                    });
                    $A.enqueueAction(updateSelectionStateApex);

                    $C.set('v.UnitSelections', unitSelections);
                    $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "Unit selection added" }).fire();
                    $A.get('e.force:refreshView').fire();

                    // delete from visible items
                    let visibleInventoryItems  = $C.get('v.VisibleInventoryItems');
                    for(var x = 0; x < visibleInventoryItems.length; x++) {
                        if ( visibleInventoryItems[x].Id === inventoryItem.Id) {
                            visibleInventoryItems.splice(x, 1);
                        }
                    }
                    $C.set('v.VisibleInventoryItems', visibleInventoryItems);
                } else {
                    $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getReturnValue() }).fire();
                }
            } else {
                $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getState() }).fire();
            }
            // set CurrentSelectedUnit as null
            $C.set('v.CurrentSelectedUnit', null);
        });
        $A.enqueueAction(selectUnitApex);
    }
})