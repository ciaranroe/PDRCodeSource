({
    doInit: function ($C, $E, $H) {

        var getContentApex = $C.get('c.getContentApex');
        getContentApex.setParams({ recordId: $C.get('v.recordId') });
        getContentApex.setCallback(this, function (response) {

            console.log('c.getContentApex',response.getState(),response.getReturnValue());
            if (response.getState() === 'SUCCESS') {

                var defaultImage = $C.get('v.DefaultImage');
                var selectionIds = [];

                var content = response.getReturnValue();

                var info = {};
                Object.assign(info, info, content);

                var locations = [];
                var opp = content.Opportunity;

                $C.set('v.Opportunity', opp);
                $C.set('v.SelectionsEditable', opp.Selections_Editable__c);
                $C.set('v.SelectionsEditablePerm', opp.Selections_Editable__c);
                $C.set('v.IncludeNextYearPitchFees', opp.Park__r.Next_Year_Pitch_Fees__c != 'Unavailable');
                $C.set('v.RequireNextYearPitchFees', opp.Park__r.Next_Year_Pitch_Fees__c == 'Required');
                $C.set('v.IncludeNextYearRates', opp.Park__r.Next_Year_Rates__c != 'Unavailable');
                $C.set('v.RequireNextYearRates', opp.Park__r.Next_Year_Rates__c == 'Required');
                $C.set('v.LoyaltyDiscount', content.LoyaltyDiscount);
                $C.set('v.PricebookEntries', content.PricebookEntries);

                var rates = $H.getRates($C);

                if (opp.Selections_Editable__c) {

                    if (content.ParkTarget && content.ParkTarget.length) $C.set('v.ParkTarget', content.ParkTarget[0]);
                    if (content.CommissionBands) $C.set('v.CommissionBands', content.CommissionBands);

                    if (content.PitchFees && content.PitchFees.length) {
                        $H.configurePitchFees(opp, content.PitchFees, content.LoyaltyDiscount, rates, $H, $C);
                        console.log('after configure pitch fees', content.LoyaltyDiscount);
                        $C.set('v.LoyaltyDiscount', content.LoyaltyDiscount);
                    }

                    if (!content.SalePromotions) content.SalePromotions = [];
                    if (!content.StockPromotions) content.StockPromotions = [];
                    if (!content.SubscriptionPromotions) content.SubscriptionPromotions = [];

                    $H.evalPromoCompatibility(content.SalePromotions, content.StockPromotions, content.SubscriptionPromotions);

                    console.log('after eval promos');

                    $C.set('v.SalePromotions', content.SalePromotions);
                    $C.set('v.StockPromotions', content.StockPromotions);
                    $C.set('v.SubscriptionPromotions', content.SubscriptionPromotions);

                    if (content.CaravanAncillaries) $C.set('v.CaravanAncillaries', content.CaravanAncillaries);
                    if (content.LodgeAncillaries) $C.set('v.LodgeAncillaries', content.LodgeAncillaries);
                    if (content.PitchMoveAncillaries) $C.set('v.PitchMoveAncillaries', content.PitchMoveAncillaries);
                    if (content.InsurancePolicyDefinitions) $C.set('v.InsurancePolicyDefinitions', content.InsurancePolicyDefinitions);
                    if (content.AlarmPBE) $C.set('v.AlarmPBE', content.AlarmPBE);

                    if (content.Opportunity && content.Opportunity.Park__r.Pitch_Locations__c) {
                        locations = JSON.parse(content.Opportunity.Park__r.Pitch_Locations__c);
                    }
                }

                $C.set('v.Rates', rates);
                console.log('after set rates');

                if (content.BuyIns) {

                    var RetainedDeckPXId;

                    content.BuyIns.forEach(function (buyIn) {
                        buyIn.Configuring = false;

                        if (!buyIn.Include_Decking__c && !RetainedDeckPXId){
                            RetainedDeckPXId = buyIn.Id;
                        } else {
                            buyIn.Include_Decking__c = true;
                        }
                    });

                    $C.set('v.BuyIns', content.BuyIns);
                    $C.set('v.RetainedDeckPXId',RetainedDeckPXId);
                }


                if (content.UnitSelections) {
                    content.UnitSelections.forEach(function (item) {

                        selectionIds.push(item.Inventory_Item__c);

                        if (item.Inventory_Item__r && item.Inventory_Item__r.Id && content.SelectionItems[item.Inventory_Item__r.Id]){
                            delete content.SelectionItems[item.Inventory_Item__r.Id].Id;
                        }

                        var invItem;
                        var useState    = item.Use_State__c || !opp.Selections_Editable__c;
                        var expired     = item.Expired__c;
                        var available   = item.Available__c;
                        var primary     = item.Primary__c;
                        var primaryPitchId;

                        console.log('===> 1');
                        if (item.Pitch_Selections__r) {
                            item.Pitch_Selections__r.forEach(function (pitchSelection) {
                                if (pitchSelection.Primary__c) {
                                    primaryPitchId = pitchSelection.Id;
                                }
                            });
                        }

                        console.log('===> 2');
                        if (useState && item.State__c) {

                            console.log('useState');
                            invItem = JSON.parse(item.State__c);
                            invItem.Expired__c = expired;
                            invItem.Available__c = available;
                            invItem.Primary__c = primary;

                            if (invItem.Pitch_Selections__r) {
                                invItem.Pitch_Selections__r.forEach(function (pitchSelection) {
                                    if (pitchSelection.Id == primaryPitchId) {
                                        pitchSelection.Primary__c = true;
                                    }
                                });
                            }

                            if (invItem.SalePromotions && invItem.SalePromotions.length) {
                                invItem.PromotionStatus = invItem.SalePromotions.length == 1 ? '1 promotion available' : invItem.SalePromotions.length + ' promotions available';
                            }
                        } else if (item.Inventory_Item__r && item.Inventory_Item__r.Id && content.SelectionItems[item.Inventory_Item__r.Id]) {
                            console.log('TAKE ' + item.Inventory_Item__r.Id);
                            invItem = content.SelectionItems[item.Inventory_Item__r.Id];
                        }

                        console.log('===> 3',invItem);
                        if (invItem) {
                            console.log('ASSIGN');
                            Object.assign(item, item, invItem);
                        }

                        console.log('===> 4');
                        if (item.Stock_Images__r && item.Stock_Images__r.length) {
                            item.ActiveIndex = 0;
                        } else {
                            item.Thumbnail_Image__c = defaultImage;
                        }

                        console.log('===> 5');

                        if (!useState) {

                            console.log('===> 5.1');
                            $H.getTenure(item, opp);

                            item.SalePromotions = [];
                            item.PitchPromotions = [];

                            if (item.Promotion_Adjustments__r && item.Promotion_Adjustments__r.length) {
                                item.Promotion_Adjustments__r.forEach(function (promo) {
                                    if (content.StockPromotions && content.StockPromotions[promo.Promotion_Output__r.Promotion__c]) {
                                        item.SalePromotions.push(content.StockPromotions[promo.Promotion_Output__r.Promotion__c]);
                                    }
                                });
                            }

                            if (content.SalePromotions && content.SalePromotions.length) {
                                console.log('======>',item);
                                $H.evalUnitPromos(item, content.SalePromotions);
                            }

                            if (item.SalePromotions.length) {
                                item.PromotionStatus = item.SalePromotions.length == 1 ? '1 promotion available' : item.SalePromotions.length + ' promotions available';
                            }

                            if (item.Pitch_Selections__r && item.Pitch_Selections__r.length) {
                                $H.processPitchSelections($C, item.Pitch_Selections__r, content.PitchSelectionItems, item.PitchPromotions);
                            }
                            console.log('===> 5.2');
                        }

                        console.log('===> 6');
                        if (item.Primary__c) {
                            $C.set('v.PrimarySelection', item);
                            if (item.Pitch_Selections__r && item.Pitch_Selections__r.length) {
                                item.Pitch_Selections__r.forEach(function (pitch) {
                                    if (pitch.Primary__c || item.Pitch_Selections__r.length == 1) {
                                        $C.set('v.PrimaryPitch', pitch);
                                    }
                                });
                            }
                        }
                    });

                    console.log('setting unit seelctions',content.UnitSelections);

                    $C.set('v.UnitSelections', content.UnitSelections);
                }

                if (opp.Selections_Editable__c) {
                    if (content.InventoryItems) {

                        $C.set('v.Regions', content.Regions);

                        $H.configureUnitFilters($C, opp, content.InventoryItems);

                        content.InventoryItems.forEach(function (item) {
                            $H.getTenure(item, opp);
                            item.SalePromotions = [];
                            item.PitchPromotions = [];

                            if (item.Promotion_Adjustments__r && item.Promotion_Adjustments__r.length) {
                                item.Promotion_Adjustments__r.forEach(function (promo) {
                                    if (content.StockPromotions && content.StockPromotions[promo.Promotion_Output__r.Promotion__c]) {
                                        item.SalePromotions.push(content.StockPromotions[promo.Promotion_Output__r.Promotion__c]);
                                    }
                                });
                            }

                            if (content.SalePromotions.length) {
                                $H.evalUnitPromos(item, content.SalePromotions);

                                if (item.SalePromotions.length) {
                                    item.PromotionStatus = item.SalePromotions.length == 1 ? '1 promotion available' : item.SalePromotions.length + ' promotions available';
                                }
                            }

                            item.Selected = selectionIds.includes(item.Id);
                            item.Show = true;

                            if (item.Stock_Images__r && item.Stock_Images__r.length) {
                                item.ActiveIndex = 0;
                            } else {
                                item.Thumbnail_Image__c = defaultImage;
                            }
                        });

                        $C.set('v.InventoryItems', content.InventoryItems);
                    }

                    if (content.Pitches) {

                        $H.configurePitchFilters($C, content.Pitches);

                        content.Pitches.forEach(function (pitch) {

                            if (pitch.Banding__c) {
                                if (rates[pitch.Banding__c + 'PitchFeeThisYear'] != null) {
                                    pitch.Price = rates[pitch.Banding__c + 'PitchFeeThisYear'];
                                }
                                if (rates[pitch.Banding__c + 'PitchFeeNextYear'] != null) {
                                    pitch.PriceNextYear = rates[pitch.Banding__c + 'PitchFeeNextYear'];
                                }
                            }

                            pitch.Show = true;
                            pitch.Include = true;

                            locations.forEach(function (location) {
                                if (location.Id == pitch.Areas__c) {
                                    if (location.Pitches && pitch.Number__c) {
                                        location.Pitches.forEach(function (pitchEntity) {
                                            if (pitchEntity.Number == pitch.Number__c) {
                                                pitch.X = pitchEntity.X;
                                                pitch.Y = pitchEntity.Y;
                                            }
                                        });
                                    }
                                }
                            })
                        });

                        $C.set('v.Pitches', content.Pitches);
                    }

                    if (content.Map && content.Map.length) {
                        $C.set('v.MapURL', '/resource/' + content.Map[0].Name);
                    }

                }

                // $C.set('v.InventorySearches', invSearches);
                $C.set('v.SelectionIds', selectionIds);
            }
        });
        $A.enqueueAction(getContentApex);

    },
    toggleModal: function ($C, $E, $H) {
        // set CurrentSelectedUnit as null
        $C.set('v.CurrentSelectedUnit', null);

        $C.set('v.showModal', !$C.get('v.showModal'));
    },
    setBrowsePXUnits: function ($C, $E, $H) {

        if ($C.get('v.SelectionsEditable')) {

            var buyIns = $C.get('v.BuyIns');
            var buyInIndex = buyInIndex ? buyInIndex : $E.currentTarget.dataset.buyinindex;

            $C.set('v.ConfiguringPXIndex', buyInIndex);
            $C.set('v.ActiveBuyIn', buyIns[buyInIndex]);

            $C.set('v.Header', 'GLASS\'S GUIDE UNIT VALUATIONS');
            $C.set('v.mode', 'browse-px-units');

            if (!$C.get('v.PXFiltersLoaded')) $H.loadPXFilters($C);
        }
    },
    checkPXDecking : function($C, $E, $H) {

        var activeBuyIn = $C.get('v.ActiveBuyIn');
        var include     = $E.getSource().get("v.value");

        if (!include){
            $C.set('v.RetainedDeckPXId',activeBuyIn.Id);
        } else {
            $C.set('v.RetainedDeckPXId',null);
        }
    },
    setBrowseUnits: function ($C, $E, $H) {
        var opp = $C.get('v.Opportunity');
        $C.set('v.mode', 'browse-units');
        $C.set('v.Header', 'HOLIDAY HOMES FOR SALE AT ' + opp.Park__r.Name.toUpperCase());

        if($C.get('v.VisibleInventoryItems').length === 0) {
            $A.enqueueAction($C.get('c.searchInventory'));
        }
    },
    setShowSelections: function ($C, $E, $H) {
        $C.set('v.mode', 'show-selections');
        $C.set('v.PitchInFocus', '');
        $C.set('v.ActiveBuyIn', '');
        $C.set('v.Header', 'YOUR SELECTIONS');

        const currentSelectedUnit = $C.get('v.CurrentSelectedUnit');
        if(currentSelectedUnit) {
            $H.processSelectedUnit($C, $E, $H);
        }
    },
    searchInventory: function ($C, $E, $H) {

        // set CurrentSelectedUnit as null
        $C.set('v.CurrentSelectedUnit', null);

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Fetching holiday homes and prices based on your selected region...');

        var opportunity = $C.get('v.Opportunity');
        var unitSettings = $C.get('v.UnitSettings');

        $C.set('v.Header', 'HOLIDAY HOMES FOR SALE AT ' + unitSettings.Location.toUpperCase());

        var searchInventoryApex = $C.get('c.searchInventoryApex');
        var query = ' Location__r.Region__c = \'' + unitSettings.Location + '\' ';
        var simulatePricing = true;
        var recordType = 'OtherPark';

        if (unitSettings.Location == opportunity.Park__r.Name) {
            query = ' Location__c = \'' + opportunity.Park__c + '\' ';
            simulatePricing = false;
            recordType = 'SamePark';
        } else if (unitSettings.Location == 'Manufacturer') {
            query = ' Location__r.RecordType.Name = \'Manufacturer\' ';
            simulatePricing = true;
            recordType = 'Manufacturer';
        } else if (unitSettings.Location == 'All Other Regions') {
            query = ' Location__c != \'' + opportunity.Park__c + '\' AND  Location__r.RecordType.Name != \'Manufacturer\' '
            simulatePricing = true;
            recordType = 'OtherPark';
        }
        if (!opportunity.Park__r.Minimum_Model_Year__c === null) {
            query = query + ' AND Model_Year__c >= ' + opportunity.Park__r.Minimum_Model_Year__c + ' ';
        }

        console.log('**** OTHER PARK QUERY',query,unitSettings.Location,simulatePricing,recordType);
        console.log('opportunity.Park__c: ', opportunity.Park__c);
        console.log('opportunity.Park__r.Park_Code__c: ', opportunity.Park__r.Park_Code__c);
        console.log('query: ', query);
        console.log('simulatePricing: ', simulatePricing);
        console.log('oppId: ', $C.get('v.recordId'));
        console.log('recordType: ', recordType);

        searchInventoryApex.setParams({ parkId: opportunity.Park__c, parkName: opportunity.Park__r.Park_Code__c, query: query, simulatePricing: simulatePricing, oppId: $C.get('v.recordId'), recordType: recordType });

        searchInventoryApex.setCallback(this, function (response) {

            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');

            console.log('updated callback searchInventoryApex using ' + recordType, response.getState(), response.getReturnValue());

            if (response.getState() === 'SUCCESS' && response.getReturnValue() && !(typeof response.getReturnValue() === 'string')) {

                var inventoryItems  = response.getReturnValue();
                var salePromotions  = $C.get('v.SalePromotions');
                var selectionIds    = $C.get('v.SelectionIds');
                var defaultImage    = $C.get('v.DefaultImage');

                $H.configureUnitFilters($C, opportunity, inventoryItems);
                var unitSettings = $C.get('v.UnitSettings');

                console.info('unitSettings: ',  JSON.stringify(unitSettings));

                let availableItems = [];

                inventoryItems.forEach(function (item) {

                    $H.getTenure(item, opportunity);
                    item.SalePromotions = [];
                    item.PitchPromotions = [];
                    if (salePromotions.length) {
                        $H.evalUnitPromos(item, salePromotions);

                        if (item.SalePromotions && item.SalePromotions.length) {
                            item.PromotionStatus = item.SalePromotions.length == 1 ? '1 promotion available' : item.SalePromotions.length + ' promotions available';
                        } else {
                            item.PromotionStatus = '';
                        }
                    }

                    item.Selected = selectionIds.includes(item.Id);
                    if(unitSettings.Location == 'Manufacturer') {
                        if(unitSettings.Manufacturer == 'Any' && unitSettings.Model == 'Any') {
                            item.Show = true;
                        } else if(unitSettings.Model == 'Any') {
                            item.Show = item.Manufacturer__c == unitSettings.Manufacturer;
                        } else if(unitSettings.Manufacturer == 'Any') {
                            item.Show = item.Model__c == unitSettings.Model;
                        } else {
                            item.Show =  item.Manufacturer__c == unitSettings.Manufacturer && item.Model__c == unitSettings.Model;
                        }
                    } else {
                        item.Show = true;
                    }

                    (item.Show && !item.Selected) ? availableItems.push(item) : null;

                    if (item.Stock_Images__r && item.Stock_Images__r.length) {
                        item.ActiveIndex = 0;
                    } else {
                        item.Thumbnail_Image__c = defaultImage;
                    }

                    if (simulatePricing) {
                        item.Location__r.Name = item.Simulation_Origin__c;
                    }
                });

                $C.set('v.InventoryItems', inventoryItems);
                $C.set('v.AvailableInventoryItems', availableItems);

                $C.set("v.totalPages", Math.ceil(availableItems.length/$C.get("v.pageSize")));
                $C.set("v.currentPageNumber", 1);
                $H.buildData($C, $H);

            } else {
                var error = response.getReturnValue() ? response.getReturnValue() : 'NULL response from apex';
                $A.get("e.force:showToast").setParams({ "title": "ERROR!", "type": "error", "message": error }).fire();
            }
        });

        $A.enqueueAction(searchInventoryApex);
    },
    evalUnits: function ($C, $E, $H) {

        var unitSettings = $C.get('v.UnitSettings');
        // var unitFilters 
        var inventoryItems = $C.get('v.InventoryItems');

        // if (unitSettings.Manufacturer == 'Any' || !unitSettings.Manufacturer){
        //     unitSettings.Model = 'Any';
        // }

        if (inventoryItems.length) {
            let availableItems = [];

            inventoryItems.forEach(function (item) {

                var Manufacturer = unitSettings.Location != 'Manufacturer' || unitSettings.Manufacturer == 'Any' || unitSettings.Manufacturer == item.Manufacturer__c;
                var Model = unitSettings.Location != 'Manufacturer' || unitSettings.Model == 'Any' || unitSettings.Model == item.Model__c;
                var Ownership = !unitSettings.Ownership || unitSettings.Ownership == 'Any' || unitSettings.Ownership == item.Ownership_Fx__c;
                var Status = !unitSettings.Status || unitSettings.Status == 'Any' || unitSettings.Status == item.Usage_State__c;
                var HolidayHomeType = !unitSettings.HolidayHomeType || unitSettings.HolidayHomeType == 'Any' || unitSettings.HolidayHomeType == item.Type__c;
                var PriceFrom = !unitSettings.PriceFrom || unitSettings.PriceFrom == 'Any' || item.Total_Sales_Price__c >= unitSettings.PriceFrom;
                var PriceTo = !unitSettings.PriceTo || unitSettings.PriceTo == 'Any' || item.Total_Sales_Price__c <= unitSettings.PriceTo;
                var LengthFrom = !unitSettings.LengthFrom || unitSettings.LengthFrom == 'Any' || item.Length__c >= unitSettings.LengthFrom;
                var LengthTo = !unitSettings.LengthTo || unitSettings.LengthTo == 'Any' || item.Length__c <= unitSettings.LengthTo;
                var WidthFrom = !unitSettings.WidthFrom || unitSettings.WidthFrom == 'Any' || item.Width__c >= unitSettings.WidthFrom;
                var WidthTo = !unitSettings.WidthTo || unitSettings.WidthTo == 'Any' || item.Width__c <= unitSettings.WidthTo;
                var Berths = !unitSettings.Berths || unitSettings.Berths == 'Any' || item.Berths__c == unitSettings.Berths;
                var Bedrooms = !unitSettings.Bedrooms || unitSettings.Bedrooms == 'Any' || item.Bedrooms__c == unitSettings.Bedrooms;
                var Age = !unitSettings.Age || unitSettings.Age == 'Any' || item.Age__c <= unitSettings.Age;
                var Accessibility = !unitSettings.Accessibility || unitSettings.Accessibility == 'Any';

                item.Show = Manufacturer && Model && Ownership && Status && HolidayHomeType && PriceFrom && PriceTo && LengthFrom && LengthTo && WidthFrom && WidthTo && Berths && Bedrooms && Age && Accessibility;
                (item.Show && !item.Selected) ? availableItems.push(item) : null;
            });

            $C.set('v.InventoryItems', inventoryItems);
            $C.set('v.AvailableInventoryItems', availableItems);
            $C.set('v.UnitSettings',unitSettings);

            $C.set("v.totalPages", Math.ceil(availableItems.length/$C.get("v.pageSize")));
            $C.set("v.currentPageNumber", 1);
            $H.buildData($C, $H);
        }

    },
    showPackageUnavailable: function ($C, $E, $H) {
        console.log('package unavailable');
        $C.set('v.PackageEstimate', null);
        $A.get("e.force:showToast").setParams({ "title": "Unavailable!", "type": "warn", "message": "This combination of holiday home and pitch is no longer available" }).fire();
    },
    showPackageEstimate: function ($C, $E, $H) {

        $E.stopPropagation();

        var selectionsEditablePerm = $C.get('v.SelectionsEditablePerm');

        if (selectionsEditablePerm) {
            if ($E.currentTarget.dataset && $E.currentTarget.dataset.inventoryindex) {

                $C.set('v.SelectedUnitIndex', $E.currentTarget.dataset.inventoryindex);
                $C.set('v.SelectedUnitPitchIndex', $E.currentTarget.dataset.index);

            } else {
                var packageEstimate = $C.get('v.PackageEstimate');
            }

            $C.set('v.SelectionsEditable', false);

            var opp = $C.get('v.Opportunity');
            var pitchMove = opp.Name_Prefix__c == 'PM';

            if (pitchMove) {
                $A.enqueueAction($C.get('c.showPitchPackageEstimate'));
            } else {

                var target = $C.get('v.ParkTarget');
                var commissions = $C.get('v.CommissionBands');

                // COMMISSIONS LOGIN
                // Sales Rep Commissions: £250.00
                // Sales Manager Commission: £375.00

                /// for sales rep - 
                // we query the commission band on the park 
                // find the rates belong to that park 
                // rates can be flat, or tiered
                // flat rates are percent of margin
                // currency rates are tiered  

                /// for sales manager - the Base_Commission_Per_Sale__c 
                // outcomes is 
                // 1. actual margin * 0.9 < tareget AUM > then  Base_Commission_Per_Sale__c * 1.25
                // 2. actual margin > min AUM > then  Base_Commission_Per_Sale__c * 0.75
                // 3. actual margin < min AUM > then Base_Commission_Per_Sale__c * 0.5

                var unitIndex = packageEstimate ? $C.get('v.SelectedUnitIndex') : $E.currentTarget.dataset.inventoryindex;
                var pitchIndex = packageEstimate ? $C.get('v.SelectedUnitPitchIndex') : $E.currentTarget.dataset.index;

                var pxSelections = packageEstimate ? packageEstimate.PXUnits : $C.get('v.BuyIns');

                var pxTotal = 0;
                var pxMarginAmount = 0;

                pxSelections.forEach(function (px) {
                    if (px.SIV__c && px.Buy_In_Offer__c) {

                        if (!packageEstimate) {
                            pxTotal -= px.Buy_In_Offer__c;
                            px.Selected = true;
                            px.Ineligible = false;
                        } else {
                            pxTotal -= px.Selected ? px.Buy_In_Offer__c : 0;
                        }

                        pxMarginAmount += (px.Selected && px.Allowance_Amount__c) ? px.Allowance_Amount__c : 0;
                    } else {
                        px.Selected = false;
                        px.Ineligible = true;
                    }
                });

                var caravanAncillaries  = $C.get('v.CaravanAncillaries');
                var lodgeAncillaries    = $C.get('v.LodgeAncillaries');

                var pricebookEntries    = $C.get('v.PricebookEntries');
                console.log('pricebookentries is',pricebookEntries);

                var selections          = $C.get('v.UnitSelections');
                var selectedUnit        = selections[unitIndex];

                console.log('selected unit', unitIndex, selectedUnit);
                var selectedPitch       = selectedUnit.Pitch_Selections__r[pitchIndex];
                var unitPrice           = selectedUnit.Total_Sales_Price__c;
                var connections         = selectedUnit.Connections_Accessories__c;
                var deckingCost         = selectedUnit.Decking_Cost__c && selectedUnit.Decking__r.Include_in_Package_Price__c ? selectedUnit.Decking_Cost__c : 0;
                var decking             = selectedUnit.Decking__r;

                var insuranceDetails    = $H.getInsuranceDetails(selectedUnit, $C, $H);
                var pitchFees           = parseFloat(selectedPitch.Price);
                var pitchFeesNextYear   = parseFloat(selectedPitch.PriceNextYear);
                var pitchFeesNextYearSelected = packageEstimate ? packageEstimate.PitchFeesNextYearSelected : $C.get('v.RequireNextYearPitchFees');

                var rates = $C.get('v.Rates');
                var ratesThisYear = parseFloat(rates.RatesThisYear);
                var ratesNextYear = parseFloat(rates.RatesNextYear);
                var ratesNextYearSelected = packageEstimate ? packageEstimate.RatesNextYearSelected : $C.get('v.RequireNextYearRates');

                var pitchRateTotals = pitchFees + ratesThisYear;
                if (pitchFeesNextYearSelected) pitchRateTotals += pitchFeesNextYear;
                if (ratesNextYearSelected) pitchRateTotals += ratesNextYear;

                // refunds for PX sales
                var loyaltyDiscount     = $C.get('v.LoyaltyDiscount');
                var refundThisYear      = loyaltyDiscount.ThisYearRefund ? loyaltyDiscount.ThisYearRefund * -1 : 0;
                var refundNextYear      = loyaltyDiscount.NextYearRefund ? loyaltyDiscount.NextYearRefund * -1 : 0;
                var ratesRefundThisYear = loyaltyDiscount.ThisYearRatesRefund ? loyaltyDiscount.ThisYearRatesRefund * -1 : 0;
                var ratesRefundNextYear = loyaltyDiscount.NextYearRatesRefund ? loyaltyDiscount.NextYearRatesRefund * -1 : 0;
                var promoDiscounts      = 0;
                var marginFundedPromos  = 0;
                var commissionablePromos = 0;
                var promotions          = [];
                var selectedPromoIds    = packageEstimate ? packageEstimate.SelectedPromotionIds : [];
                var promosChanged       = false;
                var incompatiblePromos  = '';
                var subscriptionPromos  = $C.get('v.SubscriptionPromotions');

                if (selectedPitch.Promotions && selectedPitch.Promotions.length) {
                    selectedPitch.Promotions.forEach(function (promo) {
                        promotions.push(promo);
                    });
                }

                if (selectedUnit.SalePromotions && selectedUnit.SalePromotions.length) {
                    selectedUnit.SalePromotions.forEach(function (promo) {
                        promotions.push(promo);
                    });
                }

                subscriptionPromos.forEach(function (promo) {
                    promotions.push(promo);
                });

                promotions.forEach(function (promo) {

                    promo.EvaluateSelection = true;

                    if (packageEstimate && !promo.IsStock) {
                        if (promo.Selected && !selectedPromoIds.includes(promo.Id)) {
                            promo.EvaluateSelection = false;
                            incompatiblePromos += promo.IncompatiblePromos;
                            selectedPromoIds.push(promo.Id);
                            promosChanged = true;
                        } else if (!promo.Selected && selectedPromoIds.includes(promo.Id)) {
                            promo.EvaluateSelection = false;
                            promosChanged = true;
                            selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                        } else if (promo.EvaluateSelection && selectedPromoIds.includes(promo.Id)) {
                            selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                        }
                    }
                });

                promotions.forEach(function (promo) {

                    promo.IsStock = promo.Record_Type__c === 'Stock_Promotion';

                    if (promo.IsStock) {
                        promo.Selected = true;
                    } else {
                        if (promo.EvaluateSelection) {
                            if (!incompatiblePromos.includes(promo.Id)) {

                                if (promo.Selected && (!packageEstimate || !promosChanged)) {
                                    promo.Selected = true;
                                }

                                if (!promo.Selected) {
                                    promo.Selected = !packageEstimate || !promosChanged;
                                }

                                if (promo.Selected) {
                                    incompatiblePromos += promo.IncompatiblePromos;
                                    selectedPromoIds.push(promo.Id);
                                }
                            } else {
                                promo.Selected = false;
                                if (selectedPromoIds.includes(promo.Id)) {
                                    selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                                }
                            }
                        }
                    }

                    promo.Lines = [];

                    if (promo.Promotion_Outputs__r && promo.Promotion_Outputs__r.length) {

                        promo.Promotion_Outputs__r.forEach(function (output) {
                            if (output.RecordType.DeveloperName == 'Product_Giveaway' && output.Product__c) {
                                if (output.As_Extra__c) {
                                    
                                    if (output.Product__r.Name == 'Deposit Contribution'){

                                        if (output.Deposit_Amount__c){
                                            var productPrice = output.Deposit_Amount__c * -1;
                                            var marginFunded = 0;
        
                                            if (promo.Selected) {
                                                promoDiscounts += productPrice;
                                                marginFunded = output.Margin_Funded__c ? (productPrice * (output.Margin_Funded__c / 100)) : 0;
                                                marginFundedPromos += marginFunded;
        
                                                if (output.Commissionable__c) {
                                                    commissionablePromos += marginFunded;
                                                }
                                            }
                                            
                                            promo.Lines.push({ Name: output.Product__r.Name, Amount: productPrice, MarginFunded: true });

                                        }


                                    } else {
                                        var productPrice = pricebookEntries && pricebookEntries[output.Product__r.Name] ? pricebookEntries[output.Product__r.Name].UnitPrice * -1 : 0;
                                        var marginFunded = 0;
    
                                        if (promo.Selected) {
                                            promoDiscounts += productPrice;
                                            marginFunded = output.Margin_Funded__c ? (productPrice * (output.Margin_Funded__c / 100)) : 0;
                                            marginFundedPromos += marginFunded;
    
                                            if (output.Commissionable__c) {
                                                commissionablePromos += marginFunded;
                                            }
                                        }
                                        
                                        promo.Lines.push({ Name: 'Free ' + output.Product__r.Name, Amount: 0, MarginFunded: false });
                                    }
                                } else {
                                    var productPrice = 0;
                                    if (selectedUnit.Type__c == 'Lodge' && lodgeAncillaries[output.Product__c]) {
                                        productPrice = lodgeAncillaries[output.Product__c].UnitPrice * -1;
                                    } else if (selectedUnit.Type__c == 'Caravan' && caravanAncillaries[output.Product__c]) {
                                        productPrice = caravanAncillaries[output.Product__c].UnitPrice * -1;
                                    }

                                    var marginFunded = 0;

                                    if (promo.Selected) {
                                        promoDiscounts += productPrice;
                                        marginFunded = output.Margin_Funded__c ? (productPrice * (output.Margin_Funded__c / 100)) : 0;
                                        marginFundedPromos += marginFunded;

                                        if (output.Commissionable__c) {
                                            commissionablePromos += marginFunded;
                                        }
                                    }

                                    promo.Lines.push({ Name: 'Free ' + output.Product__r.Name, Amount: productPrice, MarginFunded: marginFunded });
                                }
                            } else if (output.RecordType.DeveloperName == 'Tenure_Adjustment') {
                                promo.Lines.push({ Name: output.Tenure_Years__c + ' year tenure ', Amount: null, MarginFunded: 0 });
                            } else if (output.RecordType.DeveloperName == 'Subscription_Item_Adjustment') {

                                if (output.Discount_Percentage__c && output.Subscription_Year__c) {

                                    var productPrice = 0;

                                    if (output.Output_Type__c == 'Pitch Fees') {
                                        if (output.Subscription_Year__c == new Date().getFullYear()) {
                                            productPrice = (pitchFees * (output.Discount_Percentage__c / 100)) * -1;
                                        } else if (pitchFeesNextYearSelected && output.Subscription_Year__c == new Date().getFullYear() + 1) {
                                            productPrice = (pitchFeesNextYear * (output.Discount_Percentage__c / 100)) * -1;
                                        }
                                    } else if (output.Output_Type__c == 'Rates') {
                                        if (output.Subscription_Year__c == new Date().getFullYear()) {
                                            productPrice = (ratesThisYear * (output.Discount_Percentage__c / 100)) * -1;
                                        } else if (ratesNextYearSelected && output.Subscription_Year__c == new Date().getFullYear() + 1) {
                                            productPrice = (ratesNextYear * (output.Discount_Percentage__c / 100)) * -1;
                                        }
                                    }

                                    var marginFunded = 0;

                                    if (promo.Selected) {
                                        promoDiscounts += productPrice;
                                        marginFunded = output.Margin_Funded__c ? (productPrice * (output.Margin_Funded__c / 100)) : 0;
                                        marginFundedPromos += marginFunded;

                                        if (output.Commissionable__c) {
                                            commissionablePromos += marginFunded;
                                        }
                                    }

                                    promo.Lines.push({ Name: output.Discount_Percentage__c + '% off ' + output.Output_Type__c + ' for ' + output.Subscription_Year__c, Amount: (productPrice ? productPrice : null), MarginFunded: marginFunded });
                                }
                            } else if (output.RecordType.DeveloperName == 'Unit_Price_Adjustment') {

                                var productPrice = 0;
                                var name = '';
                                var caveat = promo.Record_Type__c === 'Stock_Promotion' ? ' (reflected in package price)' : '';

                                if (output.Discount_Percentage__c != null) {
                                    productPrice = ((unitPrice - connections) * (output.Discount_Percentage__c / 100)) * -1;
                                    name = output.Discount_Percentage__c + '% off Holiday Home';
                                } else if (output.Discount_Amount__c != null) {
                                    productPrice = output.Discount_Amount__c * -1;
                                    name = '£' + output.Discount_Amount__c + ' off Holiday Home';
                                } else if (output.Fixed_Price_Amount__c != null) {
                                    productPrice = ((unitPrice - connections) - output.Fixed_Price_Amount__c) * -1;
                                    name = '£' + output.Fixed_Price_Amount__c + ' fixed price Holiday Home offer';
                                }

                                if (promo.Record_Type__c === 'Stock_Promotion') productPrice = null;

                                var marginFunded = 0;

                                if (promo.Selected) {
                                    promoDiscounts += productPrice;
                                    marginFunded = output.Margin_Funded__c ? (productPrice * (output.Margin_Funded__c / 100)) : 0;
                                    marginFundedPromos += marginFunded;

                                    if (output.Commissionable__c) {
                                        commissionablePromos += marginFunded;
                                    }
                                }

                                promo.Lines.push({ Name: name + caveat, Amount: productPrice, MarginFunded: marginFunded });

                            } else if (output.RecordType.DeveloperName == 'Account_Credit') {
                                if (output.Output_Type__c == 'Credit Owners Account') {

                                    var marginFunded = 0;

                                    if (promo.Selected) {
                                        marginFunded = output.Margin_Funded__c ? ((output.Amount__c * (output.Margin_Funded__c / 100))) * -1 : 0;
                                        marginFundedPromos += marginFunded;
    
                                        if (output.Commissionable__c) {
                                            commissionablePromos += marginFunded;
                                        }
                                    }

                                    promo.Lines.push({ Name: '£' + output.Amount__c + ' account credit', Amount: null, MarginFunded: false });
                                } else if (output.Output_Type__c == 'Credit Referrers Account') {
                                    
                                    var marginFunded = 0;

                                    if (promo.Selected) {
                                        marginFunded = output.Margin_Funded__c ? ((output.Amount__c * (output.Margin_Funded__c / 100))) * -1 : 0;
                                        marginFundedPromos += marginFunded;
    
                                        if (output.Commissionable__c) {
                                            commissionablePromos += marginFunded;
                                        }
                                    }

                                    promo.Lines.push({ Name: 'Owner referral', Amount: null, MarginFunded: false });
                                }
                            } else if (output.RecordType.DeveloperName == 'Deposit_Adjustment') {
                                if (output.Output_Type__c == 'PDR Deposit Contribution') {

                                    var marginFunded = 0;

                                    if (promo.Selected) {
                                        marginFunded = output.Margin_Funded__c ? ((output.Amount__c * (output.Margin_Funded__c / 100))) * -1 : 0;
                                        marginFundedPromos += marginFunded;
    
                                        if (output.Commissionable__c) {
                                            commissionablePromos += marginFunded;
                                        }
                                    }

                                    promo.Lines.push({ Name: '£' + output.Amount__c + ' contribution towards your finance deposit', Amount: null, MarginFunded: false });
                                } else if (output.Output_Type__c == 'Required Deposit Adjustment') {
                                    promo.Lines.push({ Name: 'Reduced sale deposit of £' + output.Amount__c, Amount: null, MarginFunded: false });
                                }
                            }
                        });
                    } else if (promo.Discount_Percentage__c) {
                        if (promo.Discount_Percentage__c) {

                            var productPrice = 0;

                            if (promo.Type__c.startsWith('Pitch')) {
                                if (promo.Year__c == new Date().getFullYear()) {
                                    productPrice = (pitchFees * (promo.Discount_Percentage__c / 100)) * -1;
                                } else if (pitchFeesNextYearSelected && promo.Year__c == new Date().getFullYear() + 1) {
                                    productPrice = (pitchFeesNextYear * (promo.Discount_Percentage__c / 100)) * -1;
                                }
                            }

                            var marginFunded = 0;

                            if (promo.Selected) {
                                promoDiscounts += productPrice;
                                marginFunded = promo.Margin_Funded__c ? (productPrice * (promo.Margin_Funded__c / 100)) : 0;
                                marginFundedPromos += marginFunded;
                            }

                            promo.Lines.push({
                                Name: promo.Discount_Percentage__c + '% off ' + promo.Type__c + ' for ' + promo.Year__c,
                                Amount: productPrice,
                                MarginFunded: marginFunded
                            });

                            promo.FromAccount = promo.Contract_Account__r ? promo.Contract_Account__r.Name : opp.Account.Name;
                        }
                    }

                    promo.Lines.sort(function (a, b) {
                        var bVal = b.Amount == null ? 1 : b.Amount;
                        var aVal = a.Amount == null ? 1 : a.Amount;

                        return aVal - bVal;
                    });

                });

                var targetMargin = selectedUnit.Target_Margin__c;
                var actualMargin = selectedUnit.Margin_Including_Connections__c  - pxMarginAmount; //+ (marginFundedPromos * -1)
                var mimimumMargin = 0;
                var commission;

                if (target) {
                    if (selectedUnit.Type__c == 'Caravan') {
                        commission = opp.Park__r.Commission_Band_Caravan__c ? commissions[opp.Park__r.Commission_Band_Caravan__c] : null;
                        if (opp.Record_Type_Name__c == 'Part_Ex_Current_owner') {
                            mimimumMargin = target.AUM_Caravan_PX__c;
                        } else {
                            mimimumMargin = target.AUM_Caravan_NB__c;
                        }

                    } else if (selectedUnit.Type__c == 'Lodge') {
                        commission = opp.Park__r.Commission_Band_Lodge__c ? commissions[opp.Park__r.Commission_Band_Lodge__c] : null;
                        if (opp.Record_Type_Name__c == 'Part_Ex_Current_owner') {
                            mimimumMargin = target.AUM_Lodge_PX__c;
                        } else {
                            mimimumMargin = target.AUM_Lodge_NB__c;
                        }
                    }
                }

                var commissionableMargin = actualMargin + commissionablePromos;
                var sRComission = 0;

                if (commission) {
                    if (commission.Commission_Band_Rates__r && commission.Commission_Band_Rates__r.length) {
                        if (commission.Type__c == 'Percent') {
                            commission.Commission_Band_Rates__r.forEach(function (bandRate) {
                                if (selectedUnit.Type__c == bandRate.Inventory_Type__c) {
                                    if (bandRate.Commission_Rate_Percent__c) {
                                        sRComission = commissionableMargin * (bandRate.Commission_Rate_Percent__c / 100);
                                    }
                                }
                            });
                        } else if (commission.Type__c == 'Amount') {
                            commission.Commission_Band_Rates__r.forEach(function (bandRate) {
                                if (commissionableMargin >= bandRate.Margin_From__c && commissionableMargin <= bandRate.Margin_To__c) {
                                    if (bandRate.Commission_Rate_Amount__c) {
                                        sRComission = bandRate.Commission_Rate_Amount__c;
                                    }
                                }
                            });
                        }
                    }
                }

                var sMComission = 0;

                if (opp.Park__r.Caravan_Sales_Manager__r && opp.Park__r.Caravan_Sales_Manager__r.Commision_Per_Sale__c) {
                    if ((commissionableMargin * 0.9) < targetMargin) {
                        sMComission = opp.Park__r.Caravan_Sales_Manager__r.Commision_Per_Sale__c * 1.25;
                    } else if (commissionableMargin > mimimumMargin) {
                        sMComission = opp.Park__r.Caravan_Sales_Manager__r.Commision_Per_Sale__c * 0.75;
                    } else {
                        sMComission = opp.Park__r.Caravan_Sales_Manager__r.Commision_Per_Sale__c * 0.5;
                    }
                }

                var refundTotal = refundThisYear + refundNextYear + ratesRefundThisYear + ratesRefundNextYear;
                var total = pxTotal + unitPrice + pitchRateTotals + refundTotal + insuranceDetails.TotalInsPrice;
                var unitName = selectedUnit.Manufacturer__c + ', ' + selectedUnit.Model__c + ' ' + selectedUnit.Model_Year__c;

                console.log('when compiling estimate',JSON.parse(JSON.stringify(loyaltyDiscount)));

                var packageEstimate = {
                    PXTotal: pxTotal,
                    PXUnits: pxSelections,
                    PXMarginAmount: pxMarginAmount,
                    SelectedUnit: selectedUnit,
                    UnitPrice: unitPrice - connections - deckingCost,
                    UnitName: unitName,
                    Connection: connections,
                    DeckingCost: deckingCost,
                    Decking: decking,
                    UnitCosts: unitPrice,
                    PitchName: selectedPitch.Pitch__r.Name,
                    PitchFees: pitchFees,
                    Rates: ratesThisYear,
                    PitchFeesNextYear: pitchFeesNextYear,
                    PitchFeesNextYearSelected: pitchFeesNextYearSelected,
                    RatesNextYear: ratesNextYear,
                    RatesNextYearSelected: ratesNextYearSelected,
                    PitchBanding: selectedPitch.Banding__c,
                    PitchRatesTotal: pitchRateTotals,
                    RefundThisYear: refundThisYear,
                    RefundNextYear: refundNextYear,
                    PitchVAT: loyaltyDiscount.PitchVAT,
                    RatesRefundThisYear : ratesRefundThisYear,
                    RatesRefundNextYear : ratesRefundNextYear, 
                    RatesVAT : loyaltyDiscount.RatesVAT,
                    RefundTotal: refundTotal,
                    Promotions: promotions,
                    SelectedPromotionIds: selectedPromoIds,
                    PromotionValue: promoDiscounts,
                    Total: total,
                    TotalIncPromotions: total + promoDiscounts,
                    TargetMargin: targetMargin,
                    MarginFundedPromo: marginFundedPromos,
                    MimimumMargin: mimimumMargin,
                    UnitMargin: selectedUnit.Margin_Including_Connections__c,
                    ActualMargin: actualMargin,
                    MarginBeforeMFO : actualMargin, //(actualMargin + (marginFundedPromos * -1)),
                    ActualMarginAfterMFO: actualMargin + marginFundedPromos,
                    CommissionableMFO : (marginFundedPromos * -1),
                    CommissionableMargin: commissionableMargin,
                    CommissionBand: commission,
                    SMCommission: sMComission,
                    SRCommission: sRComission,
                    NewForOldInsProRataNetPrice: insuranceDetails.NewForOldInsProRataNetPrice,
                    AlarmProRataNetPrice: insuranceDetails.AlarmProRataNetPrice,
                    TotalInsPrice: insuranceDetails.TotalInsPrice,
                    NewForOldId: insuranceDetails.NewForOldId,
                    MarketValueId: insuranceDetails.MarketValueId,
                    NewForOldContentProRataNetPrice: insuranceDetails.NewForOldContentProRataNetPrice,
                    MarketValueInsProRataNetPrice: insuranceDetails.MarketValueInsProRataNetPrice,
                    MarketValueContentProRataNetPrice: insuranceDetails.MarketValueContentProRataNetPrice
                };

                console.log('PACKAGE ESTIMATE',packageEstimate);

                $C.set('v.PackageEstimate', packageEstimate);
                $C.set('v.SelectedUnitId', selectedUnit.Id);
                $C.set('v.SelectedUnitIndex', unitIndex);
                $C.set('v.SelectedUnitPitchId', selectedPitch.Id);
                $C.set('v.SelectedUnitPitchIndex', pitchIndex);
                $C.set('v.BuyIns', pxSelections);
                $C.set('v.PitchInFocus', selectedPitch.Id);
            }
        }
    },
    hidePackageEstimate: function ($C, $E) {
        $C.set('v.SelectionsEditable', $C.get('v.SelectionsEditablePerm'));
        $C.set('v.PackageEstimate', null);
        $C.set('v.SelectedUnitId', null);
        $C.set('v.SelectedUnitIndex', null);
        $C.set('v.SelectedUnitPitchId', null);
        $C.set('v.SelectedUnitPitchIndex', null);

        var buyIns = $C.get('v.BuyIns');
        if (buyIns.length) buyIns.forEach(function (buyIn) { buyIn.Selected = false });
        $C.set('v.BuyIns', buyIns);
    },
    showPitchPackageEstimate: function ($C, $E) {

        var pitchPackageEstimate = $C.get('v.PitchPackageEstimate');

        $C.set('v.SelectionsEditable', false);

        var unitIndex           = $C.get('v.SelectedUnitIndex')
        var pitchIndex          = $C.get('v.SelectedUnitPitchIndex')
        var selections          = $C.get('v.UnitSelections');
        var selectedUnit        = selections[unitIndex];
        var selectedPitch       = selectedUnit.Pitch_Selections__r[pitchIndex];
        var connections         = $C.get('v.PitchMoveAncillaries');
        var pitchFees           = parseFloat(selectedPitch.Price);
        var pitchFeesNextYear   = parseFloat(selectedPitch.PriceNextYear);
        var requireNextYear     = $C.get('v.RequireNextYearPitchFees');
        var loyaltyDiscount     = $C.get('v.LoyaltyDiscount');
        var pitchMultiplier     = $C.get('v.PitchMultiplier');
        var refundThisYear      = loyaltyDiscount.ThisYearRefund ? loyaltyDiscount.ThisYearRefund * -1 : 0;
        var refundNextYear      = loyaltyDiscount.NextYearRefund ? loyaltyDiscount.NextYearRefund * -1 : 0;
        var includedLoyaltyDiscount = loyaltyDiscount.Discount * pitchMultiplier;

        var pitchFeesNextYearSelected = pitchPackageEstimate ? pitchPackageEstimate.PitchFeesNextYearSelected : requireNextYear;

        if (loyaltyDiscount.NextYear) {
            pitchFeesNextYearSelected = true;
            $C.set('v.RequireNextYearPitchFees', true);
        }

        var promoDiscounts = 0;

        var promotions          = [];
        var selectedPromoIds    = pitchPackageEstimate ? pitchPackageEstimate.SelectedPromotionIds : [];
        var promosChanged       = false;
        var incompatiblePromos  = '';
        var subscriptionPromos  = $C.get('v.SubscriptionPromotions');

        subscriptionPromos.forEach(function (promo) {
            promotions.push(promo);
        });

        promotions.forEach(function (promo) {

            promo.EvaluateSelection = true;

            if (pitchPackageEstimate && !promo.IsStock) {
                if (promo.Selected && !selectedPromoIds.includes(promo.Id)) {
                    promo.EvaluateSelection = false;
                    incompatiblePromos += promo.IncompatiblePromos;
                    selectedPromoIds.push(promo.Id);
                    promosChanged = true;
                } else if (!promo.Selected && selectedPromoIds.includes(promo.Id)) {
                    promo.EvaluateSelection = false;
                    promosChanged = true;
                    selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                } else if (promo.EvaluateSelection && selectedPromoIds.includes(promo.Id)) {
                    selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                }
            }
        });

        promotions.forEach(function (promo) {
            if (promo.EvaluateSelection) {
                if (!incompatiblePromos.includes(promo.Id)) {

                    if (promo.Selected && (!pitchPackageEstimate || !promosChanged)) {
                        promo.Selected = true;
                    }

                    if (!promo.Selected) {
                        promo.Selected = !pitchPackageEstimate || !promosChanged;
                    }

                    if (promo.Selected) {
                        incompatiblePromos += promo.IncompatiblePromos;
                        selectedPromoIds.push(promo.Id);
                    }
                } else {
                    promo.Selected = false;
                    if (selectedPromoIds.includes(promo.Id)) {
                        selectedPromoIds.splice(selectedPromoIds.indexOf(promo.Id), 1);
                    }
                }
            }

            promo.Lines = [];

            if (promo.Discount_Percentage__c) {
                var productPrice = 0;

                if (promo.Type__c.startsWith('Pitch')) {
                    if (promo.Year__c == new Date().getFullYear()) {
                        productPrice = (pitchFees * (promo.Discount_Percentage__c / 100)) * -1;
                    } else if (pitchFeesNextYearSelected && promo.Year__c == new Date().getFullYear() + 1) {
                        productPrice = (pitchFeesNextYear * (promo.Discount_Percentage__c / 100)) * -1;
                    }
                }


                var marginFunded = 0;

                if (promo.Selected) {
                    promoDiscounts += productPrice;
                    marginFunded = promo.Margin_Funded__c ? (productPrice * (promo.Margin_Funded__c / 100)) : 0;
                }

                promo.Lines.push({
                    Name: promo.Discount_Percentage__c + '% off ' + promo.Type__c + ' for ' + promo.Year__c,
                    Amount: productPrice,
                    MarginFunded: marginFunded
                });

                promo.FromAccount = promo.Contract_Account__r ? promo.Contract_Account__r.Name : opp.Account.Name;
            }

            promo.Lines.sort(function (a, b) {
                var bVal = b.Amount == null ? 1 : b.Amount;
                var aVal = a.Amount == null ? 1 : a.Amount;

                return aVal - bVal;
            });
        });


        var total = pitchFees + connections + refundThisYear + refundNextYear;
        if (pitchFeesNextYearSelected){
            total += pitchFeesNextYear;
            includedLoyaltyDiscount += loyaltyDiscount.Discount;

        } 

        var pitchPackageEstimate = {
            UnitName: selectedUnit.Name,
            PitchName: selectedPitch.Name,
            PitchFees: pitchFees,
            Connection: connections,
            PitchFeesTotal: pitchFees + (pitchFeesNextYearSelected ? pitchFeesNextYear : 0) + connections,
            RefundThisYear: refundThisYear,
            RefundNextYear: refundNextYear,
            PitchVAT : loyaltyDiscount.PitchVAT,
            RefundTotal: refundThisYear + refundNextYear,
            PitchFeesNextYear: pitchFeesNextYear,
            PitchFeesNextYearSelected: pitchFeesNextYearSelected,
            PitchBanding: selectedPitch.Banding__c,
            PitchRatesTotal: pitchFees,
            Promotions: promotions,
            SelectedPromotionIds: selectedPromoIds,
            PromotionValue: promoDiscounts,
            IncludedLoyaltyDiscount : includedLoyaltyDiscount,
            Total: total,
            TotalIncPromotions: total + promoDiscounts,
        };

        console.log('PACKAGE ESTIMATE',pitchPackageEstimate);

        $C.set('v.PitchPackageEstimate', pitchPackageEstimate);
    },
    hidePitchPackageEstimate: function ($C, $E) {
        $C.set('v.SelectionsEditable', $C.get('v.SelectionsEditablePerm'));
        $C.set('v.PitchPackageEstimate', null);
        $C.set('v.SelectedUnitId', null);
        $C.set('v.SelectedUnitIndex', null);
        $C.set('v.SelectedUnitPitchId', null);
        $C.set('v.SelectedUnitPitchIndex', null);
    },
    setConfiguringExistingPX: function ($C, $E) {
        var buyIns = $C.get('v.BuyIns');
        var buyInIndex = $E.currentTarget.dataset.buyinindex;
        buyIns[buyInIndex].Configuring = true;
        buyIns[buyInIndex].PXFormValid = true;
        $C.set('v.BuyIns', buyIns);
        $C.set('v.ConfiguringPXIndex', buyInIndex);
        $C.set('v.ActiveBuyIn', buyIns[buyInIndex]);
    },
    cancelConfiguringExistingPX: function ($C, $E) {
        var buyIns = $C.get('v.BuyIns');
        var buyInIndex = $C.get('v.ConfiguringPXIndex');
        if (buyIns[buyInIndex]) {
            buyIns[buyInIndex].Configuring = false;
        }
        $C.set('v.BuyIns', buyIns);
        $C.set('v.ConfiguringPXIndex', null);
        $C.set('v.ActiveBuyIn', null);
    },
    setConfiguringPX: function ($C) {
        $C.set('v.ConfiguringPXIndex', '');
        $C.set('v.ActiveBuyIn', { Configuring: true });
    },
    handleCreateLoad: function ($C, $E, $H) {
        $C.find("opportunityField").set("v.value", $C.get('v.recordId'));
        $C.find("statusField").set("v.value", 'Potential');
    },
    setPXUpdatePending: function ($C, $E, $H) {
        $C.set('v.ResponsePending', true);
    },
    handlePXUpdateSuccess: function ($C, $E, $H) {
        var getBuyInsApex = $C.get('c.getBuyInsApex');
        getBuyInsApex.setParams({ recordId: $C.get('v.recordId') });
        getBuyInsApex.setCallback(this, function (response) {
            $C.set('v.BuyIns', response.getReturnValue());
            $C.set('v.ResponsePending', false);
            $C.set('v.ActiveBuyIn', null);
        });
        $A.enqueueAction(getBuyInsApex);
    },
    getPXValuations: function ($C) {

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Finding matching Glass\'s Guide valuations...');

        var pxFilters = $C.get('v.PXFilters');
        var pXSettings = $C.get('v.PXSettings');
        var activeBuyIn = $C.get('v.ActiveBuyIn');

        console.log('activeBuyIn.Year', activeBuyIn.Model_Year__c);
        console.log(Object.keys(pXSettings), Object.values(pXSettings));

        if (pXSettings.Make) {
            var getValuationsApex = $C.get('c.getValuationsApex');
            getValuationsApex.setParams({ manufacturer: pXSettings.Make, year: parseInt(activeBuyIn.Model_Year__c) });
            getValuationsApex.setCallback(this, function (response) {

                console.log('$C.get(\'c.getValuationsApex\')', response.getState(), response.getReturnValue());

                if (response.getState() === 'SUCCESS') {

                    var valuations = response.getReturnValue();

                    var Model = new Set();
                    var Year = new Set();
                    var Bedrooms = new Set();
                    var Length = new Set();
                    var Width = new Set();

                    if (valuations.length) {
                        valuations.forEach(function (valuation) {

                            valuation.Show = true;
                            if (valuation.Model_Specification__r && valuation.Model_Specification__r.Model__r) Model.add(valuation.Model_Specification__r.Model__r.Range_Description__c);
                            if (valuation.Year__c) Year.add(valuation.Year__c);
                            if (valuation.Bedrooms__c) Bedrooms.add(valuation.Bedrooms__c);
                            if (valuation.Length_Rounded__c) Length.add(valuation.Length_Rounded__c);
                            if (valuation.Width_Rounded__c) Width.add(valuation.Width_Rounded__c);

                            valuation.MatchType = 'POOR MATCH';
                            valuation.Class = 'no-match';

                            if (pXSettings.Make && pXSettings.Make.toUpperCase() == activeBuyIn.Make__c.toUpperCase() &&
                                valuation.Width_Rounded__c == activeBuyIn.Width__c &&
                                valuation.Bedrooms__c == activeBuyIn.Bedrooms__c) {

                                if (valuation.Length_Rounded__c == activeBuyIn.Length__c &&
                                    valuation.Year__c == activeBuyIn.Model_Year__c &&
                                    valuation.Model_Specification__r.Model__r.Range_Description__c.toUpperCase() == activeBuyIn.Model__c.toUpperCase()) {
                                    valuation.MatchType = 'EXACT MATCH';
                                    valuation.Class = 'exact-match';
                                } else {
                                    valuation.MatchType = 'SOFT MATCH';
                                    valuation.Class = 'soft-match';
                                }
                            }
                        });
                    }

                    pxFilters.Model     = Array.from(Model);
                    pxFilters.Year      = Array.from(Year);
                    pxFilters.Bedrooms  = Array.from(Bedrooms);
                    pxFilters.Length    = Array.from(Length);
                    pxFilters.Width     = Array.from(Width);

                    pxFilters.Model.sort();
                    pxFilters.Year.sort();
                    pxFilters.Bedrooms.sort();
                    pxFilters.Length.sort();
                    pxFilters.Width.sort();

                    pxFilters.Model.forEach(function (model) {
                        if (model == activeBuyIn.Model__c) {
                            pXSettings.Model = activeBuyIn.Model__c;
                        }
                    });
                    pxFilters.Year.forEach(function (year) {
                        if (year == activeBuyIn.Model_Year__c) {
                            pXSettings.Year = activeBuyIn.Model_Year__c.toString();
                        }
                    });
                    pxFilters.Bedrooms.forEach(function (bedroom) {
                        if (bedroom == parseInt(activeBuyIn.Bedrooms__c)) {
                            pXSettings.Bedrooms = parseInt(activeBuyIn.Bedrooms__c);
                        }
                    });
                    pxFilters.Length.forEach(function (length) {
                        if (length == activeBuyIn.Length__c) {
                            pXSettings.Length = activeBuyIn.Length__c;
                        }
                    });
                    pxFilters.Width.forEach(function (width) {
                        if (width == activeBuyIn.Width__c) {
                            pXSettings.Width = activeBuyIn.Width__c;
                        }
                    });

                    $C.set('v.PXFilters', pxFilters);
                    $C.set('v.PXSettings', pXSettings);
                    $C.set('v.GlassesGuideUnits', valuations);
                    $C.set('v.responsePending', false);
                    $C.set('v.PendingMessage', '');
                    $A.enqueueAction($C.get('c.evalGG'));

                } else {
                    $C.set('v.responsePending', false);
                    $C.set('v.PendingMessage', '');
                }
            });
            $A.enqueueAction(getValuationsApex);
        } else {
            $C.set('v.PXFilters', pxFilters);
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');
        }
    },
    evalGG: function ($C, $E, $H) {

        var pXSettings = $C.get('v.PXSettings');
        var units = $C.get('v.GlassesGuideUnits');

        if (units.length) {
            units.forEach(function (unit) {

                var Model       = !pXSettings.Model || pXSettings.Model == unit.Model_Specification__r.Model__r.Range_Description__c;
                var Year        = !pXSettings.Year || pXSettings.Year == unit.Year__c;
                var Bedrooms    = !pXSettings.Bedrooms || pXSettings.Bedrooms == unit.Bedrooms__c;
                var Length      = !pXSettings.Length || pXSettings.Length == unit.Length_Rounded__c;
                var Width       = !pXSettings.Width || pXSettings.Width == unit.Width_Rounded__c;
                unit.Show       = Model && Year && Bedrooms && Length && Width;
            });

            $C.set('v.GlassesGuideUnits', units);
        }
    },
    selectGGUnit: function ($C, $E) {

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Applying this Glass\'s Guide valuation to your part exchange unit...');
        var activeBuyIn = $C.get('v.ActiveBuyIn');
        var unitId = $E.currentTarget.dataset.unitid;
        var matchType = $E.currentTarget.dataset.matchtype;

        var selectGGUnitApex = $C.get('c.selectGGUnitApex');
        selectGGUnitApex.setParams({ recordId: $C.get('v.recordId'), buyInId: activeBuyIn.Id, valuationId: unitId, matchType: matchType });
        selectGGUnitApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');

            if (response.getState() === 'SUCCESS') {
                $C.set('v.BuyIns', response.getReturnValue());
                $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "Valuation successfully applied" }).fire();
                $C.set('v.mode', 'show-selections');
                $C.set('v.ActiveBuyIn', '');
            } else {
                $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getState() }).fire();
            }
        });
        $A.enqueueAction(selectGGUnitApex);
    },
    selectUnit: function ($C, $E, $H) {

        var inventoryItems  = $C.get('v.VisibleInventoryItems');
        var unitIndex       = $E.currentTarget.dataset.index;
        var inventoryItem   = inventoryItems[unitIndex];
        console.info('unitIndex: '+ unitIndex);

        if (inventoryItem.In_Simulation__c) {
            $A.get("e.force:showToast").setParams({ "title": "Price pending", "type": "warn", "message": "We're still calculating a price for this holiday home" }).fire();
        } else {
            $C.set('v.CurrentSelectedUnit', inventoryItem);
            $A.get("e.force:showToast").setParams({ "title": "Unit selected", "type": "success", "message": `You've selected the ${inventoryItem.Name}. If you select another holiday home, this one will be replaced.`}).fire();
        }
    },
    deleteBuyIn: function ($C, $E, $H) {

        $C.set('v.responsePending', true);

        var buyInIndex  = $E.currentTarget.dataset.buyinindex;
        var buyInId     = $E.currentTarget.dataset.buyinid;

        var deleteBuyInApex = $C.get('c.deleteBuyInApex');
        deleteBuyInApex.setParams({ buyInId: buyInId });
        deleteBuyInApex.setCallback(this, function (response) {

            $C.set('v.responsePending', false);
            if (response.getState() === 'SUCCESS') {
                var buyIns = $C.get('v.BuyIns');
                buyIns.splice(buyInIndex, 1);
                $C.set('v.BuyIns', buyIns);
            }
        });
        $A.enqueueAction(deleteBuyInApex);
    },
    setViewPitches: function ($C, $E) {

        $E.stopPropagation();
        $C.set('v.mode', 'browse-pitches');

        var opp = $C.get('v.Opportunity');
        $C.set('v.Header', ' PITCHES AT ' + opp.Park__r.Name.toUpperCase());

        var unitIndex       = $E.currentTarget.dataset.inventoryindex;
        var unitId          = $E.currentTarget.dataset.inventoryid;
        var pitchIndex      = $E.currentTarget.dataset.index;
        var unitPitchId     = $E.currentTarget.dataset.unitpitchid;
        var unitSelections  = $C.get('v.UnitSelections');
        var unitSelection   = unitSelections[unitIndex];
        var currentPitches  = unitSelection.Pitch_Selections__r;

        var pitchIds = [];

        if (currentPitches && currentPitches.length) {
            currentPitches.forEach(function (pitch) {
                pitchIds.push(pitch.Pitch__c);
            });
        }

        var inventoryItem = unitSelection;
        var pitches = $C.get('v.Pitches');

        pitches.forEach(function (pitch) {

            var notSelected         = !pitchIds.includes(pitch.Id);
            var lengthCompatible    = pitch.Length__c >= inventoryItem.Length__c;
            var widthCompatible     = pitch.Width__c >= inventoryItem.Width__c;
            var yearComplatible     = !pitch.Minimum_Model_Year__c || inventoryItem.Model_Year__c >= pitch.Minimum_Model_Year__c;
            var lodgeCompatible     = !pitch.Lodge_Only_Pitch__c || inventoryItem.Type__c == 'Lodge';
            var minimumMargin       = !pitch.Minimum_Pitch_Margin__c || inventoryItem.Margin_Including_Connections__c >= pitch.Minimum_Pitch_Margin__c;

            pitch.Include = notSelected && lengthCompatible && widthCompatible && yearComplatible && lodgeCompatible && minimumMargin;

            pitch.Promotions = [];

            if (inventoryItem.PitchPromotions && inventoryItem.PitchPromotions.length) {
                inventoryItem.PitchPromotions.forEach(function (promo) {
                    if (promo.Pitch_Numbers__c.includes(pitch.Name)) {
                        pitch.Promotions.push(promo);
                    }
                });
            }
        });

        $C.set('v.SelectedUnitIndex', unitIndex);
        $C.set('v.SelectedUnitId', unitId);
        $C.set('v.SelectedUnitPitchIndex', pitchIndex);
        $C.set('v.SelectedUnitPitchId', unitPitchId);
        $C.set('v.Pitches', pitches);
    },
    evalPitches: function ($C, $E, $H) {

        var pitchSettings = $C.get('v.PitchSettings');
        var pitches = $C.get('v.Pitches');

        if (pitches.length) {
            pitches.forEach(function (pitch) {

                var Status  = !pitchSettings.Status || pitchSettings.Status == 'Any' || pitchSettings.Status == pitch.Search_Status__c;
                var Banding = !pitchSettings.Banding || pitchSettings.Banding == 'Any' || pitchSettings.Banding == pitch.Banding__c;
                var Area    = !pitchSettings.Area || pitchSettings.Area == 'Any' || pitchSettings.Area == pitch.Areas__r.Name;
                var View    = !pitchSettings.View || pitchSettings.View == 'Any' || pitchSettings.View == pitch.View__c;

                pitch.Show = Status && Banding && Area && View;
            });

            $C.set('v.Pitches', pitches);
        }
    },
    setPitchFocus: function ($C, $E) {
        var dataset = $E.currentTarget.dataset;
        var clickedPitch = dataset.pitchid;

        $C.set('v.PitchInFocus', clickedPitch);

        if (dataset.scroll) {
            document.getElementById(clickedPitch).scrollIntoView();
        }

        if (document.getElementById(clickedPitch + 'pin')) {
            document.getElementById(clickedPitch + 'pin').scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
        }
    },
    selectPitch: function ($C, $E, $H) {

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Adding pitch to your selections...');

        var unitSelections  = $C.get('v.UnitSelections');
        var selectionId     = $C.get('v.SelectedUnitId');
        var selectionIndex  = $C.get('v.SelectedUnitIndex');
        var unit            = unitSelections[selectionIndex];
        var pitchId         = $E.currentTarget.dataset.pitchid;
        var opportunity     = $C.get('v.Opportunity');
        var selectPitchApex = $C.get('c.selectPitchApex');

        selectPitchApex.setParams({
            selectionId: selectionId, pitchId: pitchId,
            opportunityId: $C.get('v.recordId'), parkId: opportunity.Park__c,
            stageName: opportunity.StageName
        });
        selectPitchApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');

            console.log(response.getState(), response.getReturnValue());
            if (response.getState() === 'SUCCESS' && response.getReturnValue().UnitPitchSelections) {

                var pitchSelections = response.getReturnValue().UnitPitchSelections[0].Pitch_Selections__r;
                var pitchSelectionItems = response.getReturnValue().PitchSelectionItems;
                $H.processPitchSelections($C, pitchSelections, pitchSelectionItems, unit.PitchPromotions);
                unitSelections[selectionIndex].Pitch_Selections__r = pitchSelections;

                $C.set('v.mode', 'show-selections');
                $C.set('v.Header', 'YOUR SELECTIONS');
                $C.set('v.UnitSelections', unitSelections);
                $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "Pitch selection added" }).fire();
                $A.get('e.force:refreshView').fire();

                // reserialize item state 
                delete unitSelections[selectionIndex].State__c;
                var unitJSON = JSON.stringify(unitSelections[selectionIndex]);
                unitSelections[selectionIndex].State__c = unitJSON;

                var updateSelectionStateApex = $C.get('c.updateSelectionStateApex');
                updateSelectionStateApex.setParams({ selectionId: selectionId, unitJSON: unitJSON });
                updateSelectionStateApex.setCallback(this, function (response) {
                    console.log(response.getReturnValue());
                });
                $A.enqueueAction(updateSelectionStateApex);

            } else {
                $A.get("e.force:showToast").setParams({
                    "title": "Error!",
                    "type": "error",
                    "message": response.getReturnValue()
                }).fire();
            }

        });
        $A.enqueueAction(selectPitchApex);
    },
    removePitchSelection: function ($C, $E) {
        $E.stopPropagation();

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Removing pitch from your selections');

        var unitSelections      = $C.get('v.UnitSelections');
        var selectionIndex      = $E.currentTarget.dataset.inventoryindex;
        var selectionPitchIndex = $E.currentTarget.dataset.index;
        var pitchId             = $E.currentTarget.dataset.unitpitchid;

        var removePitchApex = $C.get('c.removePitchApex');
        removePitchApex.setParams({ pitchSelectionId: pitchId });
        removePitchApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');
            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success') {

                unitSelections[selectionIndex].Pitch_Selections__r.splice(selectionPitchIndex, 1);
                $C.set('v.UnitSelections', unitSelections);
                $A.get("e.force:showToast").setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "Pitch selection removed"
                }).fire();
            } else {
                $A.get("e.force:showToast").setParams({
                    "title": "Error!",
                    "type": "error",
                    "message": response.getReturnValue()
                }).fire();
            }
        });
        $A.enqueueAction(removePitchApex);
    },
    createQuote: function ($C, $E, $H) {

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Generating your quote, this can take a moment...');

        var rates               = $C.get('v.Rates');
        var pXUnits             = $C.get('v.BuyIns');
        var unitSelections      = $C.get('v.UnitSelections');
        var unitSelectionIndex  = $C.get('v.SelectedUnitIndex');
        var unitSelection       = unitSelections[unitSelectionIndex];
        var pitchSelectionIndex = $C.get('v.SelectedUnitPitchIndex');
        var pitchSelection      = unitSelection.Pitch_Selections__r[pitchSelectionIndex];

        var promotionIds = [];

        var packageEstimate = $C.get('v.PackageEstimate');
        if (packageEstimate.Promotions && packageEstimate.Promotions.length) {
            packageEstimate.Promotions.forEach(function (promo) {
                if (promo.Selected) {
                    promotionIds.push(promo.Id);
                }
            });
        }

        var selectedPXUnits = [];
        pXUnits.forEach(function (unit) {
            if (unit.Selected) {
                delete unit.Quote_Lines__r;
                selectedPXUnits.push(unit);
            }
        });

        var quoteContent = {
            OpportunityId: $C.get('v.recordId'),
            BuyIns: selectedPXUnits,
            UnitSelectionId: unitSelection.Id,
            SalePrice: packageEstimate.UnitPrice, 
            PitchSelectionId: pitchSelection.Id,
            Tenure: unitSelection.Tenure,
            TenureCalculation: unitSelection.TenureCalculation,
            PitchFees: pitchSelection.Price,
            IncludePitchFeesNextYear: packageEstimate.PitchFeesNextYearSelected,
            PitchFeesNextYear: pitchSelection.PriceNextYear,
            PitchRefundThisYear: packageEstimate.RefundThisYear,
            PitchRefundNextYear: packageEstimate.RefundNextYear,
            PitchVAT : packageEstimate.PitchVAT,
            RatesProducts: rates.RatesProducts,
            RatesThisYear: rates.RatesThisYear,
            RatesRefundThisYear: packageEstimate.RatesRefundThisYear,
            RatesRefundNextYear: packageEstimate.RatesRefundNextYear,
            RatesVAT : packageEstimate.RatesVAT,
            IncludeRatesNextYear: packageEstimate.RatesNextYearSelected,
            RatesNextYear: rates.RatesNextYear,
            PromotionIds: promotionIds,
            ActualMargin: packageEstimate.ActualMarginAfterMFO,
            MarginBeforeMFO : packageEstimate.MarginBeforeMFO,
            CommissionableMFO : packageEstimate.CommissionableMFO,
            NewForOldId: packageEstimate.NewForOldId,
            MarketValueId: packageEstimate.MarketValueId,
            NewForOldContentProRataNetPrice: packageEstimate.NewForOldContentProRataNetPrice,
            MarketValueInsProRataNetPrice: packageEstimate.MarketValueInsProRataNetPrice,
            MarketValueContentProRataNetPrice: packageEstimate.MarketValueContentProRataNetPrice,
            NewForOldInsProRataNetPrice: packageEstimate.NewForOldInsProRataNetPrice,
            AlarmProRataNetPrice: packageEstimate.AlarmProRataNetPrice
        };

        console.log(quoteContent);
        console.log(JSON.parse(JSON.stringify(quoteContent)));

        var createQuoteApex = $C.get('c.createQuoteApex');
        createQuoteApex.setParams({ contentString: JSON.stringify(quoteContent) });
        createQuoteApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');
            $H.showQuoteResponse(response);
        });

        $A.enqueueAction(createQuoteApex);
    },
    createPitchMoveQuote: function ($C, $E, $H) {

        $C.set('v.responsePending', true);
        $C.set('v.PendingMessage', 'Generating your quote, this can take a moment...');

        var rates               = $C.get('v.Rates');
        var unitSelections      = $C.get('v.UnitSelections');
        var unitSelectionIndex  = $C.get('v.SelectedUnitIndex');
        var unitSelection       = unitSelections[unitSelectionIndex];
        var pitchSelectionIndex = $C.get('v.SelectedUnitPitchIndex');
        var pitchSelection      = unitSelection.Pitch_Selections__r[pitchSelectionIndex];

        var promotionIds = [];

        var pitchPackageEstimate = $C.get('v.PitchPackageEstimate');
        if (pitchPackageEstimate.Promotions && pitchPackageEstimate.Promotions.length) {
            pitchPackageEstimate.Promotions.forEach(function (promo) {
                if (promo.Selected) {
                    promotionIds.push(promo.Id);
                }
            });
        }

        var quoteContent = {
            OpportunityId: $C.get('v.recordId'),
            UnitSelectionId: unitSelection.Id,
            PitchSelectionId: pitchSelection.Id,
            PitchFees: pitchPackageEstimate.PitchFees,
            IncludePitchFeesNextYear: pitchPackageEstimate.PitchFeesNextYearSelected,
            PitchFeesNextYear: pitchPackageEstimate.PitchFeesNextYear,
            PitchRefundThisYear: pitchPackageEstimate.RefundThisYear,
            PitchRefundNextYear: pitchPackageEstimate.RefundNextYear,
            // RatesProducts: rates.RatesProducts,
            // RatesThisYear: rates.RatesThisYear,
            // IncludeRatesNextYear: false,
            // RatesNextYear: rates.RatesNextYear,
            PromotionIds: promotionIds
        };

        console.log(quoteContent);
        console.log(JSON.parse(JSON.stringify(quoteContent)));

        console.log('finish parse');

        var createPitchMoveQuoteApex = $C.get('c.createPitchMoveQuoteApex');
        createPitchMoveQuoteApex.setParams({ contentString: JSON.stringify(quoteContent) });
        createPitchMoveQuoteApex.setCallback(this, function (response) {
            $C.set('v.responsePending', false);
            $C.set('v.PendingMessage', '');
            $H.showQuoteResponse(response);
        });

        $A.enqueueAction(createPitchMoveQuoteApex);
        console.log('action enqueued');
    },
    plusSlides: function ($C, $E) {

        $E.stopPropagation();

        var unitSelections = $C.get('v.UnitSelections');
        var invItems = $C.get('v.InventoryItems');

        var dataset = $E.currentTarget.dataset;
        var itemIndex = dataset.index;
        var imgNumber = parseInt(dataset.int);
        var itemType = dataset.type;

        if (itemType === 'selection') {
            unitSelections[itemIndex].ActiveIndex += imgNumber;

            if (unitSelections[itemIndex].ActiveIndex === unitSelections[itemIndex].Stock_Images__r.length) {
                unitSelections[itemIndex].ActiveIndex = 0;
            } else if (unitSelections[itemIndex].ActiveIndex < 0) {
                unitSelections[itemIndex].ActiveIndex = unitSelections[itemIndex].Stock_Images__r.length - 1;
            }
            $C.set('v.UnitSelections', unitSelections);
        } else if (itemType === 'inventory') {
            invItems[itemIndex].ActiveIndex += imgNumber;

            if (invItems[itemIndex].ActiveIndex === invItems[itemIndex].Stock_Images__r.length) {
                invItems[itemIndex].ActiveIndex = 0;
            } else if (invItems[itemIndex].ActiveIndex < 0) {
                invItems[itemIndex].ActiveIndex = invItems[itemIndex].Stock_Images__r.length - 1;
            }
            $C.set('v.InventoryItems', invItems);
        } else if (itemType === 'primary') {

            var primary = $C.get('v.PrimarySelection');

            primary.ActiveIndex += imgNumber;

            if (primary.ActiveIndex === primary.Stock_Images__r.length) {
                primary.ActiveIndex = 0;
            } else if (primary.ActiveIndex < 0) {
                primary.ActiveIndex = primary.Stock_Images__r.length - 1;
            }
            $C.set('v.PrimarySelection', primary);
        }
    },
    currentSlide: function ($C, $E) {

        $E.stopPropagation();

        var unitSelections  = $C.get('v.UnitSelections');
        var invItems        = $C.get('v.InventoryItems');
        var dataset         = $E.currentTarget.dataset;
        var itemIndex       = dataset.index;
        var imgNumber       = parseInt(dataset.imgindex);
        var itemType        = dataset.type;

        if (itemType === 'selection') {
            unitSelections[itemIndex].ActiveIndex = imgNumber;
            $C.set('v.UnitSelections', unitSelections);
        } else if (itemType === 'inventory') {
            invItems[itemIndex].ActiveIndex = imgNumber;
            $C.set('v.InventoryItems', invItems);
        } else if (itemType === 'primary') {
            var primary = $C.get('v.PrimarySelection');
            primary.ActiveIndex = imgNumber;
            $C.set('v.PrimarySelection', primary);
        }
    },
    display: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    },
    displayOut: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    },
    stopPropagation: function ($C, $E, $H) {
        $E.stopPropagation();
    },

    /**
    * pagination
    */
    onNext: function(component, event, helper) {
        let pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },

    onPrev: function(component, event, helper) {
        let pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },

    processMe: function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    },

    onFirst: function(component, event, helper) {
        component.set("v.currentPageNumber", 1);
        helper.buildData(component, helper);
    },

    onLast: function(component, event, helper) {
        component.set("v.currentPageNumber", component.get("v.totalPages"));
        helper.buildData(component, helper);
    }
})