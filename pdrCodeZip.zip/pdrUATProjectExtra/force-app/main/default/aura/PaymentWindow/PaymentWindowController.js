({
    init : function(component, event, helper) {
        component.find("sharedMethods").createComponent("PaymentCardholderInformation", { "recordId": component.get("v.recordId") });
    },
    doEventAction : function(component, event, helper) {
        var key = event.getParam("key");
        var type = event.getParam("type");
        var data = event.getParam("data");
        var componentContainer = event.getParam("componentContainer");

        if (type === "openWindow") {
            console.log(type, key, data);
            component.find("sharedMethods").createComponent(key, data);
        } else if (type === "insertComponent") {
            console.log(type, componentContainer);
            component.set("v.componentContainer", [ componentContainer ]);
        }
    }
})