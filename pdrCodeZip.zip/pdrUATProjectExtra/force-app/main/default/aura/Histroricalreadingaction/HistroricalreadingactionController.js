({
    /*myAction : function(component, event, helper) {

    }*/
    Close:function(component){
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    }
})