({
    logout : function(component, event, helper) {
    
    //Return to login page
    var urlString = window.location.href;
    var baseURL = urlString.substring(0, urlString.indexOf('/s'));
      console.log(baseURL);
    
    var retUrl = baseURL + '/secur/logout.jsp';
      window.location.replace(retUrl);
    }
})