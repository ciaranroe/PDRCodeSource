({
    doInit : function(component, event, helper) {  
        helper.getRelatedHHList(component, event, helper);
        helper.setCaseTypePicklistValues(component, event, helper);
      
    },

    getSelectedAccount: function (component, event, helper){
        var account =  component.find("hhPickList").get("v.value");
        console.log('Selected account--->'+account);
        component.set("v.selectedAccount", account);
    },

    getSubject: function(component, event, helper){
        var subject = component.find("subjPickList").get("v.value");
        console.log(' selected ' + subject);
        component.set("v.subject", subject);
        var enquiry = component.get("v.caseEnquiry");
        console.log(subject, enquiry);
        if (enquiry.length > 0 && subject != '' && subject != '--None--') {
            component.set("v.submitDisabled", false);
        } else {
            component.set("v.submitDisabled", true);
        }
    },

    getEnquiry: function(component, event, helper){
        var enquiry = event.target.value;
        component.set("v.caseEnquiry", enquiry);
        var subject = component.get("v.subject");
        console.log(subject, enquiry);
        if (enquiry.length > 0 && subject != '' && subject != '--None--') {
            component.set("v.submitDisabled", false);
        } else {
            component.set("v.submitDisabled", true);
        }
    },

    submitCase: function(component, event, helper){

        console.log('recordId is ', component.get('v.recordId'));

        var enquiry = component.get("v.caseEnquiry");
        var subject = component.get("v.subject");
        if (!subject  || !enquiry) {
            helper.showError(component, event, helper, 'Subject and Enquiry must be populated');
        } else {
            helper.submitCase(component, event, helper);
            component.set("v.submitted", true);
            setTimeout(function() {
              component.set("v.submitted", false);
            }, 15000);
        }
    },

    setCaseTypePicklistValues : function(component, event, helper) {
        // console.log('setCaseTypePicklistValues');
        // var result = event.getParam('values');
        // console.log('result',JSON.parse(JSON.stringify(result)));
        // var fieldMap = [];
        // var order = ["--None--", "My account", 
        //             "My Lets", "Membership cards", "Activities and events", 
        //             "I'm thinking about leaving/selling my holiday home", 
        //             "I'm interested in upgrading my holiday home", 
        //             "I'd like to change my address",
        //             "Something else"];
        // for (var o = 0; o < order.length; o++) {
        //   var val = order[o];
        //   for (var key in result) {
        //       console.log('result[key].value == val',result[key].value,val,result[key].value == val);
        //     if (result[key].value == val) {
        //       console.log(result[key].value);
        //       fieldMap.push({lab: val == "--None--" ? "I have a question about.." : result[key].label, val: result[key].value});
        //     }     
        //   }
        // }
        // component.set("v.caseTypeMap", fieldMap);
    }
})