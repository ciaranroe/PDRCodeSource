({
    getRelatedHHList: function(component, event, helper){
    
        var action = component.get("c.getRelatedAccountsList");
            
            action.setCallback(this, function(actionResult) {
                
                var state = actionResult.getState();
  
                if ( state === "SUCCESS") {
                    var accountId = actionResult.getReturnValue();
                    component.set("v.acctList", actionResult.getReturnValue());
                    for (var i = 0; i < accountId.length; i++) {
                        console.log('Selected account--->'+accountId[0].Id);
                        component.set("v.selectedAccount",accountId[0].Id);
                    }
                    console.log('>>>>>>>'+JSON.stringify(component.get("v.acctList")));
                }   
            });
            
            $A.enqueueAction(action);
    },

    setCaseTypePicklistValues : function(component, event, helper) {

        console.log('setCaseTypePicklistValues');
        var fieldMap = [];
        var order = ["My account", 
                    "My Lets", "Membership cards", "Activities and events", 
                    "I'm thinking about leaving/selling my holiday home", 
                    "I'm interested in upgrading my holiday home", 
                    "I'd like to change my address",
                    "Something else"];
        for (var o = 0; o < order.length; o++) {
            var val = order[o];
            fieldMap.push({lab: val == "--None--" ? "I have a question about.." : val, val: val});
        }
        component.set("v.caseTypeMap", fieldMap);
    },

    getTypePicklistValues: function(component, event, helper) {
        var action = component.get("c.getCaseTypeValues");
        action.setCallback(this, function(response) {
            console.log('c.getCaseTypeValues',response.getState(),response.getReturnValue());
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var fieldMap = [];
                for(var key in result){
                    fieldMap.push({key: key, value: result[key]});
                }
                console.log('*************FieldMap ' + fieldMap);
                component.set("v.caseTypeMap", fieldMap);
               
            }
        });
        $A.enqueueAction(action);
    },

    submitCase: function(component, event, helper){
        console.log('******Submit Case');
        //Get the update values

        var accountId = component.get("v.selectedAccount");
        console.log('-=Helper Selected Account--->'+accountId);
        var subject = component.get("v.subject");
        var enquiry = component.get("v.caseEnquiry");
      
        var action = component.get("c.createCase");

            action.setParams({"subject": subject,
                             "acctId": accountId,
                             "enquiry": enquiry});
                             console.log('******Params  ' + accountId +  subject + enquiry);
        action.setCallback(this, function(actionResult){

            console.log('component.get("c.createCase")',actionResult.getState(),actionResult.getReturnValue());

            var state = actionResult.getState();

            if(state === "SUCCESS"){

                console.log('******New Case ' + actionResult.getReturnValue());
                /*var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "You've successfully submitted a case"
                });
                toastEvent.fire();*/
            }
        });
        $A.enqueueAction(action);
    },

    reloadPage: function(component, event, helper){
        window.location.reload();
    },
    
    showError : function(component, event, helper, errorMessage) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Error',
            message: errorMessage,
            duration:' 5000',
            key: 'info_alt',
            type: 'error',
            mode: 'pester'
        });
        toastEvent.fire();
    }
})