({  
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },

    getUploadedFiles : function(component, event, helper){
        var action = component.get("c.getFiles");  
 
        action.setParams({  
            "recordId": component.get("v.accountId") 
        });      
        action.setCallback(this,function(response){  
            var state = response.getState();  
            if(state=='SUCCESS'){  
                var result = response.getReturnValue();    

                component.set("v.files",result);  
            }  
        });  
        $A.enqueueAction(action);  
    }
 })