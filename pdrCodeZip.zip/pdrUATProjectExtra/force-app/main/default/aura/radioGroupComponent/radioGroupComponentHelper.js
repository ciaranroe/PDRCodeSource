({
	fetchOptionValues : function(component, event, helper) {
		//callServer - this method is in the BaseLightningComponent
        var params = {
            "objectApiName" : component.get('v.objectApiName'),
            "fieldApiName" : component.get('v.fieldApiName')
        }
		helper.callServer(component, 
                          "c.fetchPicklistOptions",
                          function(resultStr) {
                              var resultWrapper = JSON.parse(resultStr);
                              if (resultWrapper.hasError) {
                                  console.log("Error: " + resultWrapper.message);
                              }
                              else {
                                  this.handleResultSuccess(component, event, helper, resultWrapper);
                              }
                          } ,
                          {
                              "parameterString": JSON.stringify(params)
                          }
                         );
	},
    handleResultSuccess : function(component, event, helper, resultWrapper) {
        //actions on success
        console.log(resultWrapper.optionsList);
        component.set('v.options', resultWrapper.optionsList);
	}
})