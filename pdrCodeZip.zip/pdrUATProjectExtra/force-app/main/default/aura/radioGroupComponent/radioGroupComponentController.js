({
	doInit : function(component, event, helper) {
		helper.fetchOptionValues(component, event, helper);
	}
})