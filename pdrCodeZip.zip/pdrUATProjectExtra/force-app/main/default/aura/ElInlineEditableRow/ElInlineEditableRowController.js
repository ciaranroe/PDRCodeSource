({


    inlineEditName: function (component, event, helper) {
        var editable = component.get("v.thisEditable");
        if (editable) {
            component.set("v.nameEditMode", true);
            setTimeout(function () {
                component.find("inputId").focus();
            }, 100);
        }
    },
    inlineEditSummer: function (component, event, helper) {
        var editable = component.get("v.thisEditable");
        if (editable) {
            component.set("v.summerEditMode", true);
            setTimeout(function () {
                component.find("summer").focus();
            }, 100);
        }
    },
    inlineEditPeak: function (component, event, helper) {
        var editable = component.get("v.thisEditable");
        if (editable) {
            component.set("v.peakEditMode", true);
            setTimeout(function () {
                component.find("peak").focus();
            }, 100);
        }

    },
    inlineEditTotal: function (component, event, helper) {
        var editable = component.get("v.thisEditable");
        if (editable) {
            component.set("v.totalEditMode", true);
            setTimeout(function () {
                component.find("total").focus();
            }, 100);
        }
    },
    totalEditPeak: function (component, event, helper) {
        component.set("v.totalEditMode", true);
        setTimeout(function () {
            component.find("total").focus();
        }, 100);
    },

    inlineEditStartDate: function (component, event, helper) {
        var editable = component.get("v.thisEditable");
        if (editable) {
            component.set("v.startDateEditMode", true);
            setTimeout(function () {
                component.find("StartDate").focus();
            }, 100);
        }
    },

    onNameChange: function (component, event, helper) {
        // if edit field value changed and field not equal to blank,
        // then show save and cancel button by set attribute to true
        if (event.getSource().get("v.value").trim() != '') {
            component.set("v.showSaveCancelBtn", true);
            helper.validateFields(component, event, helper);
        }
    },
    onSummerChange: function (component, event, helper) {
        helper.validateFields(component, event, helper);
        component.set("v.showSaveCancelBtn", true);
    },
    onPeakChange: function (component, event, helper) {
        helper.validateFields(component, event, helper);
        component.set("v.showSaveCancelBtn", true);
    },
    onTotalChange: function (component, event, helper) {
        helper.validateFields(component, event, helper);
        component.set("v.showSaveCancelBtn", true);
    },

    onStartDateChange: function (component, event, helper) {
        helper.validateFields(component, event, helper);
        component.set("v.showSaveCancelBtn", true);
    },

    closeNameBox: function (component, event, helper) {
        // on focus out, close the input section by setting the 'nameEditMode' att. as false   
        component.set("v.nameEditMode", false);
        // check if change/update Name field is blank, then add error class to column -
        // by setting the 'showErrorClass' att. as True , else remove error class by setting it False   
        if (event.getSource().get("v.value").trim() == '') {
            component.set("v.showErrorClass", true);
        } else {
            component.set("v.showErrorClass", false);
        }
    },

    closeStartDateBox: function (component, event, helper) {

        component.set("v.startDateEditMode", false);
    },
    closeSummerBox: function (component, event, helper) {
        component.set("v.summerEditMode", false);
    },
    closePeakBox: function (component, event, helper) {
        component.set("v.peakEditMode", false);
    },
    closeTotalBox: function (component, event, helper) {
        component.set("v.totalEditMode", false);
    },
    doInit: function (component, event, helper) {
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");

        var obj = component.get('v.singleRec');
        var date = obj.Start_Date__c;

        if (date != '' && date < today) {
            component.set('v.thisEditable', false);
        }
    },
    removeLine: function (component, event, helper) {
        var obj = component.get('v.singleRec');
        var sNo = component.get('v.sNo');
        var parkGroup = component.get('v.ParkGroup');
        var indexVar = sNo - 1;
        if (obj.Id == '') {
            component.getEvent("DeleteRowEvt").setParams({ "indexVar": indexVar, "parkGroup": parkGroup }).fire();
        }
        else {
            var deleteScheduleApex = component.get('c.deleteScheduleApex');
            deleteScheduleApex.setParams({ schedule: obj });
            deleteScheduleApex.setCallback(this, function (response) {
                var state = response.getState();
                if (state == 'SUCCESS') {
                    component.getEvent("DeleteRowEvt").setParams({ "indexVar": indexVar, "parkGroup": parkGroup }).fire();
                }
            });
            $A.enqueueAction(deleteScheduleApex);
        }
    },



})