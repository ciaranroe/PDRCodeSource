({
  validateFields: function (component, event, helper) {
    var obj = component.get('v.singleRec');
    var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
    var startDate = obj.Start_Date__c;
    var minSummerWeeks = obj.Minimum_Summer_Weeks__c;
    var minPeakWeeks = obj.Minimum_Peak_Weeks__c;
    var minWeeks = obj.Minimum_Weeks__c;
    var name = obj.Name;
    var parkGroup = component.get('v.ParkGroup');
    console.log(parkGroup);
    if (today > startDate || minWeeks < minPeakWeeks || minWeeks < minSummerWeeks || minPeakWeeks < minSummerWeeks || name == '') {
      component.set('v.showErrorClass', true);
    }
    else {
      component.set('v.showErrorClass', false);
    }
    console.log("parkGroup:   " + parkGroup);
    component.getEvent("CheckForElScheduleErrors").setParams({ "parkGroup": parkGroup }).fire();
  }
})