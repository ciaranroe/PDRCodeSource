({
    viewDocs : function(component, event, helper) {
        var accountId = component.get("v.recordId");
        
        component.set("v.acctId", accountId);
        
        var address = component.get("v.documentPageURL") + '?accountId=' + accountId;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isredirect" :false
        });
        urlEvent.fire();
    }
})