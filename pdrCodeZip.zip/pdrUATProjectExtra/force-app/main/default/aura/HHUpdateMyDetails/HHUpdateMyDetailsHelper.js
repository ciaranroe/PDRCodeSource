({
    getAccountDetails : function(component, event, helper) {
        var action = component.get("c.getAccountDetails");

        action.setCallback(this, function(actionResult){
            var state = actionResult.getState();

            if(component.isValid() && state === "SUCCESS"){
                component.set("v.acctList", actionResult.getReturnValue());

                console.log("-------->AccountDetails " + actionResult.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    }
    
})