({
    doInit: function(component, event, helper) {
      component.set("v.clean", true);
       helper.getAccountDetails(component, event, helper);

    },

    updateDetails: function(component, event, helper){
        
        component.set("v.status", "Updating..");
        component.set("v.clean", true);
        
        //Get the update values
        var acctMobileNumber = component.get("v.mobileNumber");
        var acctEveningNumber = component.get("v.eveningNumber");
        var acctDaytimeNumber = component.get("v.daytimeNumber");
       
        //Retrieve the account Id to update
        var  acctList = component.get("v.acctList");
        var accountId = acctList[0].Id;
      

        var action = component.get("c.updateAccountDetails");

            action.setParams({"daytimeNumber": acctDaytimeNumber,
                             "eveningNumber": acctEveningNumber,
                             "mobileNumber": acctMobileNumber,
                             "accountId":accountId });

        action.setCallback(this, function(actionResult){
            var state = actionResult.getState();

            if(state === "SUCCESS"){
        	  component.set("v.status", "Updated!");
            }
        });
        $A.enqueueAction(action);
    },

    getMobileNumber: function (component, event, helper){
      var mobileNumber =  event.target.value;
      component.set("v.clean", false);
      component.set("v.status", "Update My Details");
      component.set("v.mobileNumber", mobileNumber);
      helper.checkForm();
    },

    getEveningNumber: function(component, event, helper){
      var eveningNumber = event.target.value;
      component.set("v.clean", false);
      component.set("v.status", "Update My Details");
      component.set("v.eveningNumber", eveningNumber);
      helper.checkForm();
    },

    getDayNumber: function(component, event, helper){
      var dayNumber = event.target.value;
      component.set("v.clean", false);
      component.set("v.status", "Update My Details");
      component.set("v.daytimeNumber", dayNumber);
      helper.checkForm();
    }

})