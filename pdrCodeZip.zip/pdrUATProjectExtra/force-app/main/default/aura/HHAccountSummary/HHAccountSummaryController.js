({
    
    doInit : function(component, event, helper) {
     // helper.getAccountlist(component, event, helper);
      helper.getAccountDetails(component, event, helper);
      helper.getRelatedAccountList(component, event, helper);
      helper.getLatestDirectDebit(component, event, helper);
      helper.getLastPayment(component, event, helper);
      helper.getNextPayment(component, event, helper);
    },

    navigateToStatementTab: function(component, event, helper){
      var url = window.location.origin + window.location.pathname + window.location.search + '#3';
      var urlEvent = $A.get("e.force:navigateToURL");
      urlEvent.setParams({ "url": url });
      urlEvent.fire();
    },

    navigateToDocumentTab: function(component, event, helper){
      var url = window.location.origin + window.location.pathname + window.location.search + '#4';
      var urlEvent = $A.get("e.force:navigateToURL");
      urlEvent.setParams({ "url": url });
      urlEvent.fire();
    },

    navigateToLettingsTab: function(component, event, helper){
      var url = window.location.origin + "/s/hh-letting-schemes" + window.location.search;
      var urlEvent = $A.get("e.force:navigateToURL");
      urlEvent.setParams({ "url": url });
      urlEvent.fire();
    }
})