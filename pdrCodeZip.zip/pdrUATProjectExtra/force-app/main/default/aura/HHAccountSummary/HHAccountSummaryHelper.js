({
     getAccountlist: function(component, event, helper){
        var action = component.get("c.getRelatedAccountsList");
        
        action.setCallback(this, function(actionResult) {
            
            var state = actionResult.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                
                    var accountId = actionResult.getReturnValue();
                    for (var i = 0; i < accountId.length; i++) {
                        console.log('Selected account--->'+accountId[0].Id);
                        component.set("v.accountId",accountId[0].Id);
                        //component.set('v.acctList', accountId[0]);  
                    }
                //component.set('v.acctList', accountId); 
            }  
            else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        
        $A.enqueueAction(action);
    },//Change
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },
    
    getAccountDetails: function(component, event, helper){
        var action = component.get("c.getAcctDetails");
        if(component.get("v.accountId") == null){
            this.parsePageUrlParameter(component, event, helper);
            action.setParams({recordId:component.get("v.accountId")});
           /* if(component.get("v.accountId") == null){
                var action1 = component.get("c.getRelatedAccountsList");
                action1.setCallback(this, function(actionResult1) {
                    var state1 = actionResult1.getState();
                    if (component.isValid() && state1 === "SUCCESS") {
                            var accountId = actionResult1.getReturnValue();
                            console.log('Selected account--->'+accountId[0].Id);
                            component.set("v.account1Id",accountId[0].Id);
                            console.log('==11001=>>'+component.get("v.account1Id"));
                            action.setParams({recordId:component.get("v.account1Id")});
                    }  
                    else if (state === "ERROR") {
                        var errors = response.getError();
                        console.error(errors);
                    }
                });
                
                $A.enqueueAction(action1);
                 console.log('==1100=>>'+component.get("v.accountId"));
            }  
        }
        if(component.get("v.account1Id") != null){
            action.setParams({recordId:component.get("v.account1Id")});
            console.log('==11 test 23=>>'+component.get("v.account1Id"));
        }*/
            }
        else{
            action.setParams({
                recordId:component.get("v.accountId")  
            });
        }
        
        action.setCallback(this, function (response) {
            
            var state = response.getState();   
            
            if (state === "SUCCESS") {
                
                var records = response.getReturnValue();
                component.set('v.acctList', records);   
               
                this.getRemindersSettings(component, event, helper);
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    getRelatedAccountList: function(component, event, helper){
        var action = component.get("c.getAccountHolderList");
        action.setParams({accountId:component.get("v.accountId")});
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                component.set('v.relatedAcctHolder', records);   
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); 
    },
    
    getLatestDirectDebit: function(component, event, helper){
        var action = component.get("c.getLatestDirectDebit");
        	action.setParams({accountId:component.get("v.accountId")});
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var records = response.getReturnValue();
            
            if(state === "SUCCESS"){
                component.set('v.latestDirectDebit',  records);
            }
        });
         $A.enqueueAction(action); 
    },
    
    getLastPayment: function(component, event, helper){
        var action = component.get("c.getLastPayment");
        	action.setParams({accountId:component.get("v.accountId")});
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var records = response.getReturnValue();
            if(state === "SUCCESS"){
                component.set('v.lastPayment', records);
            }
        });
         $A.enqueueAction(action); 
    },
    
    getNextPayment: function(component, event, helper){
        var action = component.get("c.getNextPayment");
        	action.setParams({accountId:component.get("v.accountId")});
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var records = response.getReturnValue();
            
            if(state === "SUCCESS"){
                component.set('v.nextPayment', records);
            }
        });
         $A.enqueueAction(action); 
    },

    getRemindersSettings: function(component, event, helper){
        var action = component.get("c.retrieveCommunityCustomSettingsDetails");
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var records = response.getReturnValue();
                component.set('v.cSettings', records);
               
            }else if (state === "ERROR"){
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); 
    }
    
})