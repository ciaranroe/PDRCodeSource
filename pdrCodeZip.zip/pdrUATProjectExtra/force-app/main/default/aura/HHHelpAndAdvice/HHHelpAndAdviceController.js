({
    openSingleFile: function(component, event, helper) {
       helper.previewFile(component, event, helper);
    },

    downloadFile:function(component, event, helper){
        helper.downloadFile(component, event, helper);
    },
})