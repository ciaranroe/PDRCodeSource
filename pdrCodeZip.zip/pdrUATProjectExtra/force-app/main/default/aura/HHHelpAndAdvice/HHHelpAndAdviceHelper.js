({

    downloadFile: function(component, event, helper) {
        
        var eventFieldName = event.currentTarget.getAttribute("data-id");
        
        var downloadRecord = component.get("c.getcSettingURL");
        
        console.log('event name: ' + eventFieldName);
        
        downloadRecord.setParams({
            recordFileId : component.get("v.documentId"),
            fieldName : eventFieldName
            
        });
        
		downloadRecord.setCallback(this, function(response) {
            
            var state = response.getState();
     
            if(state === "SUCCESS") {
                var fileDownloadUrl = response.getReturnValue();
              
                console.log('downloadFile: ', fileDownloadUrl);
                window.open(fileDownloadUrl, '_blank');
                
               
            } else if (state === "ERROR") {
                
                var errors = response.getError();
                console.log('error:' + errors);
                console.log(JSON.stringify(errors));
                
            }        
        });
        $A.enqueueAction(downloadRecord);        
    },
    
    previewFile: function(component, event, helper){
        var idFile = event.currentTarget.getAttribute("data-id");
        console.log('event name: ' + idFile);
        var previewRecord = component.get("c.getUrlDocument");
        
        previewRecord.setParams({
            recordFileId : component.get("v.documentId"),
            fieldName : idFile            
        });
        previewRecord.setCallback(this, function(response) {
            var state = response.getState();
            
            if(state === "SUCCESS") {
            console.log(response.getReturnValue());
            
                var downloadContent = response.getReturnValue();
                
            	var splitname2 = downloadContent.split('/');
            	console.log(splitname2);
            	console.log('x: ' +splitname2);
            	
                var y = splitname2[5].split('?');
            	console.log(y);
            	
                var recordId = y[0];
            	console.log(recordId);
                
            	var openPreview = $A.get('e.lightning:openFiles');
            		openPreview.fire({
                		recordIds: [recordId]
            		});

            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log('error');
                console.log(JSON.stringify(errors));
            }  
        });
            $A.enqueueAction(previewRecord);   
        
    }
})