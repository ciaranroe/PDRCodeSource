({
    doInit : function($C, $E, $H) {

        var getRecordApex = $C.get('c.getRecordApex');
        getRecordApex.setParams({recordId : $C.get('v.recordId')});
        getRecordApex.setCallback(this, function(response){
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){

                var originalRecord  = response.getReturnValue();
                var currentRecord   = response.getReturnValue();

                if (originalRecord.Completions_JSON__c){
                    currentRecord = JSON.parse(originalRecord.Completions_JSON__c);
                    currentRecord.Approval_Status__c    = originalRecord.Approval_Status__c;
                    currentRecord.Approval_Status__c    = originalRecord.Approval_Status__c;
                    currentRecord.Weaver_Signees__r     = originalRecord.Weaver_Signees__r;
                    currentRecord.Park_Accepted__c      = originalRecord.Park_Accepted__c;
                }
                $C.set('v.Invitation',currentRecord);
            }
        });
        $A.enqueueAction(getRecordApex);
    }
})