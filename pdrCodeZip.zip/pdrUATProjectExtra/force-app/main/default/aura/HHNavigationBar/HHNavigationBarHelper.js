({
	viewSingleHolidayHomePage: function(component, event, helper){
        
        var accountId = component.get("v.acctList")[0].Id;
        
        var address = component.get("v.singleHHPageUrl") + accountId;
        
        console.log('Single Page -----> ' + address);
        
        console.log('URL-------> '+ address);
        var urlEvent = $A.get("e.force:navigateToURL");
        	urlEvent.setParams({
                "url": address,
                "isRedirect": false
        });
        urlEvent.fire();
    },
    
    viewMultipleHolidayHomePage: function(component, event, helper){
        
        var address = component.get("v.multipleHHPageUrl");
        console.log('URL-------> '+ address);
        var urlEvent = $A.get("e.force:navigateToURL");
        	urlEvent.setParams({
                "url": address,
                "isRedirect": false
        });
        urlEvent.fire();
    }
})