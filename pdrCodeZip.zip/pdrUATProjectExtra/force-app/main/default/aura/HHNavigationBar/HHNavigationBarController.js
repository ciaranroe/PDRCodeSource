({

    updateMyDetails : function(component, event, helper){
        
         var communityUserId = $A.get("$SObjectType.CurrentUser.Id");
         component.set("v.userId", communityUserId);
        
        var address = component.get("v.profilePageUrl") + communityUserId;
        console.log('URL-------> '+ address);
        var urlEvent = $A.get("e.force:navigateToURL");
        	urlEvent.setParams({
                "url": address,
                "isRedirect": false
        });
        urlEvent.fire();
    },

    getRelatedAccounts : function(component, event, helper) {
        
        var action = component.get("c.getRelatedAccountsList");
        var id
        var self = this;
        
        action.setCallback(this, function(actionResult) {
            
            var state = actionResult.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                
                component.set("v.acctList", actionResult.getReturnValue());
                
                var acctListSize = component.get("v.acctList");
                
                console.log('---------> ' + acctListSize.length);
                
                if(acctListSize.length == "1"){
                    console.log("view Single holiday home page");
                    helper.viewSingleHolidayHomePage(component, event, helper);  
                }else{
                    //component.set("v.viewHolidayHomeList", true);
                    helper.viewMultipleHolidayHomePage(component, event, helper);
                }
            }   
        });
        
        $A.enqueueAction(action);
    },
    
    closeHHList : function(component, event, helper) {
        component.set("v.viewHolidayHomeList", false);
    }
    
    
    
})