({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },
    
    displayDocumentList: function (component, event, helper){
        var accountId = component.get("v.accountId");
        
        console.log('*******AccountId ' + accountId);
        
        var action = component.get("c.fetchContentDocument");
        
        action.setParams({accountId: accountId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('document List -----> ' + JSON.stringify(response.getReturnValue()));
                
                component.set('v.lstContentDoc', response.getReturnValue());
                
                this.parseEntityType(component, event, helper);
                
                component.set("v.sortAsc", true);
                this.sortBy(component,"CreatedDate");
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);  
    },
    
    parseEntityType: function(component, event, helper){
        console.log('******Entity************');
        var action = component.get("c.parseObjectTypeFromCDL");
        
        action.setParams({"lstAllCDL": component.get('v.lstContentDoc')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('---> State ' + state);
            if (state === "SUCCESS") {
                
                var cdl = [];
                var results = response.getReturnValue();
                
                for(var key in results){
                    cdl.push({value:results[key], key:key});
                }
                component.set('v.mapContentDocObjType', cdl);
                // component.set('v.mapContentDocObjType', response.getReturnValue());
                
                console.log('document List type -----> ' + JSON.stringify(cdl));
            }
        });
        $A.enqueueAction(action);  
    },
    
    sortBy: function(component, field) {
        console.log('---Sorted ');
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records = component.get("v.lstContentDoc");
        sortAsc = field == sortField? !sortAsc: true;
        
        records.sort(function(a,b){
            var t1 = a["ContentDocument"][field] == b["ContentDocument"][field],
                t2 = a["ContentDocument"][field] > b["ContentDocument"][field];
            console.log('field ' + field);
            console.log('------> t1 ' + t1);
            console.log('------> t2 ' + t2 );
            return t1? 0: (sortAsc?-1:1)*(t2?-1:1);
        });
        
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
        component.set("v.lstContentDoc", records);  
    }
})