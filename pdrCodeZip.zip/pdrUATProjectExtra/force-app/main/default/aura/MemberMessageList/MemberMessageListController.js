({
    doInit : function(component, event, helper) {
        helper.displayMessageList(component, event, helper);
    },
    
    confirmDeletion: function(component, event, helper) {
      component.set("v.targetDelete", event.currentTarget.getAttribute("data-id"));
      component.set("v.confirmDelete", true);
    },
    
    cancelDelete: function(component, event, helper) {
      component.set("v.targetDelete", "");
      component.set("v.confirmDelete", false);
    },
    
    handleDelete : function(component, event, helper) {
      component.set("v.confirmDelete", false);
      var idFile = component.get("v.targetDelete");
      component.set("v.memberMessageList", component.get("v.memberMessageList").filter(function(a) {
        return a.Id != idFile;
      }));
      helper.deleteMemberMessage(component, event, helper);
    },
    
    openMessage: function(component, event, helper) {
        
      var ids = event.currentTarget.getAttribute("data-id");
      var memberId = ids.split(':::')[0];
      var messageId = ids.split(':::')[1];  
      var timestamp = ids.split(':::')[2];
      var title = ids.split(':::')[3];
      component.set('v.selectedMemberId', memberId);
      component.set('v.selectedMessageId', messageId);
      component.set('v.selectedTimestamp', timestamp);
      component.set('v.selectedTitle', title);
      component.find("details").init();

        
    },
    
    closeMessage: function(component, event, helper) {
        
      // update message we just read
      var selected = component.get('v.selectedMessageId');
      var records = component.get('v.memberMessageList');
      for (var r = 0; r < records.length; r++) {
        if (records[r].Id == selected) {
          records[r].Message_Viewed__c = true;
        }
      }
      helper.updateHeader(component, event, helper);

      // reset selected
      component.set('v.selectedMemberId', '');
      component.set('v.selectedMessageId', '');
      component.set('v.selectedTimestamp', '');
      component.set('v.selectedTitle', '');

        
    },
    
    handlePrint: function(component, event, helper) { 
        helper.printMessage(component, event, helper); 
    },
    
    handleDownload: function(component, event, helper){ 
        helper.exportToPDF(component, event, helper);  
    }
})