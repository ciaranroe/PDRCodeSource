({
    displayMessageList :function(component, event, helper){
        var action = component.get("c.displayAllMemberMessages");
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                var res = response.getReturnValue();
                component.set("v.memberMessageList", response.getReturnValue());
      			helper.updateHeader(component, event, helper);
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    updateHeader: function(component, event, helper) {
        
      var unread = 0;
      var read = 0;
      var records = component.get("v.memberMessageList");
      for (var r = 0; r < records.length; r++) {
        if (records[r].Message_Viewed__c == false) {
          unread ++;
        } else {
          read ++;
        }
      }
        
      var message = "";
      if (unread == 0) message = read + (read == 1 ? " message" : " messages");
      if (unread > 0) message = unread + " unread" + (unread == 1 ? " message" : " messages");
      component.set('v.headerMessage', message);
        
    },
    
    exportToPDF:function(component, event, helper){
        console.log("called at least?");
        var idFile = event.currentTarget.getAttribute("data-id")
        console.log(idFile);
        var urlString = window.location.href;
        var communitybaseURL = urlString.substring(0,urlString.indexOf("/s"));
        
        var url = communitybaseURL + "/apex/MemberMessageDetailsExportToPDF?Id=" + idFile;
        console.log('url is', url); //check url
        window.open(url, "_blank"); 
    },
    
    downloadMessage:function(component, event, helper){
        var idFile = event.currentTarget.getAttribute("data-id")
        var downloadRecord = component.get("c.downloadMessageMember");
        
        downloadRecord.setParams({
            recordFileId: idFile
        });
        downloadRecord.setCallback(this, function(response) {
            
            var state = response.getState();
            if(state === "SUCCESS") {
                var messageDL = response.getReturnValue();
                messageDL.forEach(function(element, i){
                    
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": element
                    });
                    urlEvent.fire();
                });   
                
                var toastEvent = $A.get("e.force:showToast");
                
                toastEvent.fire();
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log('error');
            }        
        });
        $A.enqueueAction(downloadRecord);
    },
    
    printMessage:function(component, event, helper){
        console.log("called at least?");
        
        var msgId =  event.currentTarget.getAttribute("data-id");
        	console.log('recordId: ' + msgId); //check recordId
        
        var urlString = window.location.href;
        
        var communitybaseURL = urlString.substring(0,urlString.indexOf("/s"));
        	console.log("communitybaseURL", communitybaseURL);
        
        var url = communitybaseURL + "/apex/MemberMessageDetailsPrint?Id=" + msgId;
        	console.log('url is', url); //check url
        
        window.open(url, "_blank");
        
    },
    
    deleteMemberMessage: function(component, event, helper){
        var msgId = component.get("v.targetDelete");
        var deleteRecord = component.get("c.deleteMemberMessage");
        console.log('msgId: ' + msgId); 
        deleteRecord.setParams({
            recordId: msgId
        });
        
        deleteRecord.setCallback(this, function(response) {
            var state = response.getState();
          
            if(state === "SUCCESS") {
                console.log("successfully delete");
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log(errors);
            }
        });
        $A.enqueueAction(deleteRecord);
    },
    
    reloadPage: function(component, event, helper){
        window.location.reload();
    }

})