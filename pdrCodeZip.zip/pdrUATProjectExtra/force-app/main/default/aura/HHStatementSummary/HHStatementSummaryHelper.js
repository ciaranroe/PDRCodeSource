({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },

    getAccountNumber: function(component, event, helper){

        var action = component.get("c.getAccountNumber");
            action.setParams({"accountId" : component.get('v.accountId')}); 

            action.setCallback(this, function(response){
                var state = response.getState();

                if(state == 'SUCCESS'){
                    var acctNumber = response.getReturnValue();
                    component.set('v.accountNumber', acctNumber);
                }
             });
             $A.enqueueAction(action); 
    },

    getRelatedAccountList: function(component, event, helper){
        var action = component.get("c.getAccountHolderList");
        action.setParams({"accountId" : component.get("v.accountId")});
        action.setCallback(this, function (response) {
            var state = response.getState();
         
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                component.set('v.relatedAcctHolder', records);   
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); 
    },

    getStatementMonth: function(component, event, helper){

        var accountId = component.get('v.accountId');
        var action = component.get("c.getStatementMonth");

        action.setParams({"accountId": accountId}); 
        action.setCallback(this, function(response){

            console.log('component.get("c.getStatementMonth")',response.getState(), response.getReturnValue());
        
            var state = response.getState();

            if (state == 'SUCCESS') {
                         
                
                const baseMonths = [
                  'January', 'February', 'March', 'April', 'May', 'June',
                  'July', 'August', 'September', 'October', 'November', 'December'
                ];
                const allMonths = [];
                
                
                // if this loop is still here in 2120 then tbh I'm impressed
                // but im also dead so this is your problem now
                for (var m = 2020; m < 2120; m++) {
                  for (var b = 0; b < 12; b++) {
                    allMonths.push(baseMonths[b] + " " + m); 
                  }
                }
                
             
                var monthVal = response.getReturnValue();
                
                monthVal.sort(function(a,b){
                    return allMonths.indexOf(b) - allMonths.indexOf(a);
                });
                
                console.log('monthVal>>@'+monthVal);
                component.set("v.statementMonthList", monthVal);

                //Set the default value
                component.find("monthPicklistId").set("v.value", monthVal[0]);
                component.set("v.currentStatementMonth", monthVal[0]);
                
                this.displayStatementHeaderHelper(component, event, helper);
            }
        });
        
        $A.enqueueAction(action); 

    },
    
    displayStatementHeaderHelper: function(component, event, helper){

        console.log("month selected",  component.get("v.currentStatementMonth"));
        

        var accountId = component.get('v.accountId');
        var action = component.get("c.getStatement");
        
        
        action.setParams({"accountId": accountId, "statementMonth": component.get("v.currentStatementMonth")}); 
        
        action.setCallback(this, function(response){
            
            console.log('component.get("c.getStatement")',response.getState(), response.getReturnValue());

            if (response.getState() == 'SUCCESS') {

                var content = response.getReturnValue();

                component.set("v.statementHeader", content.Statement);
                // component.set("v.statementHeaderList", response.getReturnValue());
                
                // this.displayStatementListHelper(component, event, helper);
            }
        });
        
        $A.enqueueAction(action); 
    }, 


    displayStatementListHelper : function(component, event, helper) {

        var accountId = component.get('v.accountId');
        var statementHeaderId = (component.get("v.statementHeaderList"))[0].Id;
        
        var action = component.get("c.getStatementLines");
        
        action.setParams({"accountId": accountId, "statementMonth": component.get("v.currentStatementMonth"), "statementHeaderId": statementHeaderId}); 
        
        	action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                console.log("lines", response.getReturnValue());
                component.set("v.statementLinesList", response.getReturnValue());
                
            }
        });
        
        $A.enqueueAction(action); 
    }
})