({
    doInit: function ($C, $E, $H) {
        $C.set('v.ResponsePending', true);
        $C.set('v.showSaveCancelBtnSco', false);
        $C.set('v.showSaveCancelBtnEng', false);

        var getSchedulesApex = $C.get('c.getSchedulesApex');
        var currentYear = new Date().getFullYear();

        $C.set('v.CurrentYear', currentYear);

        getSchedulesApex.setParams({ recordId: $C.get('v.recordId') });
        getSchedulesApex.setCallback(this, function (response) {
            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS') {
                var content = response.getReturnValue();
                var seasonTemplate = content.seasonTemplate;
                var englishSchedules = content.EnglandSchedules;
                var scottishSchedules = content.ScotlandSchedules;
                var seasonYear = content.SeasonYear;
                // let cols = [
                //     {
                //         label: 'Start Date', fieldName: 'Start_Date__c', type: 'date', hideDefaultActions: true, editable: true, initialWidth: 125,
                //         typeAttributes: { year: "numeric", month: "numeric", day: "numeric" }
                //     },
                //     { label: 'Name', fieldName: 'Name', type: 'text', hideDefaultActions: true, editable: true, initialWidth: 155 },
                //     { label: 'Peak', fieldName: 'Minimum_Peak_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 55, cellAttributes: { alignment: 'center' } },
                //     { label: 'Summer', fieldName: 'Minimum_Summer_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 78, cellAttributes: { alignment: 'center' } },
                //     { label: 'Total', fieldName: 'Minimum_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 60, cellAttributes: { alignment: 'center' } }];

                var cols = [
                    {
                        label: 'Start Date', fieldName: 'Start_Date__c', type: 'date', hideDefaultActions: true, editable: true,
                        typeAttributes: { year: "numeric", month: "numeric", day: "numeric" }
                    },
                    { label: 'Name', fieldName: 'Name', type: 'text', hideDefaultActions: true, editable: true },
                    { label: 'Peak', fieldName: 'Minimum_Peak_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, cellAttributes: { alignment: 'center' } },
                    { label: 'Summer', fieldName: 'Minimum_Summer_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, cellAttributes: { alignment: 'center' } },
                    { label: 'Total', fieldName: 'Minimum_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, cellAttributes: { alignment: 'center' } }];

                if (currentYear > seasonYear) {
                    cols.forEach(function (col, index, arr) {
                        var newCol = col
                        newCol.editable = false;
                        arr[index] = newCol;
                    }
                    )
                    $C.set('v.editable', false);
                }

                $C.set('v.EnglishSchedules', englishSchedules);
                $C.set('v.ScottishSchedules', scottishSchedules);
                $C.set('v.SeasonTemplate', seasonTemplate);
                $C.set('v.SeasonYear', seasonYear);
                $C.set('v.columns', cols);
            }
        }
        )
        $A.enqueueAction(getSchedulesApex);
    },
    handleSaveSco: function ($C, $E, $H) {
        var draftValues = $C.get('v.ScottishSchedules');

        var action = $C.get("c.updateSchedules");
        draftValues.forEach(function (value) {
            console.log('valueId~:    ' + value.Id);
            !value.Id ? value.Id = null : value.Id = value.Id;
        })
        // if ($H.validateFields($C, $E, $H).isValid) {

        action.setParams({ "schedules": draftValues, recordId: $C.get('v.recordId'), parkGroup: 'Scotland' });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state == 'SUCCESS') {
                $H.getSchedules($C);
                $C.set('v.showSaveCancelBtnSco', false);
            }
            else if (state = 'ERROR') {
                let errors = response.getError();
                console.log(JSON.stringify(errors));
                let errorData = { table: { title: 'Please fix the following errors and try again.', messages: [] } };
                if (errors[0] && errors[0].message) {
                    errorData.table.messages.push(errors[0].message)
                    $C.set("v.scoErrors", errorData);
                }
                else if (!errors[0].message && errors[0].pageErrors) {
                    errors[0].pageErrors.forEach(error => errorData.table.messages.push(error.message));
                    $C.set("v.scoErrors", errorData);
                }
            }
        });
        $A.enqueueAction(action);
        // }
    },
    handleSaveEng: function ($C, $E, $H) {
        var draftValues = $C.get('v.EnglishSchedules');
        var action = $C.get("c.updateSchedules");
        draftValues.forEach(function (value) {
            console.log('valueId~:    ' + value.Id);
            !value.Id ? value.Id = null : value.Id = value.Id;
        })
        action.setParams({ "schedules": draftValues, recordId: $C.get('v.recordId'), parkGroup: 'England' });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state == 'SUCCESS') {
                $H.getSchedules($C);
                $C.set('v.showSaveCancelBtnEng', false);
            }
            else if (state = 'ERROR') {
                let errors = response.getError();
                console.log(JSON.stringify(errors));
                let errorData = { table: { title: 'Please fix the following errors and try again.', messages: [] } };
                if (errors[0] && errors[0].message) {
                    errorData.table.messages.push(errors[0].message)
                    $C.set("v.engErrors", errorData);
                }
                else if (!errors[0].message && errors[0].pageErrors) {
                    errors[0].pageErrors.forEach(error => errorData.table.messages.push(error.message));
                    $C.set("v.engErrors", errorData);
                }
            }
        });
        $A.enqueueAction(action);
    },
    addRow: function ($C, $E, $H) {
        let source = $E.getSource().get("v.name");
        let target;
        let parkGroup;
        let showButtons;
        if (source == 'sco') {
            target = "v.ScottishSchedules";
            parkGroup = 'Scotland'
            showButtons = "v.showSaveCancelBtnSco"
        }
        else if (source == 'eng') {
            target = "v.EnglishSchedules";
            parkGroup = 'England';
            showButtons = "v.showSaveCancelBtnEng"
        }

        let myData = $C.get(target);
        myData.push(
            {
                Id: "",
                Name: "",
                Start_Date__c: '',
                Park_Group__c: parkGroup,
                Minimum_Weeks__c: '',
                Minimum_Summer_Weeks__c: '',
                Minimum_Peak_Weeks__c: '',
                Sub_Hire_Season_Template__c: $C.get('v.recordId')
            }
        );
        $C.set(target, myData);
        $C.set(showButtons, true);
    },
    setEdit: function ($C, $E, $H) {
        let source = $E.getSource().get("v.name");
        let target;
        if (source == 'sco') {
            target = "v.editSco";
        }
        else if (source == 'eng') {
            target = "v.editEng";
        }
        $C.set(target, true);
    },
    cancelEdit: function ($C, $E, $H) {
        let source = $E.getSource().get("v.name");
        let target;
        if (source == 'sco') {
            target = "v.editSco";
        }
        else if (source == 'eng') {
            target = "v.editEng";
        }
        $C.set(target, false);
    },
    cancel: function (component, event, helper) {

        $A.get('e.force:refreshView').fire();
    },
    removeDeletedRow: function (component, event, helper) {
        var index = event.getParam("indexVar");
        var parkGroup = event.getParam("parkGroup");
        var target = 'v.' + parkGroup;

        var AllRowsList = component.get(target);
        AllRowsList.splice(index, 1);

        component.set(target, AllRowsList);
    },
    checkForErrors: function (component, event, helper) {
        var parkGroup = event.getParam("parkGroup");
        var target = parkGroup == 'England' ? 'v.EnglishSchedules' : 'v.ScottishSchedules';
        var updateTarget = parkGroup == 'England' ? 'v.engErrorsPresent' : 'v.scoErrorsPresent';
        var AllRowsList = component.get(target);
        console.log(AllRowsList);
        var errorsPresent = false;
        console.log('updateTarget: ' + updateTarget);
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");

        AllRowsList.forEach((row) => {
            var startDate = row.Start_Date__c;
            var minSummerWeeks = row.Minimum_Summer_Weeks__c;
            var minPeakWeeks = row.Minimum_Peak_Weeks__c;
            var minWeeks = row.Minimum_Weeks__c;
            var name = row.Name;
            if (today > startDate || minWeeks < minPeakWeeks || minWeeks < minSummerWeeks || minPeakWeeks < minSummerWeeks || name == '') {
                errorsPresent = true;
            }
        })
        console.log("errorsPresent:   " + errorsPresent);
        component.set(updateTarget, errorsPresent);
    }
})