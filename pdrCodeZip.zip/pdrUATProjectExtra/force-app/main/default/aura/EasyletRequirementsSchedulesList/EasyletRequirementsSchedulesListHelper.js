({
    getSchedules: function ($C) {
        $C.set('v.ResponsePending', true);
        let getSchedulesApex = $C.get('c.getSchedulesApex');
        let currentYear = new Date().getFullYear();

        $C.set('v.CurrentYear', currentYear);

        getSchedulesApex.setParams({ recordId: $C.get('v.recordId') });
        getSchedulesApex.setCallback(this, function (response) {
            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS') {
                var content = response.getReturnValue();
                var seasonTemplate = content.seasonTemplate;
                var englishSchedules = content.EnglandSchedules;
                var scottishSchedules = content.ScotlandSchedules;
                var seasonYear = content.SeasonYear;
                let cols = [
                    {
                        label: 'Start Date', fieldName: 'Start_Date__c', type: 'date', hideDefaultActions: true, editable: true, initialWidth: 125,
                        typeAttributes: { year: "numeric", month: "numeric", day: "numeric" }
                    },
                    { label: 'Name', fieldName: 'Name', type: 'text', hideDefaultActions: true, editable: true, initialWidth: 140 },
                    { label: 'Peak', fieldName: 'Minimum_Peak_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 50, cellAttributes: { alignment: 'center' } },
                    { label: 'Summer', fieldName: 'Minimum_Summer_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 73, cellAttributes: { alignment: 'center' } },
                    { label: 'Total', fieldName: 'Minimum_Weeks__c', type: 'number', hideDefaultActions: true, editable: true, initialWidth: 55, cellAttributes: { alignment: 'center' } }];

                if (currentYear > seasonYear) {
                    cols.forEach(function (col, index, arr) {
                        console.log('setting to editable false...');
                        let newCol = col
                        newCol.editable = false
                        arr[index] = newCol;
                    }
                    )
                }

                $C.set('v.EnglishSchedules', englishSchedules);
                $C.set('v.ScottishSchedules', scottishSchedules);
                $C.set('v.SeasonTemplate', seasonTemplate);
                $C.set('v.SeasonYear', seasonYear);
                $C.set('v.columns', cols);
            }
        }
        )
        $A.enqueueAction(getSchedulesApex);
    },
    validateFields: function (component, event, helper) {
        var allRecords = component.get("v.ScottishSchedules");
        let returnVal = { isValid: true, errors: [] };
        let nameVal = helper.requiredNameValidation(component, event, helper);
        let peakVal = helper.peakValidation(component, event, helper);
        return returnVal;
    },
    requiredNameValidation: function (component, event, helper) {
        var allRecords = component.get("v.ScottishSchedules");
        var isValid = true;
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].Name == null || allRecords[i].Name.trim() == '') {
                alert('Complete this field : Row No ' + (i + 1) + ' Name is null');
                isValid = false;
            }
        }
        return isValid;
    },
    peakValidation: function (component, event, helper) {
        var allRecords = component.get("v.ScottishSchedules");
        let returnVal = { isValid: true, errors: [] };
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].Minimum_Peak_Weeks__c == null || allRecords[i].Minimum_Peak_Weeks__c < allRecords[i].Minimum_Summer_Weeks__c) {
                returnVal.isValid = false;
                allRecords.errors.push({ index: i, field: 'Minimum_Peak_Weeks__c' });
            }
        }
        return returnVal;
    },
    totalWeeksValidation: function (component, event, helper) {
        var allRecords = component.get("v.ScottishSchedules");
        let returnVal = { isValid: true, errors: [] };
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].Minimum_Weeks__c == null || allRecords[i].Minimum_Weeks__c < allRecords[i].Minimum_Summer_Weeks__c || allRecords[i].Minimum_Weeks__c < allRecords[i].Minimum_Peak_Weeks__c) {
                returnVal.isValid = false;
                allRecords.errors.push({ index: i, field: 'Minimum_Weeks__c' });
            }
        }
        return returnVal;
    },
})