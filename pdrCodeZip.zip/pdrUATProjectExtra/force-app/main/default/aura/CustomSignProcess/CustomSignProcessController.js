({

    validateEmail : function($C, $E, $H) {

        var emailString = $C.get('v.Email');
        var regexVal = /\S+@\S+\.\S+/;
        $C.set('v.EmailValid',regexVal.test(emailString));

    },
    sendEmail : function($C, $E, $H) {

        var oppId   = $C.get('v.recordId');
        var urlBase = $A.get("$Label.c.CustomSignURL");
        var signLink = urlBase + '?Id=' + oppId;
        var emailAddress = $C.get('v.Email');

        var sendEmailApex = $C.get('c.sendEmailApex');
        sendEmailApex.setParams({ emailAddress : emailAddress, signLink : signLink});
        sendEmailApex.setCallback(this, function(response){

            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'SUCCESS'){
                $A.get("e.force:showToast").setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "Contract review link sent to " + emailAddress
                }).fire();
                $A.get("e.force:closeQuickAction").fire();
            } else {
                $A.get("e.force:showToast").setParams({
                    "title": "Error!",
                    "type": "Error",
                    "message": "There was an error sending the email: " + response.getReturnValue()
                }).fire();  
            }
        });
        $A.enqueueAction(sendEmailApex);
    }, 
    openLink : function($C,$E,$H){

        var oppId   = $C.get('v.recordId');
        var urlBase = $A.get("$Label.c.CustomSignURL");
        var signLink = urlBase + '?Id=' + oppId;
        window.open(signLink, '_blank');
        $A.get("e.force:closeQuickAction").fire();
        
    }
})