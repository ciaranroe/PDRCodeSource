({
    doInit : function($C, $E, $H) {

        console.log('init called');

        var getTemplateDatesApex = $C.get('c.getTemplateDatesApex');
        getTemplateDatesApex.setParams({ recordId : $C.get('v.recordId')});
        getTemplateDatesApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            $C.set('v.Changes',false);
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){

                var resMap = response.getReturnValue();
                if (resMap.England) {
                    $C.set('v.EnglishDates',resMap.England);
                } 
                if (resMap.Scotland) {
                    $C.set('v.ScottishDates',resMap.Scotland);
                } 
                if (resMap.Template){
                    $C.set('v.Template',resMap.Template);

                    if (resMap.Template.Past__c){
                        $C.set('v.IncludePastDates',true);
                    }
                }
            }
        });
        $A.enqueueAction(getTemplateDatesApex);

    },
    setSaveOption : function($C){
        $C.set('v.Changes',true);
    },
    cancel : function($C){
        $C.set('v.ResponsePending',true);
        $A.enqueueAction($C.get('c.doInit')); 
    }, 
    save : function($C){

        var templateDates   = [];

        var englishDates    = $C.get('v.EnglishDates');
        englishDates.forEach(function(date){
            if (date.Id) templateDates.push(date);
        });

        var scottishDates   = $C.get('v.ScottishDates');
        scottishDates.forEach(function(date){
            if (date.Id) templateDates.push(date);
        });

        var saveTemplateDatesApex = $C.get('c.saveTemplateDatesApex');
        saveTemplateDatesApex.setParams({ templateDates : templateDates, recordId : $C.get('v.recordId')});
        saveTemplateDatesApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            $C.set('v.Changes',false);
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){

                if (response.getReturnValue() === 'success'){
                    $A.get('e.force:refreshView').fire();
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": "Template dates updated"
                    }).fire();
                } else {
                    $A.get("e.force:showToast").setParams({
                        "title": "Error!",
                        "type": "error",
                        "message": response.getReturnValue()
                    }).fire();
                }

            }
        });
        $A.enqueueAction(saveTemplateDatesApex);

    }

})