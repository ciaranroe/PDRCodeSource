({
    doInit : function($C, $E, $H) {

    }, 
    searchCSNs : function($C){
        var CSNString = $C.get('v.CSNString');
        console.log(CSNString);
        console.log(CSNString.length);

        if (CSNString.length > 3){
            var searchCSNsApex = $C.get('c.searchCSNsApex');
            searchCSNsApex.setParams({ CSNString : CSNString, recordId : $C.get('v.recordId')});
            searchCSNsApex.setCallback(this, function(response){
                console.log(response.getReturnValue());
                console.log(response.getState());
                if (response.getState() === 'SUCCESS'){
                    console.log(response.getReturnValue());
                    $C.set('v.CSNsearches', response.getReturnValue());
                }
            });
            $A.enqueueAction(searchCSNsApex);
        } 

    }
})