({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },
    
    loadStatementMonthHelper : function(component, event, helper){
        //Set the statement month picklist
        var action = component.get("c.getLastSixMonths");
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            
            if(state == 'SUCCESS'){
                var monthVal = response.getReturnValue();
                component.set("v.statementMonths", monthVal);
                
                //Set the default value
                component.find("monthPicklistId").set("v.value", monthVal[0]);
                
                //To be use as paramater
                var statementMonth = component.set("v.currentStatementMonth", monthVal[0]);
                
                this.displayStatementHeaderHelper(component, event, helper);
            }
            
        });
        
        $A.enqueueAction(action); 
        
    },
    
    displayStatementHeaderHelper: function(component, event, helper){
        var accountId = component.get('v.accountId');
        
        console.log('***Inside displayStatementHeaderHelper ****** ');
        console.log('***AcctId****** ' + accountId);
        console.log('****StatementMonth*** ' + component.get("v.currentStatementMonth"));
        
         var action = component.get("c.getStatementHeader");
        
        action.setParams({"accountId": accountId, "statementMonth": component.get("v.currentStatementMonth")}); 
        
        	action.setCallback(this, function(response){
            
            var state = response.getState();
                console.log('state is : ', state);
            
            if (state == 'SUCCESS') {
                component.set("v.statementHeaderList", response.getReturnValue());
                
                console.log('*****SHLIST***** '+ response.getReturnValue());
                
                this. displayStatementListHelper(component, event, helper);
            }
        });
        
        $A.enqueueAction(action); 
    }, 
    
    displayStatementListHelper : function(component, event, helper) {

        var accountId = component.get('v.accountId');
        var statementHeaderId = (component.get("v.statementHeaderList"))[0].Id;
        
        console.log('***Inside displayStatementListHelper ****** ');
        console.log('***AcctId****** ' + accountId);
        console.log('***statementHeaderId****** ' + statementHeaderId);
        console.log('****StatementMonth*** ' + component.get("v.currentStatementMonth"));
        
        var action = component.get("c.getStatementLines");
        
        action.setParams({"accountId": accountId, "statementMonth": component.get("v.currentStatementMonth"), "statementHeaderId": statementHeaderId}); 
        
        	action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                component.set("v.statementLinesList", response.getReturnValue());
                
            }
        });
        
        $A.enqueueAction(action); 
    }
})