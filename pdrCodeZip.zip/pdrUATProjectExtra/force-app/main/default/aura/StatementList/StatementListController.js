({
    
    print : function (component, event, helper) {
        var statementHeaderId = (component.get("v.statementHeaderList"))[0].Id;
        var urlString = window.location.href;
        var communitybaseURL = urlString.substring(0, urlString.indexOf("/s"));
        console.log("communitybaseURL", communitybaseURL);
        var url = communitybaseURL +  "/apex/GeneratePrintableStatements?Id=" + statementHeaderId ;
        console.log('url is', url);
        window.open(url, "_blank");
    },
    
    doInit : function(component, event, helper) {
        
        helper.parsePageUrlParameter(component, event, helper);
        helper.loadStatementMonthHelper(component, event, helper);
    },
    
    searchStatements : function(component, event, helper){
        
        console.log('searchStatements controller method called');
        var selectedStatementMonth = event.getSource().get("v.value");
        var action = event.getSource().get("v.value")
        
        console.log('selected Month ----> ', selectedStatementMonth);
        component.set("v.currentStatementMonth", selectedStatementMonth);
        
        helper.displayStatementHeaderHelper(component, event, helper);
    }
})