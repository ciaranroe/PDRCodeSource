({
	getRelatedAccounts : function(component) {
		var action = component.get("c.getRelatedAccountsList");
        var id;
        var self = this;

        action.setCallback(this, function(actionResult) {

            var state = actionResult.getState();

            if (component.isValid() && state === "SUCCESS") {

                component.set('v.accts', actionResult.getReturnValue());
            }    
        });

        $A.enqueueAction(action);

	}
})