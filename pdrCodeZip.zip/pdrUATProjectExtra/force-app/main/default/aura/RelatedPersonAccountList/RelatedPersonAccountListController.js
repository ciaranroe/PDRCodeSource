({
	doInit : function(component, event, helper) {
		helper.getRelatedAccounts(component);
	}
})