({

    doInit : function($C,$E,$H){
        var importFiles = $H.constructList(); 
        $C.set('v.ImportList',importFiles); 
    },
    handleFilesChange : function($C){
        var fileList    = $C.get('v.FileList');
        var fileNames   = [];

        for (var x = 0; x < fileList.length; x++){
            fileNames.push(fileList[x].name);
        }

        var importFiles = $C.get('v.ImportList');
        importFiles.forEach(function(file){
            file.ggFiles.forEach(function(ggFile){

                if (fileNames.includes(ggFile.name)){
                    ggFile.located  = true;
                    ggFile.index    = fileNames.indexOf(ggFile.name);
                    ggFile.file     = fileList[fileNames.indexOf(ggFile.name)];
                } 
            });
            file.status = 'Not started';
        });

        $C.set('v.ImportList',importFiles);
    },
    setSequenceIndex : function($C,$E){
        $C.set('v.ChangingIndex',true);
        $C.set('v.SequenceIndex', parseInt($E.currentTarget.dataset.index));
    },
    importAtIndex : function($C,$E,$H){

        if ($C.get('v.ChangingIndex')){ 
            $C.set('v.ChangingIndex', false);
        } else {
            $C.set('v.processing',true);
            var index      = $C.get('v.SequenceIndex');
            var importList = $C.get('v.ImportList');
            var batchSize  = parseInt($C.get('v.BatchSize'));

            if (importList[index]){
                var sObjectType         = importList[index].sObjectName;
                var sObjectField        = importList[index].sObjectField;
                var fileDefinitions     = importList[index].ggFiles;

                fileDefinitions.forEach(function(fileDefinition){
    
                    var method  = fileDefinition.method; 

                    if (!method || $H[method]){

                        var file   = fileDefinition.file;
                        var reader = new FileReader();
                        reader.readAsText(file, "UTF-8");
                        reader.onload = function (evt) {

                            var lines = evt.target.result.split("\n");
                            lines.splice(0,1);

                            var lineSubset  = lines.slice(fileDefinition.processIndex, fileDefinition.processIndex + batchSize);
                            var sObjects    = [];

                            if (importList[index].parseObjects){

                                lineSubset.forEach(function(line){
                                    var lineProperties = line.split("\t");
                                    var sObject = $H[method](lineProperties,sObjectType);
                                    if (sObject) {
                                        sObjects.push(sObject);
                                    }
                                });
                            } else {
                                sObjects = lineSubset;
                            }    
        
                            fileDefinition.status       = 'Processing ' + sObjects.length + ' records';
                            fileDefinition.processIndex += parseInt(lineSubset.length);
                            importList[index].ggFiles   = fileDefinitions;

                            $C.set('v.ImportList',importList);

                            var processFiles = $C.get(fileDefinition.apexMethod);
                            processFiles.setParams({sObjects : sObjects, sObjectType : sObjectType, externalId : sObjectField});
                            processFiles.setCallback(this, function(response){

                                if (response.getState() === 'SUCCESS'){
                                    var successes   = parseInt(response.getReturnValue().split('::')[0]);
                                    var errors      = parseInt(response.getReturnValue().split('::')[1]);
                                    fileDefinition.status = '';
                                    fileDefinition.successes += successes;
                                    fileDefinition.errors += errors;
                                } else {
                                    fileDefinition.status = response.getState();
                                }
                                $C.set('v.ImportList',importList);

                                if (fileDefinition.processIndex < lines.length){
                                    $A.enqueueAction($C.get('c.importAtIndex'));
                                } else {
                                    $C.set('v.SequenceIndex', parseInt(index) + 1);
                                }
                            });
                            $A.enqueueAction(processFiles);
                        }
                    }
                });
            } else {
                $C.set('v.processing',false);
            }
        } 
    }
})