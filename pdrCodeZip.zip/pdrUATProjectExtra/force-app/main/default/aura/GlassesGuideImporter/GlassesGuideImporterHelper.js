({
    processModelTypes : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Model_Type_Code__c : lineProperties[0], 
                Model_Type_Description__c : lineProperties[2],
                Name : lineProperties[2]
            };
        }
        return sObject;
    },
    processAxles : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Axle_Code__c : lineProperties[0],
                Axle_Abbreviation__c : lineProperties[2],
                Axle_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },   
    processLounges : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Caravan_Lounge_Code__c : lineProperties[0],
                Caravan_Lounge_Abbreviation__c : lineProperties[2],
                Caravan_Lounge_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processConfigurations : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Configuration_Code__c : lineProperties[0],
                Configuration_Description__c : lineProperties[2],
                Name : lineProperties[2]
            };
        }
        return sObject;
    },
    processBedrooms : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Bedroom_Code__c : lineProperties[0],
                Bedroom_Abbreviation__c : lineProperties[2],
                Bedroom_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processKitchens : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Kitchen_Code__c : lineProperties[0],
                Kitchen_Abbreviation__c : lineProperties[2],
                Kitchen_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processWashrooms : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Washroom_Code__c : lineProperties[0],
                Washroom_Abbreviation__c : lineProperties[2],
                Washroom_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processFeatures : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Feature_Code__c : lineProperties[0],
                Feature_Abbreviation__c : lineProperties[2],
                Feature_Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processLengths : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Length_Code__c : lineProperties[0],
                Length_Value__c : lineProperties[2],
                Length_Unit__c : lineProperties[3],
                Name : lineProperties[2] + ' ' + lineProperties[3]
            };
        }
        return sObject;
    },
    processBerths : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Berth_Code__c : lineProperties[0],
                Berth_Description__c : lineProperties[2],
                Number_Of_Berths__c : lineProperties[3],
                Name : lineProperties[2] 
            };
        }
        return sObject;
    },
    processWeights : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Weight_Code__c : lineProperties[0],
                Weight_Value__c : lineProperties[2],
                Weight_Unit__c : lineProperties[3],
                Name : lineProperties[2] + ' ' + lineProperties[3]
            };
        }
        return sObject;
    },
    processWidths : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Width_Code__c : lineProperties[0],
                Width_Value__c : lineProperties[2],
                Width_Unit__c : lineProperties[3],
                Width_Description : lineProperties[4],
                Name : lineProperties[4]
            };
        }
        return sObject;
    },
    processWheelBases : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Wheel_Base_Code__c : lineProperties[0],
                Wheel_Base_Description__c : lineProperties[2],
                Wheel_Base_From__c : lineProperties[3],
                Wheel_Base_To__c : lineProperties[4],
                Name : lineProperties[2]
            };
        }
        return sObject;
    },
    processManufacturers : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Manufacturer_Code__c : lineProperties[0],
                Manufacturer_Description__c : lineProperties[2],
                Name : lineProperties[2]
            };
        }
        return sObject;
    },
    processRanges : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Manufacturer_Code__c : lineProperties[0],
                Range_Code__c : lineProperties[1],
                Range_Description__c : lineProperties[3],
                Range_Id__c : lineProperties[0] + lineProperties[1], 
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    processTrims : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Manufacturer_Code__c : lineProperties[0],
                Range_Code__c : lineProperties[1],
                Trim_Code__c : lineProperties[2],
                Trim_Id__c : lineProperties[0] + lineProperties[1] + lineProperties[2], // manufacturer + range + trim code
                Trim_Description__c : lineProperties[4], 
                Name : lineProperties[4]
            };
        }
        return sObject;
    },
    processValuationCategories : function(lineProperties, sObjectType){
        var sObject;
        if (lineProperties[0]){
            sObject = {
                sobjectType : sObjectType, 
                Model_Type_Code__c : lineProperties[0], 
                Category_Code__c : lineProperties[1],
                Valuation_Category_Id__c : lineProperties[0] + lineProperties[1],
                Description__c : lineProperties[3],
                Name : lineProperties[3]
            };
        }
        return sObject;
    },
    constructList : function() {
        var importFiles = [];        
        importFiles.push({
            name : 'Model Type',
            sObjectName : 'GG_Model_Type__c',
            sObjectField : 'Model_Type_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Generic_Complete_ModelType.txt', located : false, method : 'processModelTypes', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        }); 
        importFiles.push({
            name : 'Axle',
            sObjectName : 'GG_Axle__c',
            sObjectField : 'Axle_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanAxle.txt', located : false, method : 'processAxles', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        }); 
        importFiles.push({
            name : 'Lounge',
            sObjectName : 'GG_Lounge__c',
            sObjectField : 'Caravan_Lounge_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanLounge.txt', located : false, method : 'processLounges', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        }); 
        importFiles.push({
            name : 'Berth',
            sObjectName : 'GG_Berth__c',
            sObjectField : 'Berth_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanBerth.txt', located : false, method : 'processBerths', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        }); 
        importFiles.push({
            name : 'Configuration',
            sObjectName : 'GG_Configuration__c',
            sObjectField : 'Configuration_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanConfiguration.txt', located : false, method : 'processConfigurations', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        }); 
        importFiles.push({
            name : 'Bedroom',
            sObjectName : 'GG_Bedroom__c',
            sObjectField : 'Bedroom_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanBedroom.txt', located : false, method : 'processBedrooms', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Kitchen',
            sObjectName : 'GG_Kitchen__c',
            sObjectField : 'Kitchen_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanKitchen.txt', located : false, method : 'processKitchens', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Washroom',
            sObjectName : 'GG_Washroom__c',
            sObjectField : 'Washroom_Code__c',
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanWashroom.txt', located : false, method : 'processWashrooms', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Features',
            sObjectName : 'GG_Feature__c',
            sObjectField : 'Feature_Code__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanFeatures.txt', located : false, sObject : '', method : 'processFeatures', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Vehicle Length',
            sObjectName : 'GG_Vehicle_Length__c',
            sObjectField : 'Length_Code__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Generic_Complete_VehicleLength.txt', located : false, method : 'processLengths', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Vehicle Weight',
            sObjectName : 'GG_Vehicle_Weight__c',
            sObjectField : 'Weight_Code__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Generic_Complete_VehicleWeight.txt', located : false, method : 'processWeights', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Vehicle Width',
            sObjectName : 'GG_Vehicle_Width__c',
            sObjectField : 'Width_Code__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Generic_Complete_VehicleWidth.txt', located : false, method : 'processWidths', processIndex : 0,apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Wheel Base',
            sObjectName : 'GG_Wheel_Base__c',
            sObjectField : 'Wheel_Base_Code__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Generic_Complete_WheelBase.txt', located : false, method : 'processWheelBases', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Manufacturer',
            sObjectName : 'GG_Manufacturer__c',
            sObjectField : 'Manufacturer_Code__c', 
            parseObjects : true,
            ggFiles : [{ successes : 0, errors : 0,name : 'Generic_Complete_Manufacturer.txt', located : false,method : 'processManufacturers', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Range',
            sObjectName : 'GG_Range__c',
            sObjectField : 'Range_Id__c', 
            parseObjects : true,
            ggFiles : [{ successes : 0, errors : 0,name : 'Generic_Complete_Range.txt', located : false,method : 'processRanges', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Trim',
            sObjectName : 'GG_Trim__c',
            sObjectField : 'Trim_Id__c', 
            parseObjects : true,
            ggFiles : [{ successes : 0, errors : 0,name : 'Generic_Complete_Trim.txt', located : false,method : 'processTrims', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Model',
            sObjectName : 'GG_Model__c',
            sObjectField : 'Model_Id__c', 
            parseObjects : false,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_Model.txt', located : false, processIndex : 0, apexMethod : 'c.processModelsApex'}],
            subIndex : 0,           
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Model Additional',
            sObjectName : 'GG_Model__c',
            sObjectField : 'Model_Id__c', 
            parseObjects : false,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_ModelAdditional.txt', located : false, processIndex : 0, apexMethod : 'c.processModelsAdditionalApex'}],
            subIndex : 0,           
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Valuation Category',
            sObjectName : 'GG_Valuation_Category__c',
            sObjectField : 'Valuation_Category_Id__c', 
            parseObjects : true,
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_ValuationCategory.txt', located : false, method : 'processValuationCategories', processIndex : 0, apexMethod : 'c.processsObjectsApex'}],
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Caravan Details',
            sObjectName : 'GG_Model_Specification__c',
            sObjectField : 'Model_Specification_Id__c',
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_CaravanDetails.txt', located : false, processIndex : 0, apexMethod : 'c.processCaravanDetailsApex'}],
            subIndex : 0,
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Qualified Models',
            sObjectName : 'GG_Model_Specification__c',
            sObjectField : 'Model_Specification_Id__c',
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_QualifiedModel.txt', located : false, processIndex : 0, apexMethod : 'c.processQualifiedModelsApex'}],
            subIndex : 0,
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Qualified Models Valuations',
            sObjectName : 'GG_Model_Specification__c',
            sObjectField : 'Model_Specification_Id__c',
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_QualifiedModelValuations.txt', located : false,  processIndex : 0, apexMethod : 'c.processQualifiedModelValuationsApex'}],
            subIndex : 0,
            status : 'Missing .txt files'
        });
        importFiles.push({
            name : 'Valuation',
            sObjectName : 'GG_Valuation__c',
            sObjectField : 'TBC',
            ggFiles : [{successes : 0, errors : 0, name : 'Caravan_Complete_Valuations.txt', located : false, processIndex : 0, apexMethod : 'c.processValuationsApex'}],
            status : 'Missing .txt files'
        });

        return importFiles;
    }
})