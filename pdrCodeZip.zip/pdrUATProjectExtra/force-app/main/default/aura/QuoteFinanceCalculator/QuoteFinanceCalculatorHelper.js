({
    // Method to save quote record with new Finance Provider 
    financeProviderChange: function($C, quote) {
        
        var action = $C.get('c.updateFinanceProvonQuote');
        action.setParams({
            "financeProvider": $C.get('v.financeProviderId'),
            "quoteObj": quote
        }); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') { }
            
            var result = response.getReturnValue();
            
            if(result === 'SUCCESS') {
                
                console.log('Quote updated');
                $A.get('e.force:refreshView').fire();
                $C.set('v.loading', false);
            }
            
            else {
                console.log('Error while updating the quote', result);
                $C.set('v.loading', false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "mode": "sticky",
                    "message":result
                });
                toastEvent.fire();
            }
            
        }); 
        
        $A.enqueueAction(action); 
    },
    
    getQuoteDetails: function($C, $E, $H) { 
        
        console.log('***** . get quote details called');
        var recordId = $C.get('v.recordId');
        var action = $C.get('c.getQuote');
        action.setParams({"recordId": recordId});
        
        action.setCallback(this, function(response){
            
            console.log('c.getQuote',response.getState(),response.getReturnValue());
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                console.log('response state of getQuoteDetails ', state);
                console.log('response of getQuoteDetails ', response.getReturnValue());
                
                var quoteObj = response.getReturnValue();    
                
                console.log('quoteObj.Finance_Allowed__c : ', quoteObj.Finance_Allowed__c);
                
                if(quoteObj.Finance_Allowed__c === false) {
                    console.log('Finance Unavailable');
                    $C.set("v.unavailable", true);
                }
                
                else if (quoteObj.Finance_Allowed__c && quoteObj.SBQQ__Uncalculated__c) {
                    console.log('Finance Available but Quote calc in progress');
                    $C.set("v.unavailable", true);
                    $C.set("v.calcInProgress", true);
                }
                    else {
                        console.log('inside else');
                        $C.set("v.unavailable", false);
                        $C.set("v.calcInProgress", false);
                        
                        $C.set("v.quote", quoteObj);
                        $C.set("v.quoteId", quoteObj.Id);
                        $C.set("v.financeProviderId", quoteObj.Finance_Provider__c);
                       
                        if(quoteObj.Minimum_Deposit__c != null && quoteObj.Minimum_Deposit__c != 'undefined' 
                           && quoteObj.Minimum_Deposit__c != 'NaN') {
                            $C.set("v.minimumDeposit", quoteObj.Minimum_Deposit__c );
                        }
                        console.log('minimumDeposit ', quoteObj.Minimum_Deposit__c);
                        $C.set("v.selectedTypeOption", quoteObj.Holiday_Home__r.Type__c);
                        
                        console.log('QUOTE OBJ',quoteObj);
                        if(quoteObj.SBQQ__NetAmount__c !== null && quoteObj.SBQQ__NetAmount__c !== 0.00) {
                            console.log('quote net amount is not null or 0: ', quoteObj.SBQQ__NetAmount__c);
                            console.log('quote Part_Exchange_Allowance_Applied_to_Sale__c: ', quoteObj.Part_Exchange_Allowance_Applied_to_sale__c);
                            var totalPackagePrice = quoteObj.SBQQ__NetAmount__c; 
                            if (quoteObj.Part_Exchange_Allowance_Applied_to_sale__c){
                                totalPackagePrice += quoteObj.Part_Exchange_Allowance_Applied_to_sale__c;
                            }
                            if (quoteObj.PDR_Deposit_Contribution__c){
                                totalPackagePrice += quoteObj.PDR_Deposit_Contribution__c;
                            }
                            console.log('quote totalPackagePrice: ', totalPackagePrice);
                            $C.set("v.totalPackagePrice", totalPackagePrice);
                        }
                        
                        if(quoteObj.Holiday_Home__c != null && quoteObj.Holiday_Home__c != 'undefined') {
                            console.log('quote Holiday_Home__c', quoteObj.Holiday_Home__c);
                            if(quoteObj.Holiday_Home__r.Model_Year__c != null && quoteObj.Holiday_Home__r.Model_Year__c!= 'undefined') {
                                $C.set("v.modelYearValue", quoteObj.Holiday_Home__r.Model_Year__c ); 
                            }
                        }
                        else{
                            $C.set("v.modelYearValue", 2020); 
                        }
                        
                        // Get Finance Calculator rules
                        this.getFinanceCalcRules($C, quoteObj);
                    }
            }
        });
        
        $A.enqueueAction(action);
    },
    
    getFinanceCalcRules: function($C, quoteObj) { 
        
        var action = $C.get('c.getFinanceCalculatorRules');        
        action.setParams({
            "financeProvId":  $C.get('v.financeProviderId'),
            "parkId": quoteObj.Park__c,
            "invntryType":  $C.get('v.selectedTypeOption'),
            "modelYear": $C.get('v.modelYearValue')                       
        }); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();

                console.log('resultMap of getFinanceCalcRules is: ', resultMap);
                console.log('maxIvntryItemAge is: ', resultMap.InvntryItemAgeMax);
                console.log('minIvntryItemAge is: ', resultMap.InvntryItemAgeMin);
                console.log('maximumLengthofTerm is: ', resultMap.MaxTermMonths);
                
                if(resultMap.MaxTermMonths != null && resultMap.MaxTermMonths != 'undefined' &&
                   resultMap.InvntryItemAgeMax != null && resultMap.InvntryItemAgeMax != 'undefined' &&
                   resultMap.InvntryItemAgeMin != null && resultMap.InvntryItemAgeMin != 'undefined') {
                    $C.set("v.maximumLengthofTerm", resultMap.MaxTermMonths);
                    $C.set("v.maxIvntryItemAge", resultMap.InvntryItemAgeMax);
                    $C.set("v.minIvntryItemAge", resultMap.InvntryItemAgeMin);
                    this.prepopulateValues($C);
                }
                else{
                    //alert('Finance Calculator Rules are not configured for the selected Finance Provider and Park. Please contact your administrator.')
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Warning",
                        "mode": "sticky",
                        "message":"Fnance Calculator Rules are not configured for the selected Finance Provider and Park. Please contact your administrator."
                    });
                    toastEvent.fire();
                    
                    $C.set("v.maximumLengthofTerm", 84);
                    $C.set("v.maxIvntryItemAge", 2020);
                    $C.set("v.minIvntryItemAge", 2006);
                    this.prepopulateValueswithoutFP($C);
                }
                var financeProvider = $C.get('v.financeProviderId');
                if(financeProvider == undefined || financeProvider == null || financeProvider == '' ){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Warning",
                        "mode": "sticky",
                        "message":"Please select a finance provider"
                    });
                    toastEvent.fire();
                }
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    getPXValues:  function($C, $E, $H) {
        var action = $C.get('c.getPxValuesfromLine');
        action.setParams({
            "quoteId": $C.get('v.recordId')
        }); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                
                var pxValues = response.getReturnValue(); 
                console.log('response of getPXValues ', response.getReturnValue());
                console.log('PX_Finance_Settlement ', pxValues.PX_Finance_Settlement);
                
                $C.set("v.financeSettlement", pxValues.PX_Finance_Settlement);
                
                console.log('Part_Exchange_Allowance_Applied_to_Sale ', pxValues.Part_Exchange_Allowance_Applied_to_Sale);                
                if(pxValues.Part_Exchange_Allowance_Applied_to_Sale !== null) {
                    $C.set("v.hasPx", true);
                    $C.set("v.pxValue", pxValues.Part_Exchange_Allowance_Applied_to_Sale);
                }
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    prepopulateValueswithoutFP: function($C) {
        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var totalFundable = ($C.get('v.quote')).Fundable_Value__c;
        var pxVal =  $C.get('v.pxValue');
        var minDepositThreshold = ($C.get('v.quote')).Minimum_Deposit__c ;
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var interestRateVar = $C.get('v.interestRate');
        var aprValue =  $C.get('v.representativeAPR');
        var optionToPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var initDepCalculated = minDepositThreshold;

        // Commented on 3/3 to set the slider position at the very left.
        /* if(minDepositCalculated > minDepositThreshold) {
            
            initDepCalculated = minDepositCalculated ;
        } */
              console.log('minDepositPercent without FP', minDepositPercent);
        console.log('minDepositThreshold without FP', minDepositThreshold);
      
        
        if(minDepositThreshold != null && minDepositThreshold !== 'undefined' &&  minDepositThreshold != "") {
             console.log('inside if of prepopulateValueswithoutFP');
            $C.set("v.minimumDeposit", initDepCalculated.toFixed(2));
            $C.set("v.totalDeposit", initDepCalculated.toFixed(2)); 
        }
        
        else{
             var minDepositCalculated = (totalFundable * (minDepositPercent / 100)) - pxVal ;
             //var minDepositCalculated = (totalpackageprice * (minDepositPercent / 100)) - pxVal ;
            initDepCalculated = minDepositCalculated;
             $C.set("v.minimumDeposit", minDepositCalculated.toFixed(2));
       		 $C.set("v.totalDeposit", minDepositCalculated.toFixed(2)); 
        }

          console.log('calculated deposit is : ', $C.get("v.totalDeposit"));
        
        var costtochange = totalpackageprice - pxVal;        
        console.log('costToChange : ', costtochange) ;
        $C.set("v.costToChange", costtochange.toFixed(2));
        
        var balToFinance = costtochange - initDepCalculated  ;
        console.log('balancetoFinance : ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2)); 
        
        // Calculations
        this.calculations($C, aprValue, balToFinance, optionToPurchaseFee, paymentMonths);    
    },
    
    prepopulateValues: function($C) {
        
        var action = $C.get('c.getValuesfromFP');
        
        action.setParams({"financeProviderId": $C.get('v.financeProviderId')}); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            console.log('response of prepopulateValues ', response.getReturnValue());
            
            if (state == 'SUCCESS') {
                var resultMap = response.getReturnValue();
                var paymentMonths = $C.get('v.maximumLengthofTerm');                
                var totalpackageprice =  $C.get('v.totalPackagePrice');
                var minDepositThreshold = $C.get('v.minimumDeposit');
                console.log('minDepositThreshold : ', minDepositThreshold);
                var pxVal =  $C.get('v.pxValue');
                var paymentYear = (paymentMonths/12);
                var optionToPurchaseFee = Number(resultMap.Option_to_Purchase_Fee__c); 
                
                var initDepCalculated = minDepositThreshold;
                
                // Commented on 3/3 to set the slider position at the very left.
                /*   if(resultMap.Minimum_Deposit__c !== null && minDepositThreshold !== null 
                 * 		&& minDepositThreshold != 'undefined' && minDepositThreshold != 'NaN') {
                    
                    var minDepPercent = resultMap.Minimum_Deposit__c ;
                    
                    console.log('totalPackagePrice on UI is : ', totalpackageprice);
                    
                    var minDepositCalculated = (totalpackageprice * (minDepPercent / 100)) - pxVal ;
                    
                    if(minDepositCalculated > minDepositThreshold) {
                        
                        initDepCalculated = minDepositCalculated ;
                    }
                    
                    $C.set("v.minimumDeposit", minDepositThreshold);
                    $C.set("v.totalDeposit", initDepCalculated.toFixed(2));
                    
                    console.log('calculated initial deposit is : ', initDepCalculated);
                }
                
                else { 
                $C.set("v.minimumDeposit", initDepCalculated.toFixed(2)); 
                $C.set("v.totalDeposit", initDepCalculated.toFixed(2));
                //    }*/
                
                // Set minimum deposit % value from Finance Provide account else set default value
                if(resultMap.Minimum_Deposit__c != null & resultMap.Minimum_Deposit__c != 'undefined') {
                $C.set("v.minimumDepositPercent", resultMap.Minimum_Deposit__c);
                }
                
                if(minDepositThreshold !== null && minDepositThreshold != 'undefined' && minDepositThreshold != 'NaN') {
                     $C.set("v.minimumDeposit", initDepCalculated.toFixed(2)); 
               		 $C.set("v.totalDeposit", initDepCalculated.toFixed(2));
                }
                else {
                    var minDepositCalculated = (totalFundable * ($C.get("v.minimumDepositPercent") / 100)) - pxVal ; 
                	 $C.set("v.minimumDeposit", minDepositCalculated.toFixed(2)); 
               		 $C.set("v.totalDeposit", minDepositCalculated.toFixed(2));
                }
                
                $C.set("v.OptiontoPurchaseFee", optionToPurchaseFee);
                $C.set("v.interestRate", resultMap.Interest_Rate__c);
                $C.set("v.representativeAPR", resultMap.APR__c);
                
                var costtochange = totalpackageprice - pxVal;  //PDR- 2583 - px value added to calculations
                console.log('costToChange : ', costtochange) ;
                $C.set("v.costToChange", costtochange.toFixed(2));
                
                
                var balToFinance = costtochange - initDepCalculated  ;
                console.log('balancetoFinance : ', balToFinance) ;
                $C.set("v.balancetoFinance", balToFinance.toFixed(2));
                
                // Calculations
                this.calculations($C, resultMap.APR__c, balToFinance, optionToPurchaseFee, paymentMonths);
                
                if(paymentMonths == null || paymentMonths === null || paymentMonths === 'undefined') {
                    $C.set("v.selectedTermMonth", 84);    
                    $C.set("v.maximumLengthofTerm", 84);
                }
                
                else { 
                    $C.set("v.maximumLengthofTerm", (paymentMonths));
                    $C.set("v.selectedTermMonth", (paymentMonths)); 
                }
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    getCalculatorResult: function($C,parameters) {
        
        var action = $C.get('c.saveCalculation');
        
        action.setParams(parameters); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            var resultMap = response.getReturnValue();
            var calculatorId = resultMap.CalculatorId ;
            var errormsg = resultMap.Error;
            var result = response.getReturnValue();
            
            console.log(response);
            
            if (state === "SUCCESS") {
                
                console.log('resultMap.Success is : ', resultMap.Success);
                
                if(resultMap.Success === 'Calculations Saved') {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success",
                        "message": "Calculation Saved successfully"
                    });
                    toastEvent.fire();
                    
                    $C.set("v.isFlowModalOpen", true);
                    
                    //Find lightning flow from component
                    var flow = $C.find("FinanceCalculationDocumentFlow");
                    //Put input variable values
                    var inputVariables = [
                        {
                            name : "CalculatorId",
                            type : "String",
                            value : calculatorId
                        }
                    ];
                    //Reference flow's Unique Name
                    flow.startFlow("FinanceCalculationDocumentFlow", inputVariables);
                    
                }
                
                else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": result
                    });
                    toastEvent.fire();
                }
            }
            
        });
        
        $A.enqueueAction(action); 
    },
    
    onDepositAmountChange: function($C, selectedDeposit){
        
        var totalpackageprice =  $C.get('v.totalPackagePrice');
        var pxVal =  $C.get('v.pxValue');
      //  var minDepositAmount = $C.get('v.minimumDeposit');
        var minDepositAmount = $C.get('v.minimumDeposit') == null ? 0 : $C.get('v.minimumDeposit');        
        console.log('min Deposite amount:- '+minDepositAmount)
        var minDepositPercent = $C.get('v.minimumDepositPercent');
        var paymentMonths = $C.get('v.selectedTermMonth');
        var paymentYear = (paymentMonths/12);
        var APRVal = $C.get('v.representativeAPR');
        var interestratevar = $C.get('v.interestRate');
        var costtochange = $C.get("v.costToChange");
        var optionToPurchaseFee = $C.get('v.OptiontoPurchaseFee');
        var initDepCalculated = minDepositAmount;
        var finalDeposit;
        var totalFundable = ($C.get('v.quote')).Fundable_Value__c;
        
        console.log('selected cash deposit in onDepositAmountChange : ', selectedDeposit);
        
        if(minDepositPercent != null) {
            
            var minDepositCalculated = (totalFundable * (minDepositPercent / 100)) - pxVal ;
            
            if(minDepositCalculated > minDepositAmount) {
                
                initDepCalculated = minDepositCalculated ;
            }
            console.log('calculated initial deposit is : ', initDepCalculated);
        }
        
        if(selectedDeposit < initDepCalculated && selectedDeposit >= minDepositAmount) {
            console.log('selected deposit is less than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
            console.log('finalDeposit: '+finalDeposit);
        }
        else if(selectedDeposit > initDepCalculated && selectedDeposit <= totalpackageprice) {
            console.log('selected deposit is greater than initial deposit : ', selectedDeposit);
            finalDeposit = selectedDeposit ;
            console.log('finalDeposit: '+finalDeposit);
        }
            else{
                finalDeposit = initDepCalculated ;
                console.log('selected deposit is greater');
                console.log('finalDeposit: '+finalDeposit);
            }

        finalDeposit = parseFloat(finalDeposit); // PDR-2676

        //PDR- 2583
        if(finalDeposit > 1000) {
            $C.set("v.totalDeposit", finalDeposit.toFixed(2));   
            console.log('finalDeposit in onDepositAmountChange : ', finalDeposit.toFixed(2));
        } else {
            $C.set("v.totalDeposit", finalDeposit);
        }
        
        // PDR- 2583 Ends
        
        var balToFinance = costtochange - finalDeposit  ;
        console.log('balancetoFinance : ', balToFinance) ;
        $C.set("v.balancetoFinance", balToFinance.toFixed(2));
        
        // Calculations
        this.calculations($C, APRVal, balToFinance, optionToPurchaseFee, paymentMonths);  
    },
    
    // Reusable method to calculate AER, Monthly Payments, Total Repayment.
    calculations: function($C, aprValue, balToFinance, optionToPurchaseFee, paymentMonths) {
        
        var apr = Number(aprValue/100);
        console.log('apr value is : ', apr);
        
        var aer = (Math.pow((apr+1), (1/12) )-1)*12 ; 
        aer = aer.toFixed(4);
        $C.set("v.aerValue", aer);
        console.log('aerValue value is : ', aer);
        
        var firstMonthPayment = ((balToFinance) * (aer/12) ) / (1 - Math.pow( (1 + aer/12), -paymentMonths) );
        firstMonthPayment = Number(firstMonthPayment).toFixed(2);
        
        var finalMonthPayment = 0; 
        
        if(optionToPurchaseFee != null && optionToPurchaseFee != 'undefined' 
           && optionToPurchaseFee != 0 && optionToPurchaseFee != 'NaN') {
            console.log('optionToPurchaseFee in If condition : ', optionToPurchaseFee);
            finalMonthPayment = Number(firstMonthPayment) + Number(optionToPurchaseFee);
        }
        else{
            finalMonthPayment = Number(firstMonthPayment);
        }
        
        $C.set("v.firstPaymentAmount",firstMonthPayment); 
        $C.set("v.monthlyPaymentAmount", firstMonthPayment);
        $C.set("v.finalPaymentAmount", finalMonthPayment);
        console.log('firstMonthPayment value is : ' , firstMonthPayment);
        console.log('finalPaymentAmount value is : ' , finalMonthPayment);
        
        var repaymentMonth = Number(firstMonthPayment) * (Number(paymentMonths)-2) ;
        $C.set("v.regularMonth", (Number(paymentMonths)-2).toFixed(2));
        
        var totalrepayment = (Number(firstMonthPayment) + repaymentMonth + Number(finalMonthPayment));
        console.log('total value of totalrepayment : ', totalrepayment) ;
        $C.set("v.totalRepayment", totalrepayment.toFixed(2));
        
        $C.set("v.totalCostToCredit", (totalrepayment - balToFinance).toFixed(2)); 
    }
})