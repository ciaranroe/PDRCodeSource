({
    // gets the initial values
    getInitialValues: function($C, $E, $H) {

        console.log('**** getInitialValues called');
        $H.getQuoteDetails($C, $E, $H);
        $H.getPXValues($C, $E, $H);       
    },

    // Update values when Finance Provider is changed
    onFinanceProvChange: function($C, $E, $H) {
        
        var quoteObj = $C.get('v.quote');
        var lookupId = $E.getParam("value")[0];
        $C.set('v.financeProviderId', lookupId);
        console.log('Finance Provider on change', lookupId) ;
        
        if(lookupId == null || lookupId == undefined || lookupId === 'undefined' || lookupId === null) {
            // Reset values when Finance Provider is set to nll
            var defaultMinDepPercent = 10;
            var defaultInterestRate = 4.75;
            $C.set('v.representativeAPR', $A.get("$Label.c.APR"));
            $C.set("v.minimumDepositPercent", defaultMinDepPercent);
            $C.set("v.interestRate", defaultInterestRate);
            
            $H.prepopulateValueswithoutFP($C);
            
        }
        else { 
            $C.set('v.loading', true);
            $H.financeProviderChange($C,quoteObj);
          //  $H.getFinanceCalcRules($C,quoteObj); 
        }
    },
    
    // changes the term values
    changeTerm: function($C, $E, $H) {
        var type = $E.getSource().get('v.name');
        var maximumTerm = $C.get('v.maximumLengthofTerm');
        var newTerm = Number($C.get('v.selectedTermMonth'));
        var optionToPurchaseFee =  $C.get('v.OptiontoPurchaseFee');
        var aprValue =  $C.get('v.representativeAPR');
        console.log('newTerm value is : ', newTerm);
        if (type == 'add') newTerm += 12;
        console.log('newTerm value after add is : ', newTerm);
        if (type == 'subtract') newTerm -= 12;
        console.log('newTerm value after subtract is : ', newTerm);
        
        if (newTerm > maximumTerm) newTerm = maximumTerm;
        if (newTerm < 12) newTerm = 12;
        
        var balToFinance = $C.get('v.balancetoFinance');
		console.log('balToFinance in Change Term is : ', balToFinance);
        
        var interestRateVal = $C.get('v.interestRate');

        $H.calculations($C,aprValue,balToFinance,optionToPurchaseFee, newTerm);
        
        $C.set('v.selectedTermMonth', newTerm);        
    },
    
    // changes the deposit values
    changeDeposit: function($C, $E, $H) {
        console.log('chanage deposit');
        var type = $E.getSource().get('v.name');
        var minimumDeposit = $C.get('v.minimumDeposit');
        var newDeposit = Number($C.get('v.totalDeposit'));
        var maxDeposit = Number($C.get('v.totalPackagePrice'));
        console.log('change deposit type is : ', type);
        
        if (type == 'add') newDeposit += 500;
        
        if (type == 'subtract') newDeposit -= 500;
        
        if (type == undefined) newDeposit =  Number($C.find('depositRange').get('v.value'));
        if (newDeposit < minimumDeposit) newDeposit = minimumDeposit;
        if (newDeposit > maxDeposit) newDeposit = maxDeposit;
        newDeposit = Number(newDeposit);
        if (!isNaN(newDeposit)) newDeposit = Number(newDeposit.toFixed(2));
        console.log('deposit is in change deposit: ', newDeposit);
        
        $H.onDepositAmountChange($C, newDeposit);
    },

    // Save result as a new Calculator record
    saveResult: function($C, $E, $H) {
        
     var quote = $C.get('v.quote');
     var totalAmountPayable = $C.get('v.totalPackagePrice');
    
        console.log('totalAmountPayable : ', totalAmountPayable);        
        var calculation = {
            Name: quote.Name,
            CPQ_Quote__c: $C.get('v.quoteId'),
            Balance_to_Finance__c: $C.get('v.balancetoFinance'),
            APR__c: $C.get('v.representativeAPR'),
            Interest_Rate__c: $C.get('v.interestRate'),
            Deposit__c: $C.get('v.totalDeposit'),
            Finance_Provider__c: $C.get('v.financeProviderId'),
            Monthly_Repayment__c: $C.get('v.monthlyPaymentAmount'),
            Months_To_Pay_Back__c: $C.get('v.selectedTermMonth'),
            Option_to_Purchase_Fee__c: $C.get('v.OptiontoPurchaseFee'),
            Total_Repayment__c: $C.get('v.totalRepayment'),
            Total_Cost_Of_Credit__c: $C.get('v.totalCostToCredit'),
            Total_Amount_Payable__c: totalAmountPayable,
            InventoryType__c: quote.Holiday_Home__r.Type__c,
            Location__c: quote.Park__c,
            Model_Year__c: $C.get('v.modelYearValue'),
            Agreement_Number__c: $C.get('v.agreementNumber'),
            Type__c: 'Finance',
            Initial_Payment__c : $C.get('v.firstPaymentAmount')
        };
        console.log(calculation);
        
        var params = {
            result: calculation    
        };
        
        $H.getCalculatorResult($C,params);
    },
    
    // Close flow modal and redirect user to quote record
    handleFlowStatusChange: function($C, $E, $H) { 
        
        console.log('event status is ', $E.getParam("status"));
        if($E.getParam("status") === "FINISHED") {
            
            var urlEvent = $A.get("e.force:navigateToSObject");
            urlEvent.setParams({
                "recordId": $C.get('v.quoteId'),
                "isredirect": "true"
            });
            urlEvent.fire(); 
            
            $C.set("v.isFlowModalOpen", false);
        }
    }
})