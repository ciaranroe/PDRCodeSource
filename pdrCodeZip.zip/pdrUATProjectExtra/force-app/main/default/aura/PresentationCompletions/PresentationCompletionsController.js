({
    doInit : function($C, $E, $H) {

        var getRecordApex = $C.get('c.getRecordApex');
        getRecordApex.setParams({recordId : $C.get('v.recordId')});
        getRecordApex.setCallback(this, function(response){
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var result = response.getReturnValue();//opportunity
                var record = result.opportunity;
				$C.set('v.HPICheck',result.HPICheck);
                console.log('result.sellingAccountIdFormula::>>',result.sellingAccountIdFormula);
                if(result.sellingAccountIdFormula != null && result.sellingAccountIdFormula != undefined){ 
                    $C.set('v.sellingAccountIdFormula', result.sellingAccountIdFormula);  
                } 
                
                record.TotalDocuments = record.Documents__r ? record.Documents__r.length : 0;
                record.CompletedDocuments = 0;

                if (record.Documents__r){
                    record.Documents__r.forEach(function(doc){
                        if (doc.Status__c == 'Complete' && doc.Approved__c){
                            record.CompletedDocuments += 1;
                        }
                    });
                }

                record.Signees = 0;
                record.SigneesComplete = 0;

                // if (record.Opportunity_Members__r){
                //     if (record.RecordType.Name.includes('Pitch Move')){
                //         record.Signees = record.Opportunity_Members__r.length
                //     } else {
                //         record.Signees = record.Opportunity_Members__r.length * 2;
                //     }
                // }

                if (record.Weaver_Signs__r){
                    record.Weaver_Signs__r.forEach(function(signRecord){
                        record.Signees += signRecord.aptk_weaver_s__Total_Signees__c;
                        record.SigneesComplete += signRecord.aptk_weaver_s__Total_Signed__c;
                    });

                }

                record.Appraisals = 0;
                record.AppraisalsComplete = 0;

                if (record.Appraisal_Forms__r){
                    record.Appraisal_Forms__r.forEach(function(form){
                        record.Appraisals += 1;
                        if (form.Completion_Date__c != null) {
                            record.AppraisalsComplete += 1;
                        }
                    });
                }

                record.FinanceChecks = 0;
                record.FinanceChecksComplete = 0;

                

                if (record.Buy_Ins__r){

                    if (record.Appraisals < record.Buy_Ins__r.length){
                        record.Appraisals = record.Buy_Ins__r.length;
                    }

                    record.Buy_Ins__r.forEach(function(buyIn){

                        record.FinanceChecks += 1;

                        if (buyIn.Inventory_Item__r){
                            if (buyIn.Inventory_Item__r.Type__c == 'Tourer' || buyIn.Inventory_Item__r.Type__c == 'Motorhome'){
                                if (buyIn.Inventory_Item__r.Last_CRIS_Check_Date_Time__c){
                                    if (buyIn.Inventory_Item__r.Last_CRIS_Check_Date_Time__c > record.CreatedDate){
                                        record.FinanceChecksComplete += 1;
                                    }
                                }
                            } else if (buyIn.Inventory_Item__r.Type__c == 'Caravan' || buyIn.Inventory_Item__r.Type__c == 'Lodge'){
                                if (buyIn.Inventory_Item__r.Last_HPI_Check_Date_Time__c){
                                    if (buyIn.Inventory_Item__r.Last_HPI_Check_Date_Time__c > record.CreatedDate){
                                        record.FinanceChecksComplete += 1;
                                    }
                                }
                            }
                        }
                    });
                }

                $C.set('v.Opportunity',record);
            }
        });
        $A.enqueueAction(getRecordApex);
    },
    
    closeModal : function($C, $E, $H){
        $C.set('v.isFlowLaunch', false);
    },
    
    //PDR-1983
    onLaunchFlow : function($C, $E, $H){
        debugger;
        $C.set('v.isFlowLaunch', true);
        console.log('Flow Click');
        var sellingAccountIdFormula = $C.get('v.sellingAccountIdFormula');
        
        if(sellingAccountIdFormula != null && sellingAccountIdFormula != undefined){
            var accountExitProcessNew = $C.find("privateSaleFlowId");
            var flowCallFromOpportunity = true;
            var inputVariables = [
                {
                    name:"recordId",
                    type:"String",
                    value:sellingAccountIdFormula
                },
                {
                    name:"flowCallFromOpportunity",
                    type:"Boolean",
                    value: flowCallFromOpportunity
                }
            ];
            
            accountExitProcessNew.startFlow("Account_Exit_Process_New", inputVariables);  
        } 
        
    },
    //PDR-1983
    handleStatusChange : function(component, event, helper) {
        debugger;
        if(event.getParam("status") === "FINISHED") { 
            //$A.get('e.force:refreshView').fire();
            $C.set('v.isFlowLaunch', false);
        } 
        console.log('Flow Status::', event.getParam("status"));
        console.log('131eventError::', event.getParam("error"));
        console.log('131event::', event);
        
    }
})