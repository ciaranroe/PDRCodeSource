({
	getExitOfferRecord: function($C, $E, $H) { 
        
        var fetchExitOfferDetails = $C.get('c.fetchExitOfferDetails');
        fetchExitOfferDetails.setParams({recordId : $C.get('v.recordId')});
        fetchExitOfferDetails.setCallback(this, function(response){
            console.log('response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var record = response.getReturnValue();
                console.log('record : ', record);
                $C.set('v.ExitOffer',record.exitOffer);
                
                if(record.debitNoteList != null && record.debitNoteList != 'undefined' && record.debitNoteList != " ") {
                    $C.set('v.listOfDN',record.debitNoteList);
                }
                
                if(record.creditNoteList != null && record.creditNoteList != 'undefined' && record.creditNoteList != " ") {
                    $C.set('v.listOfCN',record.creditNoteList);
                }
                
                if(record.creditNoteLineList != null && record.creditNoteLineList != 'undefined' && record.creditNoteLineList != " ") {
                    $C.set('v.listOfCNL',record.creditNoteLineList);
                }
                
                if(record.debitNoteLineList != null && record.debitNoteLineList != 'undefined' && record.debitNoteLineList != " ") {
                    $C.set('v.listOfDNL',record.debitNoteLineList);
                }
            }
        });
        $A.enqueueAction(fetchExitOfferDetails);
    }
})