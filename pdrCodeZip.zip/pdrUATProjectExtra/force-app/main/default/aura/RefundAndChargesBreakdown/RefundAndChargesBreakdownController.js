({
	doInit : function($C, $E, $H) {
        
        $H.getExitOfferRecord($C, $E, $H);
        
    }
})