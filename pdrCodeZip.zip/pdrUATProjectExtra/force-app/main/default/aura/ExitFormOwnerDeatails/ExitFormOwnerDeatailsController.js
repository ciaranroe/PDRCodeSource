({
    doInit : function($C, $E, $H) {
        $H.getExitFormRecord($C, $E, $H); 
    },
    
    onCheck: function($C, $E, $H) {
        console.log('fill bank details : ', $C.get('v.fillBankDetails'));
        $H.getOnCheck($C, $E);
    },
    
    onNumberOfOwners: function($C, $E) {
        debugger;
        var data = [];
        var length = $C.get('v.repeateInputBoxNumber'); // user defined length
        console.log('numberOfOwners is : ' , length);
        let isAllDeselected = true;
        if(length != null && length != 'undefined' && length > 0) {
            for(var i = 0; i < length; i++) {
                data.push({'id' : '', 'name': '', 'email':'', 'isSelected': false, 'disabled': false});
            }
            $C.set('v.ownerIterationCount', data);
 
            let contractAccountContact = $C.get('v.contractAccountContact');
            console.log('contractAccountContact 27::>>'+contractAccountContact);
            if(contractAccountContact != undefined && contractAccountContact.length > 0){
                let noOfContactIteration = 0;
                if(length <= contractAccountContact.length){
                    noOfContactIteration = length;
                }else{
                    noOfContactIteration = contractAccountContact.length;
                }
                for(let i = 0; i < noOfContactIteration; i++){
                    data[i].id = contractAccountContact[i].Id;
                    data[i].name = contractAccountContact[i].Name;
                    data[i].email = contractAccountContact[i].Email;
                    if(!$A.util.isEmpty(contractAccountContact[i].Bank_Account_Name__c) && !$A.util.isEmpty(contractAccountContact[i].Bank_Account_Number__c) ){
                        data[i].isSelected = true;
                        data[i].disabled = false;
                        isAllDeselected = false;
                    }else{
                        data[i].disabled = true;
                    }
                    $C.set('v.ownerIterationCount', data);
                }
            }
            if(isAllDeselected && data != null && data.length > 0){
                for(let i = 0; i < data.length; i++){
                    data[i].disabled = false;
                }
            }
            console.log('data is : ' , data);
        } 
    },
    
    ownerNameChange: function($C, $E, $H) {
        $H.getOwnerName($C, $E);
        
        console.log('ownerNameL Controller ', $H.getOwnerName($C, $E));
    },
    
    ownerEmailChange: function($C, $E, $H) {
        $H.getOwnerEmail($C, $E);
    },
    
    handleSubmit: function($C,$E,$H) {
        $C.set("v.Spinner", true);
        var exitFormObj = $C.get('v.ExitForm');
        var ownerNameList = [];//$C.get('v.listOfOwnerName');
        var ownerEmailList = [];// $C.get('v.listOfOwnerEmail');
        var ownerNameString;
        var ownerEmailString;
        
        var isValid = true;
        
        let ownerIterationCount = $C.get("v.ownerIterationCount");   
        for(let i=0; i < ownerIterationCount.length; i++ ){
            console.log('ownerIterationCount', JSON.stringify(ownerIterationCount[i])); 
            ownerNameList.push(ownerIterationCount[i].name);
            ownerEmailList.push(ownerIterationCount[i].email);
            
            if(ownerIterationCount[i].name != undefined && ownerIterationCount[i].name != 'undefined' && ownerIterationCount[i].name != null && ownerIterationCount[i].name != '' ){
                isValid = true;
            }else{
                isValid = false;
            }
        }
        
        console.log('ownerNameList ', ownerNameList.length);
        if(ownerNameList.length > 0) {
            
            ownerNameString = ownerNameList.join();
            
            console.log('ownerNameString ', ownerNameString);
        }
        
        console.log('ownerEmailList ', ownerEmailList.length);
        if(ownerEmailList.length > 0) {
            
            ownerEmailString = ownerEmailList.join();
            
            console.log('ownerEmailString ', ownerEmailString);
        }
        
        var exitFormDetails = {
            Id: exitFormObj.Id,
            Number_of_owners__c: $C.get('v.repeateInputBoxNumber'),
            Bank_Account_Name__c: $C.get('v.bankAccountName'),
            Bank_Account_Number__c: $C.get('v.bankAccountNum'),
            Sort_Code__c: $C.get('v.sortCode'),
            Owners_Names__c: ownerNameString,
            Owners_Email_Addresses__c:ownerEmailString,
            Owners_names_and_bank_details_captured__c: true
        };
        console.log(exitFormDetails);
        debugger;
        //let ownerIterationCount = $C.get('v.ownerIterationCount');
        let contactList = [];
        let bankAccountName = $C.get('v.bankAccountName');
        let bankAccountNum = $C.get('v.bankAccountNum');
        let selectedContactIsFromOwnerIteration = false;
        let bankInfoLinkedContactId;
        let alreadyAddedContactToUpdate = [];
        
		var sortCode = $C.get('v.sortCode');
		//var bankAccountName = $C.get('v.bankAccountName');
		//var bankAccountNum = $C.get('v.bankAccountNum');
		//var ownerIterationCount = $C.get('v.ownerIterationCount');  
         
        if($A.util.isEmpty(sortCode) && $A.util.isEmpty(bankAccountName) && $A.util.isEmpty(bankAccountNum)){
            isValid = false;
            //PDR-1944  //PDR-2059 !$C.get('v.captureBankDetails')
            if(!$C.get('v.payByCheque') || !$C.get('v.captureBankDetails')){
                isValid = true;
            } 
        }
        
        
        if(isValid){ 
            if(!$A.util.isEmpty(bankAccountName) && !$A.util.isEmpty(bankAccountNum) && ownerIterationCount != null && ownerIterationCount.length > 0){
                for(let i = 0 ; i< ownerIterationCount.length; i++){
                    if(ownerIterationCount[i].isSelected && !$A.util.isEmpty(ownerIterationCount[i].id)){
                        contactList.push({
                            'Id': ownerIterationCount[i].id,
                            'Bank_Account_Name__c': bankAccountName, 
                            'Bank_Account_Number__c': bankAccountNum
                        });
                        bankInfoLinkedContactId = ownerIterationCount[i].id;
                        selectedContactIsFromOwnerIteration = true;
                    }else if(ownerIterationCount[i].id.includes('003')){
                        contactList.push({
                            'Id': ownerIterationCount[i].id,
                            'Bank_Account_Name__c': '', 
                            'Bank_Account_Number__c': ''
                        });
                    }
                    alreadyAddedContactToUpdate.push(ownerIterationCount[i].id);
                }  
            } 
            
            let contactWithBankDetailList = $C.get('v.contactWithBankDetailList');
            if(selectedContactIsFromOwnerIteration && contactWithBankDetailList != undefined && contactWithBankDetailList.length > 0){
                for(let i = 0 ; i< contactWithBankDetailList.length; i++){
                    console.log('!$A.util.isEmpty(contactWithBankDetailList[i].id::>>', contactWithBankDetailList );
                    if(!alreadyAddedContactToUpdate.includes(contactWithBankDetailList[i].Id) && !$A.util.isEmpty(bankInfoLinkedContactId) && !$A.util.isEmpty(contactWithBankDetailList[i].Id) && contactWithBankDetailList[i].Id != bankInfoLinkedContactId){
                        contactList.push({
                            'Id': contactWithBankDetailList[i].Id,
                            'Bank_Account_Name__c': '', 
                            'Bank_Account_Number__c': ''
                        });   
                    }
                }
            }
            
            var params = {
                updatedExitForm: exitFormDetails,
                updateContactList: contactList
            };
            
            $H.updateExitFormAction($C,params);
        }else{
            var toastEvent = $A.get("e.force:showToast");
            $C.set("v.Spinner", false);
            toastEvent.setParams({
                title : 'Error',
                message:'Enter all input values of \'Owner Details\' section',
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }
    },
    
    handleContactClick : function($C,$E,$H){
        debugger;
        console.log('Clicked on Contact');
        var name = $E.currentTarget.dataset.name;
        var ownerIndex = $E.currentTarget.dataset.ownerindex;
        var contactIndex = $E.currentTarget.dataset.contactindex;
        var ownerEmail = $E.currentTarget.dataset.email;
        
        console.log('Name:>> ',name);
        console.log('ownerIndex:>> ',ownerIndex);
        console.log('contactIndex::>>',contactIndex);
        console.log('ownerEmail:>> ',ownerEmail);
        
        let ownerIterationCount = $C.get("v.ownerIterationCount"); 
        let contactList = $C.get("v.contactList");  
        for(let i=0; i < contactList.length; i++ ){
            if(contactIndex == i){
                console.log('contactList[i]::>>',JSON.stringify(contactList[i]));
                ownerIterationCount[ownerIndex].id = contactList[i].Id;
                ownerIterationCount[ownerIndex].name = contactList[i].Name;
                ownerIterationCount[ownerIndex].email = contactList[i].Email; 
                break;
            }
        }
        
        var allValid = $C.find('contact').reduce(function (validSoFar, inputCmp) {
            
            console.log('inputCmp::>>',inputCmp.get("v.value"));
            console.log('get("v.validity")',inputCmp.get("v.validity"));
            console.log('isValid',inputCmp.isValid);
            if(!inputCmp.isValid() && inputCmp.get('v.name') == ownerIndex){
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            } 
        }, true);
        
        $C.set("v.ownerIterationCount", ownerIterationCount); 
        $C.set("v.selectedInputRow", "");
        $C.set("v.contactList", undefined);
    },
    
    onCheckBox : function($C,$E,$H){
        debugger;
        console.log('ownerIterationCount on check::>>', $C.get('v.ownerIterationCount'));
        let selectedIndex = $E.getSource().get("v.name");
        let value = $E.getSource().get("v.value");
        let ownerIterationCount = $C.get("v.ownerIterationCount");
        let isAllDeselected = true;
        for(let i = 0; i < ownerIterationCount.length; i++ ){
            console.log('Selected Row::>>', selectedIndex+':- '+value);
            if(i == (selectedIndex) && value){ 
                ownerIterationCount[i].isSelected = true;
                ownerIterationCount[i].disabled = false; 
                isAllDeselected = false;
            }else{
                ownerIterationCount[i].isSelected = false;
                ownerIterationCount[i].disabled = true; 
            } 
        }
        if(isAllDeselected){
           for(let i = 0; i < ownerIterationCount.length; i++ ){
             ownerIterationCount[i].disabled = false; 
        	} 
        }
        $C.set("v.ownerIterationCount", ownerIterationCount);
    }
    
})