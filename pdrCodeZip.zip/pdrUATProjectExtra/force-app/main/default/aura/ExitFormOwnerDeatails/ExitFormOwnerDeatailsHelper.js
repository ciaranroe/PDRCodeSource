({
    getExitFormRecord: function($C, $E, $H) { 
        
        var fetchExitFormDetails = $C.get('c.fetchExitFormDetails');
        fetchExitFormDetails.setParams({recordId : $C.get('v.recordId')});
        fetchExitFormDetails.setCallback(this, function(response){
            console.log('response is : ' , response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                var record = response.getReturnValue();
                let ownerIterationCount =[];
                console.log('record : ', record);
                
                $C.set('v.ExitForm',record.exitForm);
                //$C.set('v.bankDetailscheckboxValue', true);
                /*
                if(record.sortCodeValue != null && record.sortCodeValue != 'undefined' && record.sortCodeValue != " ") {
                    $C.set('v.sortCode',record.sortCodeValue);
                }
                if(record.bankAccountNameValue != null && record.bankAccountNameValue != 'undefined' && record.bankAccountNameValue != " ") {
                    $C.set('v.bankAccountName',record.bankAccountNameValue);
                }
                if(record.bankAccountNumValue != null && record.bankAccountNumValue != 'undefined' && record.bankAccountNumValue != " ") {
                    $C.set('v.bankAccountNum',record.bankAccountNumValue);
                }*/
                if(record.ownersNameString != null && record.ownersNameString != 'undefined' && record.ownersNameString != " ") {
                    //$C.set('v.ownerIterationCount',(record.ownersNameString).split(","));
                    $C.set('v.ownerIterationCount',ownerIterationCount);
                }
                if(record.ownersEmailString != null && record.ownersEmailString != 'undefined' && record.ownersEmailString != " ") {
                    //$C.set('v.ownerIterationCount',(record.ownersEmailString).split(","));
                    $C.set('v.ownerIterationCount',ownerIterationCount);
                } 
                if(record.ownersCount != null && record.ownersCount != 'undefined' && record.ownersCount != " " && record.ownersCount > 0) {
                    //$C.set('v.repeateInputBoxNumber', record.ownersCount);
                } 
                if(record.contractAccountContactList != undefined && record.contractAccountContactList != null){ 
                    $C.set('v.contractAccountContact', record.contractAccountContactList);
                    $C.set('v.numberOfContractAccountContact', record.contractAccountContactList.length); 
                }else{
                    $C.set('v.numberOfContractAccountContact', 0);
                }
                if(record.contactWithBankDetailList){
                    $C.set('v.contactWithBankDetailList',record.contactWithBankDetailList);
                }
                
                var exitOffer = record.latestExitOffer;
                var payableByPDR = exitOffer != null ? JSON.parse(JSON.stringify(exitOffer.Payable_By_Parkdean_Resorts__c)) : 0;
                console.log('payableByPDR::>>',payableByPDR);
                if(payableByPDR && payableByPDR <= 0){
                    console.log('payableByPDR', true);
                }
                
                //PDR-2059
                if(record.exitForm.RecordType.Name == 'Repossession' || 
                   record.exitForm.RecordType.Name == 'Voluntary Termination' ||
                   record.exitForm.RecordType.Name == 'In Lien' ){
                    if(record.exitForm.Pay_by_Cheque__c == true){
                        //Hide Bank Details
                        $C.set('v.showBankDetails', false);
                    }else{
                        $C.set('v.showBankDetails', true); 
                    } 
                    $C.set('v.isOwnerDetailsVisible',true);
                    $C.set('v.captureBankDetails',true);
                }else{
                    $C.set('v.isOwnerDetailsVisible',true);
                    $C.set('v.showBankDetails', true);
                    if(payableByPDR <= 0){
                        $C.set('v.captureBankDetails',false);
                    }else{ 
                        $C.set('v.captureBankDetails',true);
                    }
                }

                //PDR-1962
                if(record.exitForm.RecordType.Name == 'Repossession' || record.exitForm.RecordType.Name == 'Voluntary Termination'){
                    if(record.fpSortCodeValue != null && record.fpSortCodeValue != 'undefined' && record.fpSortCodeValue != " ") {
                        $C.set('v.sortCode',record.fpSortCodeValue);
                    }
                    if(record.fpAccountNameValue != null && record.fpAccountNameValue != 'undefined' && record.fpAccountNameValue != " ") {
                        $C.set('v.bankAccountName',record.fpAccountNameValue);
                    }
                    if(record.fpAccountNumberValue != null && record.fpAccountNumberValue != 'undefined' && record.fpAccountNumberValue != " ") {
                        $C.set('v.bankAccountNum',record.fpAccountNumberValue);
                    }
                }else{
                    if(record.sortCodeValue != null && record.sortCodeValue != 'undefined' && record.sortCodeValue != " ") {
                        $C.set('v.sortCode',record.sortCodeValue);
                    }
                    if(record.bankAccountNameValue != null && record.bankAccountNameValue != 'undefined' && record.bankAccountNameValue != " ") {
                        $C.set('v.bankAccountName',record.bankAccountNameValue);
                    }
                    if(record.bankAccountNumValue != null && record.bankAccountNumValue != 'undefined' && record.bankAccountNumValue != " ") {
                        $C.set('v.bankAccountNum',record.bankAccountNumValue);
                    }
                }
                

                //PDR-1944
                debugger;
                if(record.payByCheque != undefined && record.payByCheque != null ){
                    $C.set('v.payByChequeOriginal', record.payByCheque);
                    if(record.payByCheque){
                     	$C.set('v.payByCheque', false);   
                    }else{
                        $C.set('v.payByCheque',true);
                    } 
                }
                if(record.isInlienOrRepossession != undefined && record.isInlienOrRepossession != null){
                    $C.set('v.isInlienOrRepossession',record.isInlienOrRepossession);
                    
                }
                console.log('contactWithBankDetailList::>> ',record.contactWithBankDetailList);
            }
        });
        $A.enqueueAction(fetchExitFormDetails);
    },
    
    getOnCheck: function($C, $E, $H) {
        /*var checkBoxFieldValue = false;
        if($C.get('v.payByCheque')){
            checkBoxFieldValue = $C.get('v.payByCheque');
        } else {
            checkBoxFieldValue = $E.getSource().get("v.checked");
        }
        console.log('checkBoxFieldValue' , checkBoxFieldValue);
        $C.set("v.bankDetailscheckboxValue", checkBoxFieldValue);
        */ 
        $C.set("v.bankDetailscheckboxValue", $E.getSource().get("v.checked"));
        
    },
    
    getOwnerName: function($C, $E) {
        debugger;
        var action = $E.getSource();  
        var ownerNameVal = action.get("v.value");
        //var ownerNameVal = $C.get('v.ownerName');
        var ownerNameList = $C.get('v.listOfOwnerName');
        const rowIndex = action.get('v.title');
        
        $C.set("v.selectedInputRow", action.get("v.name"));
        console.log('SelectedRow-----',$C.get("v.selectedInputRow"));
        console.log('ownerNameVal is : ', ownerNameVal);
        console.log('name index is : ', rowIndex);
        
        if(ownerNameVal != null && ownerNameVal != 'undefined' && ownerNameVal != "" && ownerNameVal != " ") {
            console.log('Inside If');
            var action = $C.get('c.findByName');
            action.setParams({ 
                "searchKey" : ownerNameVal        
                             });
             action.setCallback(this, function(response) {
                 var state = response.getState();
            if(state == 'SUCCESS') {
                $C.set("v.contactList", response.getReturnValue());
            }

        });
        $A.enqueueAction(action);
       
            ownerNameList.push(ownerNameVal);
        }
        else {
            console.log('Inside else');
            ownerNameList.splice(rowIndex, 1);
        }
        console.log('ownerNameList: ', ownerNameList);
    },
    
    getOwnerEmail: function($C, $E) {
        
        var action = $E.getSource();  
        var ownerEmailVal = action.get("v.value");
        var rowIndex = action.get('v.title');
        console.log('email index is : ', rowIndex);
        $C.set("v.selectedInputRow", action.get("v.name"));
        // var ownerEmailVal = $C.get('v.ownerEmail');
        var ownerEmailList = $C.get('v.listOfOwnerEmail');
        
        if(ownerEmailVal != null && ownerEmailVal != 'undefined' && ownerEmailVal != "" && ownerEmailVal != " ") {
            var action = $C.get('c.findByEmail');
            action.setParams({ "searchKey" : ownerEmailVal });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if(state == 'SUCCESS') {
                    $C.set("v.contactList", response.getReturnValue());
                }
            });
            $A.enqueueAction(action);
            ownerEmailList.push(ownerEmailVal);
        }
        else {
            console.log('Inside else');
            ownerEmailList.splice(rowIndex, 1);
        }
        console.log('ownerEmailList: ', ownerEmailList);
    },
    
    updateExitFormAction: function($C,parameters) {
        console.log('parameters is : ', parameters);
        var action = $C.get('c.saveExitForm');
        action.setParams(parameters);  
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state === "SUCCESS") {
                
                var result = response.getReturnValue();
                
                if(result === 'SUCCESS') {                   
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success",
                        "message": "Exit Form Saved successfully"
                    });
                    toastEvent.fire();
                    $C.set('v.repeateInputBoxNumber', '');
                    $A.get('e.force:refreshView').fire();
                    $C.set("v.Spinner", false);
                }
                
                else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "mode": "Sticky",
                        "message": result
                    });
                    toastEvent.fire();
                    $C.set("v.Spinner", false);
                }
            }
            
        });
        
        $A.enqueueAction(action); 
    }
})