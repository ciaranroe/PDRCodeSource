({
    takePayment : function(component, event, helper) {
        component.find("sharedMethods").createComponent("PaymentCardholderInformation", { "recordId": component.get("v.recordId") });
    }
})