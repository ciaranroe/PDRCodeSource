({
    doInit : function(component, event, helper){
        helper.showNoOfNewMessages(component, event, helper);
    },
    
    btnClick : function(component, event, helper) {
        
        var address = component.get("v.memberMessagePageUrl");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isredirect" :false
        });
        urlEvent.fire();
    }
})