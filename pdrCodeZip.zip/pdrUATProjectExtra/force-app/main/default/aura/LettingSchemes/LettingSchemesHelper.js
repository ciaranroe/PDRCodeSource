({

  // helper function to run an apex method
  // callback returns callback(err, res)
  runApex: function ($C, method, params, callback) {
    var action = $C.get("c." + method);
    action.setParams(params);
    console.log("Running LettingSchemes." + method + "() method with the following parameters: ", params);
    action.setCallback(this, function (response) {
      var status = response.getState();
      if (status === "SUCCESS") {

        console.log("For LettingSchemes." + method + "() return value", response.getReturnValue());
        return callback(null, response.getReturnValue());
      } else {
        console.error(response);
        return callback(response.getError(), null);
      }
    })
    $A.enqueueAction(action);
  },

  // take a date and format it like "Mon 20 Apr"
  formatDate: function (str) {
    var weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var d = new Date(str);
    var weekday = weekdays[d.getDay()];
    var month = months[d.getMonth()];
    return weekday + " " + d.getDate() + " " + month;
  },

  // set the dates based on profile
  setDates: function ($C) {
    var all = $C.get("v.all_dates");
    var profile = $C.get("v.profile");
    var invite = $C.get('v.invitation');
    var filter = $C.get("v.filter");
    var pscheme = $C.get('v.pscheme');

    var filtered = all.filter(function (a) {

      console.log('USING PROFILE', profile);
      var profileCheck = false;

      // console.log('invite.Primary_Scheme__c',invite.Primary_Scheme__c,'a.Season',a.Season);

      // if (a.Summer == true || (pscheme == 'GI' && a.Season)) {
      if (a.Summer == true || a.Season) {
        // if (a.Summer == true) {
        if (profile == "Sat-Sat") {
          console.log('IN SAT SAT');
          profileCheck = a.Nights == 7;
          console.log('1 - ', a.Depart, a.Nights, profileCheck);
        } else {
          profileCheck = a.Depart.indexOf("Sat") == -1;
          console.log('2 - ', a.Depart, a.Nights, profileCheck);
        }
      } else {
        profileCheck = a.Depart.indexOf("Sat") == -1;
        console.log('3 - ', a.Depart, profileCheck);
      }

      if (!profileCheck) {
        console.log('setting checked to false for', a);
        a.GISelected = false;
        a.ELSelected = false;
      }

      var filterCheck = false;
      if (filter == "All") filterCheck = true;
      if (filter == "Peak") filterCheck = a.Season;
      if (filter == "Summer") filterCheck = a.Summer;
      if (filter == "FebHalfTerm") filterCheck = a.FebHalfTerm;
      if (filter == "Festive") filterCheck = a.Festive;
      a.Show = filterCheck;

      return profileCheck;
    });
    $C.set("v.filtered_dates", filtered);

    profile = $C.get('v.invitation').Block_Profile__c;
    var selected = $C.get('v.selections');
    var unselected = all.filter(function (a) {
      var profileCheck = false;
      if (a.Summer == true || (invite.Primary_Scheme__c == 'Guaranteed Income' && a.Season)) {
        // if (a.Summer == true) {
        if (profile == "Sat-Sat") {
          profileCheck = a.Nights == 7;
        } else {
          profileCheck = a.Depart.indexOf("Sat") == -1;
        }
      } else {
        profileCheck = a.Depart.indexOf("Sat") == -1;
      }

      if (!profileCheck) {
        console.log('setting checked to false for', a);
        a.GISelected = false;
        a.ELSelected = false;
      }

      var filterCheck = false;
      if (filter == "All") filterCheck = true;
      if (filter == "Peak") filterCheck = a.Season;
      if (filter == "Summer") filterCheck = a.Summer;
      if (filter == "FebHalfTerm") filterCheck = a.FebHalfTerm;
      if (filter == "Festive") filterCheck = a.Festive;
      // overide for addition selection step 2
      if ($C.get('v.add_step') == '2') {
        filterCheck = a.GISelected == true || a.ELSelected == true ? true : false;
      }
      a.Show = filterCheck;
      var selectedCheck = selected.filter(function (b) {
        var ss = b.CheckIn;
        var aa = a.Depart;
        return ss == aa;
      });

      return profileCheck && selectedCheck.length == 0;
    })
    $C.set('v.unselected_dates', unselected);
    console.log('set v.unselected_dates', unselected);

    console.log('$H.setDates() finished');
    this.updateTotals($C);
  },

  // someone decided it'd be a good idea to not have a number field default to 0 w
  checkBlank: function (obj, key) {
    if (obj[key] == undefined || obj[key] == null || obj[key] == "") {
      obj[key] = 0;
    }
    return obj[key];
  },

  // update total values
  updateTotals: function ($C) {

    console.log('update totals called');

    // we only use the selections (i.e. saved records) as our date list when the invitation is fully accepted
    // for drafts we already apply any selections made to the filtered_dates list in loadApp() after we run the "getISelections" remote action
    // don't change this Ronan pls lol
    var selections = $C.get('v.selections');
    var status = $C.get('v.invitation').Approval_Status__c;
    var use_selections = (status.indexOf("Successful") >= 0 || status == "Park Accepted") && $C.get('v.selections').length > 0;
    var dates = $C.get("v.filtered_dates");
    if (selections.length && use_selections == true) dates = $C.get('v.selections');

    var mins = $C.get("v.mins");
    var gi = 0;
    var el = 0;
    var counts = {
      gi_peak: 0,
      gi_summer: 0,
      gi_count: 0,
      gi_total: 0,
      el_peak: 0,
      el_summer: 0,
      el_count: 0,
      el_total: 0,
      cancels: 0
    }
    dates.forEach(function (d, i) {
      // decide "week" picks
      d.GIWeek = false;
      d.ELWeek = false;
      if (d.Nights == 4 || d.Nights == 3) {

        console.log('is 4 3');
        // if we are selected + so is the next one then we are a week 
        var n = dates[i + 1];
        var l = dates[i - 1];
        var lgi = l == undefined ? false : l.GIWeek;
        var lel = l == undefined ? false : l.ELWeek;
        if (d.GISelected && lgi == false && n.GISelected) {
          d.GIWeek = true;
        }
        if (d.ELSelected && lel == false && n.ELSelected) {
          d.ELWeek = true;
        }
        //  if ($C.get("v.invitation").Approval_Status__c == 'Park Accepted') {
        //    d.GIWeek = true;
        //    d.ELWeek = true;
        //  } 
      }

      //  if (d.Nights == 7){
      //    if (d.GISelected){
      //     d.GIWeek = true;
      //    }
      //    if (d.ELSelected) {
      //     d.ELWeek = true;
      //   }
      //    console.log('nights is 7',d);
      //  }


      // update GI counts
      if (d.GISelected == true && d.BookedO != true && d.Cancel != true) {
        gi += Number(d.GI);
      }
      if (d.GISelected == true && (d.GIWeek || d.Nights == 7) && d.Cancel != true) {

        if (d.Nights == 7) {
          console.log('nights is 7', d);
        }



        if (d.Summer == true) {
          counts.gi_summer++;
          counts.gi_peak++;
        }
        if (d.Season == true) counts.gi_peak++;
        if (d.Summer == false && d.Season == false) counts.gi_count++;
        counts.gi_total++;
      }
      // update el counts
      if (d.ELSelected == true && d.BookedO != true && d.Cancel != true) {
        el += Number(d.EL);
      }
      if (d.ELSelected == true && (d.ELWeek || d.Nights == 7) && d.Cancel != true) {
        if (d.Summer == true) {
          counts.el_summer++;
          counts.el_peak++;
        }
        if (d.Season == true) counts.el_peak++;
        if (d.Summer == false && d.Season == false) counts.el_count++;
        counts.el_total++;
      }
      // update cancels
      if (d.Cancel == true) counts.cancels++;
    });

    counts.gi_peak_valid = counts.gi_peak < mins.gi_peak ? false : true;
    counts.gi_summer_valid = counts.gi_summer < mins.gi_summer ? false : true;
    counts.gi_count_valid = counts.gi_count < mins.gi_other ? false : true;
    counts.gi_total_valid = counts.gi_total < mins.gi_total ? false : true;
    counts.el_peak_valid = counts.el_peak < mins.el_peak ? false : true;
    counts.el_summer_valid = counts.el_summer < mins.el_summer ? false : true;
    counts.el_count_valid = counts.el_count < mins.el_other ? false : true;
    counts.el_total_valid = counts.el_total < mins.el_total ? false : true;
    $C.set("v.filtered_dates", dates);
    $C.set("v.selected_dates", dates.filter(function (d) {
      return d.GISelected || d.ELSelected;
    }));
    $C.set("v.gi_total", (gi).toFixed(2));
    $C.set("v.el_total", (el).toFixed(2));
    $C.set("v.counts", counts);
    $C.set("v.total", (gi + el).toFixed(2));
    // check button valid
    var valid = false;
    var scheme = $C.get("v.pscheme");

    if (scheme == 'GI') {
      console.log('EVAL VALID', counts.gi_peak_valid, counts.gi_summer_valid, counts.gi_count_valid, counts.gi_total_valid);
    }

    if (scheme == "GI" && counts.gi_peak_valid && counts.gi_summer_valid && counts.gi_count_valid && counts.gi_total_valid) {
      valid = true;
    }
    if (scheme == "EL" && counts.el_peak_valid && counts.el_summer_valid && counts.el_count_valid && counts.el_total_valid) {
      valid = true;
    }
    console.log('setting valid ====>');

    // var valid = true;
    $C.set("v.valid", valid);

    var additions = $C.get('v.unselected_dates');
    var gi_add_total = 0;
    var el_add_total = 0;
    var add_count = 0;
    additions.forEach(function (a) {
      if (a.GISelected == true || a.ELSelected == true) {
        add_count++;
        if (a.GISelected == true) gi_add_total += Number(a.GI);
        if (a.ELSelected == true) el_add_total += Number(a.EL);
      }
    })
    $C.set('v.add_count', add_count);
    $C.set('v.gi_add_total', (gi_add_total).toFixed(2));
    $C.set('v.el_add_total', (el_add_total).toFixed(2));
    $C.set('v.add_total', (gi_add_total + el_add_total).toFixed(2));

    console.log('$H.updateTotals() finished');

    // // TO DO - CALL APEX TO UPDATE DATE SELECTIONS 
    // if (saveSelections){
    //   $A.enqueueAction($C.get('c.saveSelections'));
    // }

  },

  // updates the invite status
  updateStatus: function ($C, $H, status, inviteAccepted) {

    console.log('status passed to method', status);

    var invitation = $C.get("v.invitation");
    invitation.Approval_Status__c = status;
    var invite = { Id: invitation.Id }

    if (status) invite.Approval_Status__c = invitation.Approval_Status__c;
    if (inviteAccepted) invite.Invite_Accepted__c = true;
    if (invitation.Primary_Scheme__c != undefined) invite.Primary_Scheme__c = invitation.Primary_Scheme__c;
    if (invitation.Block_Profile__c != undefined) invite.Block_Profile__c = invitation.Block_Profile__c;
    var params = {
      invitation: JSON.stringify(invite),
    };
    $H.runApex($C, 'updateInvitation', params, function (err, res) {
      if (err) return console.error(err);
      if (res.indexOf("Error:") == 0) return console.error(err);
      console.log("Set Invitation Status to " + status);
      $C.set("v.invitation", invitation);
      if ($C.get("v.saveMsg") == "Saving..") {
        $C.set("v.saveMsg", "Saved!");
        setTimeout(function () {
          $C.set("v.saveMsg", "Save Draft");
        }, 1000);
      }
      $C.set("v.loading", false);
    })
  },

  // updates the tutorial status
  shownTutorial: function ($C, $H) {
    var invitation = $C.get("v.invitation");
    invitation.Tutorial_Shown__c = true;
    $C.set("v.invitation", invitation);
    $C.set("v.tutorial", "99");
    var invite = {
      Id: invitation.Id,
      Tutorial_Shown__c: invitation.Tutorial_Shown__c
    }
    var params = {
      invitation: JSON.stringify(invite)
    };
    $H.runApex($C, 'updateInvitation', params, function (err, res) {
      if (err) return console.error(err);
      if (res.indexOf("Error:") == 0) return console.error(err);
      console.log("Set Tutorial Shown");
    })
  },


  // saves the current selection
  saveSelections: function ($C, $E, $H, isDraft) {

    $C.set("v.loading", true);

    var current = $C.get('v.invitation');
    var counts = $C.get('v.counts');
    var allowPets = $C.get('v.allowPets');

    var dates = $C.get("v.filtered_dates");
    var selections = [];

    console.log(isDraft == false ? "Saving selections" : "Saving draft");

    if (isDraft == false) $C.set("v.step", "5");

    for (var d = 0; d < dates.length; d++) {
      var s = dates[d];
      // if (s.ELSelected || s.GISelected) {

      var selectionType = 'Owner Booking';

      if (s.ELSelected) {
        selectionType = 'Easylet';
      } else if (s.GISelected) {
        selectionType = 'Guaranteed Income';
      }

      console.log('s is', s);

      var selection = {
        Check_In_Date__c: s.RawDate.split("T")[0],
        Current_Value__c: s.Price,
        EL_Available__c: s.Template.EL_Available__c,
        EL_Commission__c: current.EL_Default_Commission__c,
        EL_Selected__c: s.ELSelected,
        GI_Commission__c: current.GI_Default_Commission__c,
        Committed_Value__c: s.Price,
        Nights__c: s.Nights,
        GI_Selected__c: s.GISelected,
        GI_Available__c: s.Template.GI_Available__c,
        Peak_Season__c: s.Season,
        Peak_Summer__c: s.Summer,
        Booked_By_Owner__c: selectionType == 'Owner Booking',
        Selection__c: selectionType,
        Subhire_Invitation__c: current.Id
      }
      selections.push(selection);
      // }
    };

    console.log("Selections: ", selections);
    console.log('counts', counts);

    var params = {
      invitationId: current.Id,
      selections: JSON.stringify(selections),
      summerWeeks: $C.get('v.pscheme') == "GI" ? counts.gi_summer : counts.el_summer,
      peakWeeks: $C.get('v.pscheme') == "GI" ? counts.gi_peak : counts.gi_peak,
      totalWeeks: $C.get('v.pscheme') == "GI" ? counts.gi_total : counts.gi_total,
      profilePreference: $C.get('v.profile'),
      allowPets: allowPets
    }
    // current.Approval_Status__c = "Successful Application"; // to do - what should this be?
    current.Primary_Scheme__c = $C.get('v.pscheme') == "GI" ? 'Guaranteed Income' : 'EasyLet';
    current.Block_Profile__c = $C.get('v.profile');
    current.Allow_Pets__c = allowPets;
    if (isDraft == false) current.Submitted__c = true;
    $C.set("v.invitation", current);

    console.log(current.Eligible_to_Submit__c);

    var approvalStatus = current.Eligible_to_Submit__c && isDraft == false ? 'Successful Application' : 'Application started and saved but not completed';

    $H.runApex($C, "setSelections", params, function (err, res) {
      if (err) return console.error(err);
      if (res.indexOf("Error: ") == 0) return console.error(res);
      $H.updateStatus($C, $H, approvalStatus);
    });
  },
  beginPoll: function ($C, $E, $H) {
    console.log('beginPoll');
    var pollingStatus = $C.get('v.polling');
    // var getSignStatusApex = $C.get('c.getSignStatus')
    var signeeId = $C.get('v.signeeId');
    console.log('signeeId:  ' + signeeId);
    var getSignStatusApex = $C.get('c.getSignStatus');
    getSignStatusApex.setParams({ signeeId: signeeId });
    getSignStatusApex.setCallback(this, function (response) {
      if (response.getState() == "SUCCESS") {
        var signStatus = response.getReturnValue()
        if (signStatus) {
          console.log('Signing Complete');
          this.saveSelections($C, $E, $H, false);

          console.log('Saved selections... Setting to Step 1');
          $C.set('v.step', '1');
          $C.set('v.polling', false);
        } else {
          console.log('Signing Not Yet Complete');
          setTimeout(
            function () {
              $H.beginPoll($C, $E, $H)
            }, 1000);
        }
      }
    })
    if (pollingStatus) {
      $A.enqueueAction(getSignStatusApex);
    }
  },
  validateSort: function (sortStr) {
    var validSort = /^\d{6}$/;
    return validSort.test(sortStr);
  },
  validateAcc: function (accNoStr) {
    var validAccNo = /^\d{8}$/;
    var result = validAccNo.test(accNoStr);
    return result
  }

})