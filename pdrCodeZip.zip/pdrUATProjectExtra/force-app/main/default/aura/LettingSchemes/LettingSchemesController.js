({

  // get the initial data for the component
  loadApp: function ($C, $E, $H) {

    // clear hash if we came from HHAccountSummary
    window.location.hash = "";

    // whats the point of default values if they're not set on init
    $C.set("v.profile", "Mon-Fri Fri-Mon");
    $C.set("v.filter", "All");
    $C.set("v.step", "1");
    $C.set("v.add_step", "1");
    $C.set("v.tab", "0");
    $C.set("v.tutorial", "0");
    $C.set("v.tutorial_steps", "5");
    $C.set("v.declined", false);
    $C.set("v.pscheme", "GI");
    $C.set("v.loading", true);

    var counts = {
      gi_peak: 0,
      gi_summer: 0,
      gi_count: 0,
      gi_total: 0,
      el_peak: 0,
      el_summer: 0,
      el_count: 0,
      el_total: 0
    }
    var mins = {
      gi_peak: 0,
      gi_summer: 0,
      gi_other: 0,
      el_peak: 0,
      el_summer: 0,
      el_other: 0
    }
    $C.set("v.counts", counts);

    var params;
    var sObjectName = $C.get('v.sObjectName');

    if (sObjectName == 'Subhire_Invitation__c') {
      params = { recordId: $C.get('v.recordId') };
    } else {
      // get the subhire invitations for the currently selected holiday home
      // holiday home is specified in the URL and set by the HHMenu component
      var accountId = window.location.search.indexOf("?accountId=") == -1 ? "" : window.location.search.split("?accountId=")[1].split('&')[0];
      if (accountId == "") return null;
      // params = {recordId: accountId};

      var inviteId = window.location.search.indexOf("&inviteId=") == -1 ? "" : window.location.search.split("&inviteId=")[1].split('&')[0];
      params = { recordId: inviteId };

    }

    // once we have the invitations we can list the available years and decide whether to show the invitation or not
    $H.runApex($C, "getInvitations", params, function (err, invs) {
      if (err) return console.error(err);

      invs = invs.sort(function (a, b) {
        return a.CreatedDate - b.CreatedDate
      })

      // @TODO for now we'll just hardcode the year using the URL
      $C.set('v.invitations', invs);
      console.log("All invitations", invs);
      var current = invs[0];
      $C.set('v.invitation', current);
      $C.set('v.allowPets', current.Allow_Pets__c);

      console.log('**** CURRENT ****', current);
      // update steps and values 
      if (!current.Guaranteed_Income__c) {
        // $C.set("v.step", "1");
        // $C.set("v.steps_required", "4");
        // $C.set("v.tutorial_steps", "4");
        $C.set('v.pscheme', 'EL');

      } else {
        $C.set('v.pscheme', 'GI');
      }

      if (current.Block_Profile__c) {
        $C.set('v.profile', current.Block_Profile__c);
        console.log('SETTING ====>', current.Block_Profile__c);
      }

      console.log("Invitation", current);

      var owners = [];

      if (current.Weaver_Signees__r) {
        for (var o = 0; o < current.Weaver_Signees__r.length; o++) {
          owners.push({ Id: current.Weaver_Signees__r[o].aptk_weaver_s__Contact__r.AccountId, Name: current.Weaver_Signees__r[o].aptk_weaver_s__Contact__r.Name });
          if (current.Weaver_Signees__r[o].Is_Current_User__c) {
            console.log('setting weaver signee id');
            $C.set('v.signeeId', current.Weaver_Signees__r[o].Id);
          }
        }

      }

      $C.set("v.owner_list", owners);

      // if (current.Approval_Status__c == "Invited") $C.set("v.tutorial", "1");
      if (current.Invite_Accepted__c && !current.Tutorial_Shown__c) $C.set("v.tutorial", "1");
      if (current.Tutorial_Shown__c == true) $C.set("v.tutorial", "99");

      if (current.Joined_Date__c) $C.set('v.joined', $H.formatDate(current.Joined_Date__c));

      console.log("Current Status: ", current.Approval_Status__c);

      var mins = {
        gi_peak: $H.checkBlank(current.Subhire_Scheme_Season__r, "GI_Minimum_Peak_Season_Blocks_Required__c"),
        gi_summer: $H.checkBlank(current.Subhire_Scheme_Season__r, "GI_Minimum_Peak_Summer_Blocks_Required__c"),
        gi_total: $H.checkBlank(current.Subhire_Scheme_Season__r, "GI_Minimum_Blocks_Required__c"),
        el_peak: $H.checkBlank(current.Subhire_Scheme_Season__r, "EL_Minimum_Peak_Season_Blocks_Required__c"),
        el_summer: $H.checkBlank(current.Subhire_Scheme_Season__r, "EL_Minimum_Peak_Summer_Blocks_Required__c"),
        el_total: $H.checkBlank(current.Subhire_Scheme_Season__r, "EL_Minimum_Blocks_Required__c")
      }
      // mins.gi_total = $H.checkBlank(current.Subhire_Scheme_Season__r, "GI_Minimum_Peak_Season_Blocks_Required__c") + mins.gi_peak;// + mins.gi_summer;
      mins.gi_other = mins.gi_total - (mins.gi_peak); // + mins.gi_summer);
      // if (mins.gi_other < 0) mins.gi_other = 0;
      // mins.el_total = $H.checkBlank(current.Subhire_Scheme_Season__r, "EL_Minimum_Peak_Season_Blocks_Required__c") + mins.el_peak;// + mins.el_summer;
      mins.el_other = mins.el_total - (mins.el_peak); // + mins.el_summer);
      // if (mins.el_other < 0) mins.el_other = 0;
      $C.set("v.mins", mins);


      var grade = current.Unit_Grade__c;

      // get the template values for this season     
      params = { seasonId: current.Subhire_Scheme_Season__c }
      $H.runApex($C, "getTemplates", params, function (err, templates) {
        if (err) return console.error(err);
        // go and get the actual values for this grade from odi
        params = {
          serviceId: current.Unit_Grade__c,
          startDate: new Date(current.Season_Start__c),
          endDate: new Date(current.Season_End__c)
        }
        $H.runApex($C, "getDatePrices", params, function (err, dates) {
          if (err) return console.error(err);
          // format the results as we need
          var data = JSON.parse(dates);
          var services = data.Services;
          if (services.length == 0) {
            $C.set('v.pricingUnavailable', true);
          }
          var gi_margin = current.GI_Default_Commission__c / 100;
          var el_margin = current.EL_Default_Commission__c / 100;
          services = services.filter(function (d) {
            if (d.Nights == 7) {
              var depart = $H.formatDate(d.Depart);
              return depart.indexOf('Sat') != -1;
            } else if (d.Nights != 5) {
              return true;
            }
            return false;
          });
          var s_start = new Date(current.Subhire_Scheme_Season__r.Summer_Start_Date__c);
          var s_end = new Date(current.Subhire_Scheme_Season__r.Summer_End_Date__c);
          services = services.filter(function (d) {
            var dd = new Date(d.Depart);
            var month = dd.getMonth() + 1;
            var day = dd.getDate();
            var template = templates.filter(function (t) {
              var t_month = Number(t.Check_In_Date__c.split('-')[1]);
              var t_day = Number(t.Check_In_Date__c.split('-')[2]);
              return t_month == month && t_day == day && t.Nights__c == d.Nights;
            });
            d.Template = template[0];
            return d.Template != undefined;
          });

          // prevent past bookings
          var twoWeeks = new Date();
          twoWeeks.setDate(twoWeeks.getDate() + 14);

          services.forEach(function (d) {
            // find the matching template
            // for each price we need to add the GI + EL vales based on margin percent
            d.Summer = d.Template.Peak_Summer__c;
            d.Season = d.Template.Peak_Season__c;
            d.FebHalfTerm = d.Template.Feb_Half_Term__c;
            d.Festive = d.Template.Festive__c;
            d.RawDate = d.Depart;
            d.Depart = $H.formatDate(d.Depart);
            d.GI = d.Template.GI_Available__c == true && d.Price != 0 ? (d.Price * gi_margin).toFixed(2) : 0;
            d.GISelected = false;
            d.EL = d.Template.EL_Available__c == true && d.Price != 0 ? (d.Price * el_margin).toFixed(2) : 0;
            d.ELSelected = false;
            d.Show = true;
            d.GIWeek = false;
            d.ELWeek = false;
            d.OBSelected = true;
            if (new Date(d.RawDate) < twoWeeks) {
              d.GI = 0;
              d.EL = 0;
              d.Past = true;
            }
          });
          console.log("All Dates", services);

          // also get current selections
          params = {
            invitationId: current.Id
          }
          $H.runApex($C, "getISelections", params, function (err, selections) {
            if (err) return console.error(err);
            selections = selections.sort(function (a, b) {
              return new Date(a.Check_In_Date__c) - new Date(b.Check_In_Date__c);
            })

            if (!current.Submitted__c) {
              selections.forEach(function (selection) {
                if ((selection.GI_Selected__c || selection.EL_Selected__c) && selection.Within_2_Weeks__c) {
                  selection.GI_Selected__c = false;
                  selection.EL_Selected__c = false;
                }
              });
            }

            selections = selections.map(function (s) {
              return {
                Id: s.Id,
                Summer: s.Peak_Summer__c,
                Season: s.Peak_Season__c,
                CheckIn: $H.formatDate(s.Check_In_Date__c),
                ELSelected: s.EL_Selected__c,
                EL: s.EL_Value__c,
                Nights: s.Nights__c,
                GISelected: s.GI_Selected__c,
                GI: s.GI_Value__c,
                Booked: s.Booked_By_Guest__c || s.Booked_By_Owner__c,
                BookedG: s.Booked_By_Guest__c,
                BookedO: s.Booked_By_Owner__c,
                BookingId: s.Booking_Id__c,
                Selection: s.Selection__c,
                PastDate: s.Past_Date__c,
                Income: s.EL_Selected__c === true ? s.EL_Value__c.toFixed(2) : s.GI_Selected__c === true ? s.GI_Value__c.toFixed(2) : null,
                // Income: (s.EL_Value__c + s.GI_Value__c).toFixed(2),
                GIWeek: false,
                ELWeek: false,
                Past: false,
                Cancel: false
              }
            })
            console.log("Selections: ", selections);

            console.log("Applying draft selections, if any.");
            for (var s = 0; s < selections.length; s++) {
              var selection = selections[s];
              console.log('selection.BookingId:   ' + selection.BookingId);
              console.log('selection.BookedO:   ' + selection.BookedO);
              if ((selection.BookingId === null || selection.BookingId === undefined || selection.BookingId === '') && selection.BookedO === true) {
                console.log('found a booking error....');
                $C.set('v.bookingErrorFound', true);
              }
              for (var d = 0; d < services.length; d++) {
                var service = services[d];
                // check match
                if (selection.CheckIn == service.Depart && selection.Nights == service.Nights) {
                  service.ELSelected = selection.ELSelected;
                  service.GISelected = selection.GISelected;
                  break;
                }
              }
            }

            $C.set("v.all_dates", services);
            $C.set('v.selections', selections);

            console.log("Finished Loading.");
            console.log(services.length + " dates, " + selections.length + " selections.");

            $H.setDates($C);
            $H.updateTotals($C);
            $C.set("v.loading", false);

          });
        });
      })

      // get any statements
      params = { invitationId: current.Id };
      $H.runApex($C, "getStatements", params, function (err, statement) {
        if (err) return console.error(err);
        $C.set('v.statement', statement);
      });

      // get the letting scheme weaver template
      $H.runApex($C, "getTemplateID", {}, function (err, templateId) {
        if (err) return console.error(err);
        $C.set('v.signTemplateId', templateId);
      });

    })

  },

  // set the dates based on profile
  setDates: function ($C, $E, $H) {
    $C.set("v.profile", $E.currentTarget.value);
    $H.setDates($C);
  },

  // set app to gi scheme mode (shows gi + el, gi minimums applied)
  setGI: function ($C, $E, $H) {
    $C.set("v.pscheme", "GI");
  },

  // start invite
  inviteStart: function ($C, $E, $H) {
    $C.set("v.tutorial", "1");
    var current = $C.get("v.invitation");
    if (current.Tutorial_Shown__c == true) $C.set("v.tutorial", "99");

    var approvalStatus = 'Application started and saved but not completed';

    if (current.Account_Current_Balance__c > 0 && !current.Insurance_Valid__c) {
      approvalStatus = 'Application with Debt and No Insurance';
    } else if (current.Account_Current_Balance__c > 0) {
      approvalStatus = 'Application with Debt';
    } else if (!current.Insurance_Valid__c) {
      approvalStatus = 'Application with No Insurance';
    }

    $H.updateStatus($C, $H, approvalStatus, true);
  },

  // restart invite, cancel decline basically
  inviteRestart: function ($C, $E, $H) {
    $C.set("v.declined", false);
  },

  // decline invite
  inviteDecline: function ($C, $E, $H) {

    console.log('inv decline called');
    if ($C.get("v.declined") == false) {
      $C.set("v.declined", true);
      console.log('dec 1');
    } else {
      $H.updateStatus($C, $H, "Withdrawn");
      console.log('dec 2');
    }
  },

  // skip tutorial
  skipTutorial: function ($C, $E, $H) {
    $H.shownTutorial($C, $H);
    $C.set('v.pscheme', 'GI');
    $C.set("v.tutorial", "99");
  },

  // next tutorial
  nextTutorial: function ($C, $E, $H) {
    var current = $C.get("v.tutorial");
    var inv = $C.get("v.invitation");
    var next = "1";
    if (current == "1") next = "2";
    else if (current == "2") next = "3";
    else if (current == "3") next = "4";
    else if (current == "4") next = "5";
    if (inv.Guaranteed_Income__c) {
      if (next == "1") $C.set('v.pscheme', 'GI');
      else if (next == "2") $C.set('v.pscheme', 'EL');
      else if (next == "3") $C.set('v.pscheme', 'GI');
    }
    $C.set("v.tutorial", next);
    if (current == "5") {
      $H.shownTutorial($C, $H);
      if (current.Guaranteed_Income__c) {
        $C.set('v.pscheme', 'GI');
      }
      $C.set("v.tutorial", "99");
    }
  },

  // go back a tutorial step
  backTutorial: function ($C, $E, $H) {
    var current = $C.get("v.tutorial");
    var inv = $C.get("v.invitation");
    var next = "1";
    if (current == "2") next = "1";
    else if (current == "3") next = "2";
    else if (current == "4") next = "3";
    else if (current == "5") next = "4";
    if (inv.Guaranteed_Income__c) {
      if (next == "1") $C.set('v.pscheme', 'GI');
      else if (next == "2") $C.set('v.pscheme', 'EL');
      else if (next == "3") $C.set('v.pscheme', 'GI');
    }
    $C.set("v.tutorial", next);
  },

  // go to the next step
  nextStep: function ($C, $E, $H) {
    var current = $C.get("v.step");
    var next = "1";
    if (current == "1") next = "2";
    if (current == "2") next = "3";
    if (current == "3") next = "4";
    if (current == "4") next = "5";
    if (current == "5") next = "6";
    $C.set("v.step", next);
  },

  // go back a step
  backStep: function ($C, $E, $H) {
    var current = $C.get("v.step");
    var next = "1";
    if (current == "2") next = "1";
    if (current == "3") next = "2";
    if (current == "4") next = "3";
    if (current == "5") next = "4";
    if (current == "6") next = "5";
    $C.set("v.step", next);
  },

  // cancel submit process 
  cancelSubmit: function ($C, $E, $H) {
    $C.set("v.step", "1");
    $C.set('v.polling', false);
  },

  saveForDraft: function ($C, $E, $H) {
    $C.set("v.saveMsg", "Saving..");
    $H.saveSelections($C, $E, $H, true);
  },


  saveForLater: function ($C, $E, $H) {
    $H.saveSelections($C, $E, $H, true);
    $C.set('v.step', '1');
  },

  signAndSubmit: function ($C, $E, $H) {

    var weaverbaseULR = $C.get('v.weaverBaseURL');
    var signeeId = $C.get('v.signeeId');
    var polling = $C.get('v.polling');

    window.open(weaverbaseULR + '/WeaverSign/aptk_weaver_s__sign?signeeId=' + signeeId, '_blank');
    console.log('window opened');
    if (!polling) {
      // $H.beginPoll($C, $E, $H);
      $C.set('v.polling', true);
      $A.enqueueAction($C.get('c.beginPoll'));
    }
  },
  beginPoll: function ($C, $E, $H) {
    var pollingStatus = $C.get('v.polling');
    var signeeId = $C.get('v.signeeId');
    var sigsReceived = $C.get('v.invitation').Signatures_Received__c;
    var getSignStatusApex = $C.get('c.getSignStatus');
    getSignStatusApex.setParams({ signeeId: signeeId });
    getSignStatusApex.setCallback(this, function (response) {
      if (response.getState() == "SUCCESS") {
        var signStatus = response.getReturnValue()
        if (signStatus) {
          console.log('Signing Complete');
          $H.saveSelections($C, $E, $H, false);

          $C.set('v.step', '1');
          $C.set('v.polling', false);
          $C.set('v.invitation.Signatures_Received__c', sigsReceived + 1);
          $C.set('v.sigReceived', true);
        } else {
          console.log('Signing Not Yet Complete');
          window.setTimeout(
            $A.getCallback(function () {
              $A.enqueueAction($C.get('c.beginPoll'));
            }), 1000);
        }
      }
    })
    if (pollingStatus) {
      $A.enqueueAction(getSignStatusApex);
    }
  },
  // set app to el scheme mode (shows el only, el minimums applied)
  setEL: function ($C, $E, $H) {
    $C.set("v.pscheme", "EL");
    // clear GIs
    var dates = $C.get("v.filtered_dates");
    dates.forEach(function (d) {
      d.GISelected = false;
    });
    $C.set("v.filtered_dates", dates);
    $H.updateTotals($C, false);
  },

  // update date filter
  setFilter: function ($C, $E, $H) {
    var filter = $E.currentTarget.getAttribute("data-id");
    $C.set("v.filter", filter);
    $H.setDates($C);
  },

  // update totals when box ticked
  updateTotals: function ($C, $E, $H) {
    var input = $E.currentTarget.getAttribute("data-id");
    var index = input.split("|")[0];
    var type = input.split("|")[1];
    var dates = $C.get('v.invitation').Approval_Status__c == "Park Accepted" ? $C.get('v.unselected_dates') : $C.get("v.filtered_dates");
    dates[index][type + "Selected"] = !dates[index][type + "Selected"];
    $H.updateTotals($C, false);
  },

  // update totals for cancellations
  updateTotalFromCancel: function ($C, $E, $H) {
    var input = $E.currentTarget.getAttribute("data-id");
    var index = input.split("|")[0];
    var dates = $C.get("v.selections")[index].Cancel = !$C.get("v.selections")[index].Cancel;
    $H.updateTotals($C, false);
  },

  // open payment model, reset anything we need to here
  openPaymentInfo: function ($C, $E, $H) {
    var invitation = $C.get("v.invitation");
    $C.set("v.paymentInfoPopup", true);
    // reset popup fields from the actual invitation
    var currentOwner = invitation.Bank_Account_Holder__c;
    console.log("currentOwner: " + currentOwner, invitation);
    if (currentOwner == "" || currentOwner == null || currentOwner == undefined) currentOwner = $C.get("v.owner_list")[0].Id;
    console.log("currentOwner2:", currentOwner);
    $C.set("v.paymentOwner", currentOwner);
    $C.set("v.paymentName", invitation.Bank_Account_Name__c == null ? "" : invitation.Bank_Account_Name__c);
    $C.set("v.paymentNumber", invitation.Bank_Account_Number__c == null ? "" : invitation.Bank_Account_Number__c);
    $C.set('v.accNoValid', $H.validateAcc(invitation.Bank_Account_Number__c));
    $C.set("v.paymentSort", invitation.Sort_Code__c == null ? "" : invitation.Sort_Code__c);
    $C.set('v.sortCodeValid', $H.validatSort(invitation.Sort_Code__c));
    // $C.set("v.paymentCheque", invitation.Payment_by_Cheque__c == null ? false : invitation.Payment_by_Cheque__c);
    $C.set("v.paymentUpdated", false);
  },

  // close payment model
  closePaymentInfo: function ($C, $E, $H) {
    $C.set("v.paymentInfoPopup", false);
  },

  // close signature model
  closeSigReceivedModal: function ($C, $E, $H) {
    $C.set("v.sigReceived", false);
  },

  // // change cheque payment
  // setPaymentCheque: function($C, $E, $H) {
  //   $C.set("v.paymentCheque", !$C.get("v.paymentCheque"));
  // },

  // change cheque payment
  setPaymentOwner: function ($C, $E, $H) {
    $C.set("v.paymentOwner", $C.find("hhOwner").get("v.value"));
  },

  // update payment info
  updatePaymentInfo: function ($C, $E, $H) {
    var invitation = $C.get("v.invitation");
    var update = {
      Id: invitation.Id,
      Bank_Account_Holder__c: $C.get("v.paymentOwner"),
      Bank_Account_Name__c: $C.get("v.paymentName"),
      Bank_Account_Number__c: $C.get("v.paymentNumber"),
      Sort_Code__c: $C.get("v.paymentSort"),
      // Payment_by_Cheque__c: $C.get("v.paymentCheque"),
      Payment_Information_Provided__c: true
    }
    var params = {
      invitation: JSON.stringify(update)
    }
    $H.runApex($C, "updateInvitation", params, function (err, res) {
      if (err) return console.error(err);
      invitation.Bank_Account_Holder__c = update.Bank_Account_Holder__c;
      invitation.Bank_Account_Name__c = update.Bank_Account_Name__c;
      invitation.Bank_Account_Number__c = update.Bank_Account_Number__c;
      invitation.Sort_Code__c = update.Sort_Code__c;
      invitation.Payment_by_Cheque__c = update.Payment_by_Cheque__c;
      invitation.Payment_Information_Provided__c = true;
      $C.set("v.invitation", invitation);
      $C.set("v.paymentUpdated", true);
    });
  },
  reOpenInvitation: function ($C, $E, $H) {

    $C.set('v.loading', true);
    var invitation = $C.get("v.invitation");
    var reOpenInvitationApex = $C.get('c.reOpenInvitationApex');
    reOpenInvitationApex.setParams({ invitationId: invitation.Id });
    reOpenInvitationApex.setCallback(this, function (response) {

      $C.set('v.loading', false);
      console.log('c.reOpenInvitationApex', response.getState(), response.getReturnValue());

      if (response.getState() === 'SUCCESS') {
        if (response.getReturnValue() === 'success') {
          $A.enqueueAction($C.get('c.loadApp'));
        }
      }
    });
    $A.enqueueAction(reOpenInvitationApex);

  },
  cancelBooking: function ($C, $E, $H) {

    console.log('cancelBooking called ');

    $C.set('v.loading', true);

    var selections = $C.get('v.selections');
    var index = $E.currentTarget.dataset.index;
    var selection = selections[index];
    console.log('selection is ', selection);

    var cancelBookingApex = $C.get('c.cancelBookingApex');
    cancelBookingApex.setParams({ bookingId: selection.Id });
    cancelBookingApex.setCallback(this, function (response) {

      $C.set('v.loading', false);

      console.log('c.cancelBookingApex', response.getState(), response.getReturnValue());

      if (response.getState() === 'SUCCESS') {
        selection.Selection = 'EasyLet';
        selection.ELSelected = true;
        selection.Booked = false;
        selection.BookedG = false;
        selection.BookedO = false;
        selection.BookingId = null;
        $C.set('v.selections', selections);

        $H.updateTotals($C);
        console.log('selections set');
      }
    });
    $A.enqueueAction(cancelBookingApex);

  },

  addBooking: function ($C, $E, $H) {

    console.log('addBooking called ');

    $C.set('v.loading', true);

    var selections = $C.get('v.selections');
    var index = $E.currentTarget.dataset.index;
    var selection = selections[index];
    console.log('selection is ', selection);

    var addBookingApex = $C.get('c.addBookingApex');
    addBookingApex.setParams({ bookingId: selection.Id });
    addBookingApex.setCallback(this, function (response) {

      $C.set('v.loading', false);
      console.log('c.addBookingApex', response.getState(), response.getReturnValue());

      if (response.getState() === 'SUCCESS') {


        var res = response.getReturnValue();

        // IF THE RESPONSE FROM APEX IS SOMETHING ABOUT IT BEING BOOKED, WE NEED A CUSTOM POPUP 
        // TELLING THE CUSTOMER THE DATE ISN'T AVAILABLE, AND TO CONTACT THE TEAM

        if (!res.startsWith('error:')) {
          selection.Selection = 'Owner Booking';
          selection.ELSelected = false;
          selection.Booked = true;
          selection.BookedG = false;
          selection.BookedO = true;
          selection.BookingId = res;
          $C.set('v.selections', selections);
          $H.updateTotals($C);
        } else {
          selection.Error = true;
          console.log('adding error!', res);
          $C.set('v.addBookingError', res.substring(res.indexOf('error:') + 6));
          $C.set('v.selections', selections);
        }
      }
    });
    $A.enqueueAction(addBookingApex);

  },
  clearAddBookingError: function ($C, $E, $H) {
    $C.set('v.addBookingError', '');
  },

  // add new selections
  addBookings: function ($C, $E, $H) {

    var current = $C.get('v.invitation');
    var dates = $C.get("v.unselected_dates");
    var selections = [];

    for (var d = 0; d < dates.length; d++) {
      var s = dates[d];
      if (s.ELSelected || s.GISelected) {
        var selection = {
          Check_In_Date__c: s.RawDate.split("T")[0],
          Current_Value__c: s.Price,
          EL_Available__c: s.Template.EL_Available__c,
          EL_Commission__c: current.EL_Default_Commission__c,
          EL_Selected__c: s.ELSelected,
          GI_Commission__c: current.GI_Default_Commission__c,
          Committed_Value__c: s.Price,
          Nights__c: s.Nights,
          GI_Available__c: s.Template.GI_Available__c,
          GI_Selected__c: s.GISelected,
          Peak_Season__c: s.Season,
          Peak_Summer__c: s.Summer,
          Selection__c: s.ELSelected ? 'EasyLet' : 'Guaranteed Income',
          Subhire_Invitation__c: current.Id,
          Partner_Selection_Id__c: s.Partner_Selection_Id__c
        }
        selections.push(selection);
      }
    }

    console.log("Additions: ", selections);

    var params = {
      selections: JSON.stringify(selections)
    }
    $H.runApex($C, "addSelections", params, function (err, res) {
      if (err) return console.error(err);
      if (res.indexOf("Error: ") == 0) return console.error(res);
      $C.set("v.add_step", "3");
    });

  },

  // save cancellations (update as booked by owner)
  setCancellations: function ($C, $E, $H) {
    var dates = $C.get("v.selections");
    $C.set("v.loading", true);
    var cancels = [];
    for (var d = 0; d < dates.length; d++) {
      if (dates[d].Cancel == true) {
        cancels.push({
          Id: dates[d].Id,
          Booked_By_Owner__c: true
        });
      }
    }
    console.log(cancels);
    $H.runApex($C, "cancelSelections", { selections: JSON.stringify(cancels) }, function (err, res) {
      if (err) return console.error(err);
      for (var d = 0; d < dates.length; d++) {
        if (dates[d].Cancel == true) dates[d].Booked_By_Owner__c = true;
      }
      $C.set("v.loading", false);
      $C.set("v.add_step", "3");
      setTimeout(function () {
        window.location.reload();
      }, 1500);
    })

  },

  // save selections
  saveSelections: function ($C, $E, $H) {
    $H.saveSelections($C, $E, $H, false);
  },

  // go to the next tab in the add bookings process (approved bookings)
  nextTab: function ($C, $E, $H) {
    var current = $C.get("v.add_step");
    var next = (Number(current) + 1) + '';
    $C.set('v.add_step', next);
    $H.setDates($C);
  },

  // go to the last tab in the add bookings process (approved bookings)
  backTab: function ($C, $E, $H) {
    var current = $C.get("v.add_step");
    var next = (Number(current) - 1) + '';
    $C.set('v.add_step', next);
    $H.setDates($C);
  },

  // set tab, loading component
  setTab: function ($C, $E, $H) {
    var index = $E.currentTarget.getAttribute("data-index");
    $C.set('v.tab', index);
    $C.set('v.add_step', '1');
  },

  handlePetChange: function ($C, $E, $H) {
    var allowPets = $E.getParam("value");
    $C.set('v.allowPets', allowPets);
  },

  validateSortCode: function ($C, $E, $H) {
    var sortString = $E.getSource().get("v.value");
    var result = $H.validateSort(sortString);
    $C.set('v.sortCodeValid', result);
  },

  validateAccNo: function ($C, $E, $H) {
    var accNoStr = $E.getSource().get("v.value");
    var result = $H.validateAcc(accNoStr);
    $C.set('v.accNoValid', result);
  }

})