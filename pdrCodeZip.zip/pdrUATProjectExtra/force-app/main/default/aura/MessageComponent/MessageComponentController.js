({
	displayDetailError : function(component, event, helper) {
		component.set("v.detailMessage", true);
	},
    hideDetailError : function(component, event, helper) {
		component.set("v.detailMessage", false);
	},
     hideErrorComponent : function(component, event, helper) {
		component.set("v.message", '');
	}

})