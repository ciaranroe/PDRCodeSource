({
    getCommunityUserName : function(component, event, helper) {
        var action = component.get("c.getUserName");
       
            action.setCallback(this, function (response) {
            
            var state = response.getState();   
            
            if (state === "SUCCESS") {
                var record = response.getReturnValue();
                component.set('v.userDetails', record);
        
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); 
    },
    
    getAccountlist: function(component, event, helper){
        var action = component.get("c.getRelatedAccountsList");
        
        action.setCallback(this, function(actionResult) {
            
            var state = actionResult.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                
                var accs = actionResult.getReturnValue(); 
                
                component.set("v.acctList", accs);
                if (accs.length > 0) {
                  var first = accs[0].Id;
                  component.set("v.firstAcctId", first);
                }
                
                
            }   
        });
        
        $A.enqueueAction(action);
    }
})