({
    doInit: function(component, event, helper) {
        helper.getCommunityUserName(component, event, helper);
        helper.getAccountlist(component, event, helper);
    }
})