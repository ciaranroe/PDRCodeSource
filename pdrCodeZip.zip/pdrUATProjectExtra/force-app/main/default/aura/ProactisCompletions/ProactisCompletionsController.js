({
    doInit : function($C, $E, $H) {

        var getRecordApex = $C.get('c.getRecordApex');
        getRecordApex.setParams({recordId : $C.get('v.recordId')});
        getRecordApex.setCallback(this, function(response){
            console.log(response.getReturnValue()[0]);
            if (response.getState() === 'SUCCESS'){
                var record = response.getReturnValue();
                record.JobsRequired = record.RecordType.Name.startsWith('Hire Fleet');
                $C.set('v.PurchaseRequest',record);
            }
        });
        $A.enqueueAction(getRecordApex);
    },
    setPendingExport : function($C,$E,$H){
        $C.set('v.ResponsePending',true);
        var setPendingExportApex = $C.get('c.setPendingExportApex');
        setPendingExportApex.setParams({recordId : $C.get('v.recordId')});
        setPendingExportApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            if (response.getState() === 'SUCCESS'){
                if (response.getReturnValue() === 'success'){
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": 'Request now pending export to Proactis'
                    }).fire();
                    $A.get('e.force:refreshView').fire();
                } else {
                    $A.get("e.force:showToast").setParams({
                        "title": "Error!",
                        "type": "error",
                        "message": response.getReturnValue()
                    }).fire();
                }
            }
        });
        $A.enqueueAction(setPendingExportApex);
    }
})