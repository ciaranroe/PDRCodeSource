({
	saveAndView : function(component, event, helper) {
        helper.newLead(component, event, helper, 'SAVE');
	},
    overrideDuplicate: function(component, event, helper) {
         helper.newLead(component, event, helper, 'OVERRIDE');
    },
    hideUnhideNewLead: function(component, event, helper) {
        var currentButton = event.getSource(); 
        var iconName = currentButton.get('v.iconName');
	  
        if(iconName=='utility:up') {
            currentButton.set("v.iconName", "utility:down");
            component.set("v.newLeadHeight", '780');
    		var cmpTarget = component.find('newLeadHideUnhide');
    		$A.util.removeClass(cmpTarget, 'slds-hidden');
    		$A.util.addClass(cmpTarget, 'slds-visible');             
        }
        else {
            currentButton.set("v.iconName", "utility:up");
            component.set("v.newLeadHeight", '5');
    		var cmpTarget = component.find('newLeadHideUnhide');
    		$A.util.removeClass(cmpTarget, 'slds-visible');
    		$A.util.addClass(cmpTarget, 'slds-hidden');   
        }    
    },
    disableOrEnableSaveButton: function(component, event, helper) {
        var lastName = component.get("v.lastName");
        var mobile = component.get("v.mobile");
        var phone = component.get("v.phone");
        var email = component.get("v.email");
        var postcode = component.get("v.postcode");
     
        var leadSource=component.find("leadSource").get("v.value");
        
        var leadSource2=component.find("leadSource2").get("v.value");
        var enquiryMethod=component.find("enquiryMethod").get("v.value");

        if (lastName && leadSource && leadSource2 && enquiryMethod && (mobile || phone || email || postcode)) {
            component.set("v.isSaveButtonActive", false);
        } 
        else {
            component.set("v.isSaveButtonActive", true);
        }
	},
    handleCancel: function(component, event, helper) {
        var utilityBarAPI = component.find("utilitybar"); 
 		//Checking the request has come from the utility bar or new page
        utilityBarAPI.getAllUtilityInfo().then(function (response) {
            console.log('utility response:' + JSON.stringify(response));
             for (var i = 0; i < response.length; i++) {
                 if(response[i].utilityLabel=='New Lead'){
                       if (response[i].utilityVisible) {
                            utilityBarAPI.minimizeUtility();
                       } else {
                           helper.closeNewLeadTab(component, event, helper);						  
                       }
                 }
             }
         });   
        component.set("v.isActionFinished", false);
    },
    getAddress: function(component, event, helper) {       
       helper.getAddressSuggestion(component, event, helper);
    },
     getAddressDetails: function(component, event, helper) {
 		helper.getLocationDetails(component, event, helper);
     }       
})