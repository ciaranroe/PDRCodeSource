({
    newLead: function(component, event, helper, sourceButton){
         helper.scrollOnTop(component, event, helper);
        //start spinner
        component.set("v.isActionFinished", true);
        //controlling user error message
        component.set("v.serverError",'');
        component.set('v.results','');
          var params = {
          salutation: component.find("salutation").get("v.value"),
          firstName: component.get("v.firstName"),
          lastName: component.get("v.lastName"),
          email: component.get("v.email"),
          street: component.get("v.street"),
          city: component.get("v.city"),
          state: component.get("v.state"),
          country: component.get("v.country"),
          postcode: component.get("v.postcode"),
          phone: component.get("v.phone"),
          mobile: component.get("v.mobile"),
          leadSource: component.find("leadSource").get("v.value"),
          leadSource2: component.find("leadSource2").get("v.value"),
          enquiryMethod: component.find("enquiryMethod").get("v.value"),
          textOpt: component.get("v.textOpt"),
          phoneOpt: component.get("v.phoneOpt"),
          emailOpt: component.get("v.emailOpt"),
          postOpt: component.get("v.postOpt"),
          marketingConsent: component.get("v.marketingConsent"),
          note:component.get("v.note")
        };
        console.log('Lead params:' +  JSON.stringify(params)); 
        //This one hit through Save and View button
        if(sourceButton=='SAVE'){
            helper.decideNewLead(component, event, helper, JSON.stringify(params));
        }
        else if(sourceButton=='OVERRIDE'){
            helper.createNewLead(component, event, helper, JSON.stringify(params));
        }
    },
    //This function is called in Controller at onInit and onSearchInputChange
  decideNewLead: function(component, event, helper, params) {
    helper.callServer(
      component,
      "c.searchRecords",
      function(results) {
        var parseResults = JSON.parse(results);
        if (parseResults.hasError) {
          console.log("Error: " + parseResults.message);
          component.set("v.serverError", parseResults.message);
          component.set("v.isActionFinished", false);
        } else {
            component.set("v.serverError", '');
            //send without parse result as serach result component is already parsing it when duplicate will be found
            helper.handleSearchResultSuccess(component, event, helper, results,params);
        }
      },
      {
        parameterString: params
      }
    );
  },
  handleSearchResultSuccess: function(component, event, helper, results,params) {
       var parseResult=JSON.parse(results);
	  //check the duplicate
      if(parseResult.holidayMakers.length>0 || parseResult.leads.length>0 || parseResult.contacts.length>0){
          component.set('v.results',results);
          component.set("v.newLeadHeight", '5');
          var cmpTarget = component.find('newLeadHideUnhide');
          $A.util.removeClass(cmpTarget, 'slds-visible');
          $A.util.addClass(cmpTarget, 'slds-hidden');
          var cardButton = component.find("cardButton");
          cardButton.set("v.iconName", "utility:up");
          component.set("v.isActionFinished", false);
        }
      else{//No duplicate found and create the lead record.
            helper.createNewLead(component, event, helper, params);
      }
    },
    createNewLead:  function(component,event,helper,params){
         helper.callServer(
                  component,
                  "c.insertRecord",
                  function(result) {
                    var serverResult = JSON.parse(result);
                    if (serverResult.hasError) {//Error
                      console.log("Error: " + serverResult.message);
                      component.set("v.isActionFinished", false);
                      component.set("v.serverError", serverResult.message);
                    } else {//Success
						component.set("v.serverError", '');                        
                      helper.handleNewLeadResultSuccess(component, event, helper, serverResult);
                    }
                  },
                  {
                    parameterString: params
                  }
                  );
    },
     handleNewLeadResultSuccess: function(component, event, helper, results) {
	   component.set("v.serverError", '');
       console.log('Lead Id received:' + results.Id);    
         component.set("v.isActionFinished", false);		         
         if(results.Id){                        
             var utilityBarAPI = component.find("utilitybar");             
          	//Checking the request has come from the utility bar or new page
             utilityBarAPI.getAllUtilityInfo().then(function (response) {
             console.log('utility response:' + JSON.stringify(response)); 
             for (var i = 0; i < response.length; i++) {
                 if(response[i].utilityLabel=='New Lead'){
                       if (response[i].utilityVisible) {
                               helper.resetForm(component, event, helper);
                               utilityBarAPI.minimizeUtility();
                               var navigation = $A.get("e.force:navigateToSObject");
                               navigation.setParams({
                                   recordId: results.Id
                               });
                               navigation.fire();
                           } else {
                               helper.closeNewLeadTab(component, event, helper);
                               helper.redirectToNewRecordTab(component, event, helper,results.Id);
                           }         
                 }
             }               
            });        
             //Show toast message
             helper.showToast(component, event, helper,'Success!','The lead has been created successfully.');
            
         }
     },
    showToast : function(component, event, helper,title,message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message
        });
        toastEvent.fire();
	},
    resetForm: function(component,event,helper){
          component.set("v.firstName",'');
          component.set("v.lastName",'');
          component.set("v.email",'');
          component.set("v.postcode",'');
          component.set("v.phone",'');
          component.set("v.mobile",'');
          component.set("v.textOpt",false);
          component.set("v.phoneOpt",false);
          component.set("v.emailOpt",false);
          component.set("v.postOpt",false);
          component.set("v.marketingConsent",false);
          component.set("v.note",'');
          component.set('v.results','');
          component.set("v.isSaveButtonActive", true);
          component.find("salutation").reset();
          component.find("leadSource").reset();
          component.find("leadSource2").reset();
          component.find("enquiryMethod").reset();
    },
    scrollOnTop:  function(component,event,helper){
			document.getElementById('scrollTesting').scrollIntoView();
    },
    closeNewLeadTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
         workspaceAPI.getFocusedTabInfo().then(function(response) {
         	var focusedTabId = response.tabId;
	         workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });
    },
    redirectToNewRecordTab: function(component, event, helper,recordId) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.openTab({
            url: '/lightning/r/Lead/' + recordId + '/view',
        }).then(function(response) {
            workspaceAPI.focusTab({tabId : response});
       })
        .catch(function(error) {
            console.log(error);
        });
    },
    handleAddressDetailsSuccess: function(component, event, helper, placeDetails) {
            console.log('Json print');
            console.log('place placeDetails:' + placeDetails);
            var streetConcatinate = '';
            var isCountryUK=false;
        	
            // found if the country is UK or not
           // var formattedAddress=placeDetails.result.formatted_address;
            ///if (formattedAddress.includes('United Kingdom') || formattedAddress.includes('UK')){
             //   isCountryUK=true;
           // }
              for (var i = 0; i < placeDetails.result.address_components.length; i++) {
                   if (placeDetails.result.address_components[i].types[0] == "country" ) {
                       if(placeDetails.result.address_components[i].long_name=="United Kingdom" || placeDetails.result.address_components[i].long_name=="UK"){
                           isCountryUK=true;
                       }
                }
              }
            for (var i = 0; i < placeDetails.result.address_components.length; i++) {
                console.log('JSON Response****');
                console.log(placeDetails.result.address_components[i].types[0]);

                if (placeDetails.result.address_components[i].types[0] == "street_number") {
                    streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
                    console.log('1');
                    console.log(streetConcatinate);
                }               
                if (placeDetails.result.address_components[i].types[0] == "route") {
                    streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
                    console.log('2');
                    console.log(streetConcatinate);
                }
                if (placeDetails.result.address_components[i].types[0] == "country" ) {
					component.set("v.country", placeDetails.result.address_components[i].long_name);
                }
                if (placeDetails.result.address_components[i].types[0] == "postal_code" || placeDetails.result.address_components[i].types[0] == "postal_code_prefix") {
                    component.set("v.postcode", placeDetails.result.address_components[i].long_name);
                }
               //fill the below details only when the country is UK
               if(isCountryUK){
                    if (placeDetails.result.address_components[i].types[0] == "locality") {
                        streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
                        console.log('3');
                        console.log(streetConcatinate);
                    }                   
                    if (placeDetails.result.address_components[i].types[0] == "postal_town" ) {
                        component.set("v.city", placeDetails.result.address_components[i].long_name);
                    }
                }
            }
            console.log('*********streetConcatinate***');
            console.log(streetConcatinate);
            if (streetConcatinate != null) {
                component.set("v.street", streetConcatinate);                
            }
            component.set('v.predictions', []);
    },
     handleAddressSuccess: function(component, event, helper, response) {
          console.log('Json parse---');
          console.log('response.predictions:' + response.predictions);
          component.set('v.predictions', response.predictions);
     },
    getAddressSuggestion: function(component, event, helper){                   
        var location=component.get('v.location');
        if(location && location.length>3){
            var params = {location:location
                            };
            
            console.log('params:' + params)
            helper.callServer(
                  component,
                  "c.getAddressSuggestions",
                  function(results) {
                    var response = JSON.parse(results);                  
                    if (response.hasError) {
                      console.log("Error: " + response.message);
                      component.set("v.serverError", response.message);
                      component.set("v.isActionFinished", false);
                    } else {
                        component.set("v.serverError", '');
                        helper.handleAddressSuccess(component, event, helper, JSON.parse(response.message));
                    }
                  },
                  {
                    parameterString: JSON.stringify(params)
                  }
                );
        }
        else{
            component.set('v.predictions', []);
        }
    },
   getLocationDetails: function(component, event, helper){                   
        component.set("v.city", '');
        component.set("v.postcode", '');
        component.set("v.street", '');
        component.set("v.locality", '');
       component.find("location").set("v.value",'');
        var selectedItem = event.currentTarget;
        var placeid = selectedItem.dataset.placeid;
        var params = {
            location: placeid
        };
        helper.callServer(
              component,
              "c.getLocationDetails",
              function(results) {
                var response = JSON.parse(results);                  
                if (response.hasError) {
                  console.log("Error: " + response.message);
                  component.set("v.serverError", response.message);
                  component.set("v.isActionFinished", false);
                } else {
                    component.set("v.serverError", '');
					helper.handleAddressDetailsSuccess(component, event, helper, JSON.parse(response.message));
                }
              },
              {
                parameterString: JSON.stringify(params)
              }
            );
    }
})