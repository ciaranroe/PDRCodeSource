({
    doInit : function($C) {

        var getLocationsApex = $C.get('c.checkIsValidApex');
        getLocationsApex.setParams({ recordId : $C.get('v.recordId'), sObjectName : $C.get('v.sObjectName')});
        getLocationsApex.setCallback(this, function(resposne){
            if (resposne.getState() === 'SUCCESS'){
                $C.set('v.valid',resposne.getReturnValue());
            }
        });
        $A.enqueueAction(getLocationsApex);
    }
})