({
    doInit : function($C, $E, $H) {

        var getFileApex = $C.get('c.getFileApex');
        getFileApex.setParams({ documentId : $C.get('v.recordId')});
        getFileApex.setCallback(this, function(response){
            if (response.getState() === 'SUCCESS'){
                var content = response.getReturnValue();
                if (content.length){
                    $C.set('v.File',content[0]);
                }
            }

        });
        $A.enqueueAction(getFileApex);

    }
})