({
    doInit : function(component, event, helper) {

        var getQuoteContents = component.get('c.getQuoteContents');
        getQuoteContents.setParams({recordId : component.get('v.recordId')});
        getQuoteContents.setCallback(this, function(response){

            console.log('c.getQuoteContents',response.getState(),response.getReturnValue());

            if (response.getState() === 'SUCCESS'){
                var res = response.getReturnValue();

                if (res.Error){
                    $A.get("e.force:showToast").setParams({"title": "Error!","message": res.Error, "mode" : "error"}).fire();
                } else {
                    component.set('v.Rows', res);
                }
            }

        });
        $A.enqueueAction(getQuoteContents);
    }
})