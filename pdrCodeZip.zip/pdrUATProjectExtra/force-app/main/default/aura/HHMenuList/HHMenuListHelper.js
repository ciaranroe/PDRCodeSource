({
     
    getAccountlist: function(component, event, helper){
        var action = component.get("c.getRelatedAccountsList");
        
        action.setCallback(this, function(actionResult) {
            
            var state = actionResult.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                
                var accs = actionResult.getReturnValue(); 
                
                component.set("v.acctList", accs);
                if (accs.length > 0) {
                  var first = accs[0].Id;
                  component.set("v.firstAcctId", first);
                }
                if (accs.length > 1) component.set("v.plural", "s");
                
                var lettings = 0;
                var isSet = false;
                accs.forEach(function(a) {
                  if (a.Subhire_Invitations__r != null && a.Subhire_Invitations__r.length > 0) {
                     lettings++;
                     if (isSet == false) {
                       component.set("v.firstLAcctId", a.Id);
                       component.set("v.firstLInvId", a.Subhire_Invitations__r[0].Id);
                       isSet = true;
                     }
                  }
                });
                component.set("v.hasLettings", lettings > 0);
                
                
            }   
        });
        
        $A.enqueueAction(action);
    },

    viewSingleHolidayHomePage: function(component, event, helper){
     
        var accountIdList = component.get("v.acctList");

      // set default record type value to attribute    
      for(var i = 0; i < accountIdList.length; i++){
         
        var accountId = component.get("v.acctList")[i].Id;
   
              var address = component.get("v.HHPageUrl") + accountId;

              var urlEvent = $A.get("e.force:navigateToURL");
                      urlEvent.setParams({
                      "url": address,
                      "isRedirect": false
              });
              urlEvent.fire();
      }

    },
    
    viewMultipleHolidayHomePage: function(component, event, helper){
        
        var address = component.get("v.multipleHHPageUrl");

        var urlEvent = $A.get("e.force:navigateToURL");
        	urlEvent.setParams({
                "url": address,
                "isRedirect": false
        });
        urlEvent.fire();
    },

    getRelatedHHList: function(component, event, helper){
        var action = component.get("c.getRelatedAccountsList");
            
            action.setCallback(this, function(actionResult) {
                
                var state = actionResult.getState();
                
                if (component.isValid() && state === "SUCCESS") {
                    
                    component.set("v.acctList", actionResult.getReturnValue());
                    
                    var acctListSize = component.get("v.acctList");

                }   
            });
            
            $A.enqueueAction(action);
    }
})