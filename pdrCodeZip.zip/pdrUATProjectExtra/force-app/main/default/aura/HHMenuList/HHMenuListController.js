({

    doInit: function(component, event, helper){
       helper.getAccountlist(component, event, helper);
        
      component.set("v.hasOffers", false);
        
        var action = component.get("c.displayAllMemberMessages");
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                var res = response.getReturnValue();
                var unread = res.filter(function(r) {
                  return r.Message_Viewed__c == false;
                }).length;
                if (unread > 0) {
                  component.set("v.unreadCount", unread);
                  console.log(component.get("v.unreadCount"));
                }
            }
        });
        $A.enqueueAction(action); 
        
        // check offers
        var action = component.get("c.getOffers");
    	action.setCallback(this, function(response) {
          console.log("has offers?", response.getReturnValue());
      	  if (response.getState() == "SUCCESS") {
        	component.set("v.hasOffers", response.getReturnValue().length > 0);    
      	  } else {
            console.log('error?', response.getError());
          }
    	});
    	$A.enqueueAction(action);
        
        
        var recordId = window.location.search.indexOf("?accountId=") == -1 ? "" : window.location.search.split("?accountId=")[1].split('&')[0];
        component.set("v.recordId", recordId);

        if (window.location.search.indexOf("&inviteId=") != -1){
            console.log('setting invite Id',window.location.search.split("&inviteId=")[1].split('&')[0]);
            component.set("v.inviteId", window.location.search.split("&inviteId=")[1].split('&')[0]);
        }

        
        var path = window.location.pathname;
        component.set("v.path", path);
        console.log(path);
        if (path == "/s/hh-profile-change-password-page" || path == "/s/hh-profile-update-my-details-page" || path == "/s/hh-profile-my-preferences-page") {
            component.set("v.isProfilePage", true);
        }
        if (path == "/s/hh-details-page") {
            component.set("v.isHHPage", true);  
        }
        if (path == "/s/hh-letting-schemes") {
            console.log("LS page");
            component.set("v.isLSPage", true);  
        }
        
       
        
    },

    updateMyDetails : function(component, event, helper){
            
        var communityUserId = $A.get("$SObjectType.CurrentUser.Id");
            component.set("v.userId", communityUserId);
            
        var address = component.get("v.profilePageUrl") + communityUserId;
      
        var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                    "url": address,
                    "isRedirect": false
            });
            urlEvent.fire();
    },

    navigateRecordPage: function(component, event, helper){
      
        helper.viewSingleHolidayHomePage(component, event, helper);
    },
    
    getRelatedAccounts : function(component, event, helper) {  
       helper.getRelatedHHList(component, event, helper);
    },
        
    closeHHList : function(component, event, helper) {
        component.set("v.viewHolidayHomeList", false);
    },
   
    showListItems: function(component, event, helper){
        component.set("v.displayListItems", true);
    },

    goToContactUsPage:function(component, event, helper){
        console.log('pageUrl ' + pageUrl);
        var pageUrl = component.get("v.contactUsUrl");
        var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": pageUrl
            });
        urlEvent.fire();
    }
})