({
    /**********************************************************************************************
    * @Author: Monali Nagpure
    * @Date: 24/07/2020          
    * @Description: Aura controller for Matching rule creator functionality
    * @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
    ************************************************************************************************/

    /**
    * Method Name : handleCloseModal
    * Parameters  : component, event
    * Description : Handles event from child LWC cmp and closes the modal
    * Created By  : Monali Nagpure
    * Created On  : 24/07/2020  
    **/
    handleCloseTab: function (component, event) {

        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function (response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({ tabId: focusedTabId });
            $A.get('e.force:refreshView').fire();
        })
            .catch(function (error) {
                console.log(error);
            });

    },
})