({
    hShowMessage : function(messageType, messageText) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "mode": "pester",
            "type": messageType,
            "title": "Payment",
            "message": messageText
        });
        toastEvent.fire();
    },
    hShowError : function() {
        var helper = this;
        helper.hShowMessage("error", "Something is wrong! Please refresh the page and try it again!");
    },
    hCloseWindow : function() {
        var closeWindow = $A.get("e.force:closeQuickAction");
        closeWindow.fire();
    },
    hRunEvent : function(component, key, type, data, componentContainer) {
        var newComponentEvent = component.getEvent("PaymentWindowEvent");
        newComponentEvent.setParams({
            "key": key,
            "type": type,
            "data": data,
            "componentContainer": componentContainer
        });
        newComponentEvent.fire();
    },
    hOpenWindow : function(component, windowName, data) {
        var helper = this;
        helper.hRunEvent(component, windowName, "openWindow", data, []);
    },
    hInsertWindow : function(component, windowName, componentContainer) {
        var helper = this;
        helper.hRunEvent(component, windowName, "insertComponent", {}, componentContainer);
    },
    hSetData : function(component, dataSetName, data) {
        var helper = this;
        helper.hRunEvent(component, dataSetName, "setData", data, []);
    },
    hGetErrorMessage : function(msg) {
        for (var i = 0; i < msg.Messages.length; i++) {
            if (msg.Messages[i].length == 3) {
                if (msg.Messages[i][1] == 'Error') {
                    console.log("ERROR MESSAGE: " + msg.Messages[i][2]);
                    return msg.Messages[i][0];
                }
            }
        }

        return '';
    },
    hShowMessages : function(msg) {
        var helper = this;
        for (var i = 0; i < msg.Messages.length; i++) {
            if (msg.Messages[i].length == 3) {
                helper.hShowMessage(msg.Messages[i][1].toLowerCase(), msg.Messages[i][0]);
                console.log(msg.Messages[i][1].toUpperCase() + " MESSAGE: " + msg.Messages[i][2]);
            }
        }
    },
    getErrorFromArray : function(err) {
        try {
            return err[0].pageErrors[0].message;
        } catch(e) { }
        return err;
    }
})