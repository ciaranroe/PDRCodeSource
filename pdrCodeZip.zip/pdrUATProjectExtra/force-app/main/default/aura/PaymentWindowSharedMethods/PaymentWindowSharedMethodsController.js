({
    showMessage : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        helper.hShowMessage(parameters.messageType, parameters.messageText);
    },
    showError : function(component, event, helper) {
        helper.hShowError();
    },
    closeWindow : function(component, event, helper) {
        helper.hCloseWindow();
    },
    getFullName : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        return (parameters.firstName == undefined || parameters.firstName == null || parameters.firstName == "" ? "" : parameters.firstName + " ") + (parameters.lastName == undefined || parameters.lastName == null ? "" : parameters.lastName);
    },
    openWindow : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        helper.hOpenWindow(component, parameters.windowName, parameters.windowData);
    },
    createComponent : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        if (parameters.componentName == null || parameters.componentName == undefined || parameters.componentName == "") {
            return;
        }

        $A.createComponent(
            "c:" + parameters.componentName,
            (parameters.componentParameters == null || parameters.componentParameters == undefined ? {} : parameters.componentParameters),
            function(newComponent, status, errorMessage) {
                if (status === "SUCCESS") {
                    helper.hInsertWindow(component, parameters.componentName, newComponent);
                }
                else if (status === "INCOMPLETE") {
                    helper.hShowError();
                    console.log("No response from server or client is offline.")
                }
                else if (status === "ERROR") {
                    helper.hShowError();
                    console.log("Error: " + errorMessage);
                }
            }
        );
    },
    getInitData : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.getCardholderInformations");
        action.setParams({ "accountId" : parameters.recordId });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                // var errMsg = helper.hGetErrorMessage(data.Msg);

                // if (errMsg != "") {
                //     helper.hShowMessage("error", errMsg);
                //     helper.hCloseWindow();
                // } else if (data.AllowPayment == undefined || data.AllowPayment == null || !data.AllowPayment) {
                //     helper.hShowMessage("error", "Payments can only be taken for contract accounts");
                //     helper.hCloseWindow();
                // } else if (data.AccountName == undefined || data.AccountName == null || data.AccountName == "" || data.Members == undefined || data.Members == null) {
                //     helper.hShowMessage("error", "Input data are not selected properly! Please refresh the page.");
                //     helper.hCloseWindow();
                // } else {
                    helper.hShowMessages(data.Msg);
                // }

                helper.hSetData(component, "cardholder", {
                    "AccountName": data.AccountName,
                    "Members": data.Members,
                    "Ledger": data.Ledger === 'RL' ? 'Rent' : 'Sales',
                    "Invoices" : data.Invoices, 
                    "Errors" : data.Errors
                });
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    getInvoices : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.getAvailableInvoices");
        action.setParams({ "accountId" : parameters.recordId, "memberId" : parameters.AccountId });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                var errMsg = helper.hGetErrorMessage(data.Msg);

                if (errMsg != "") {
                    helper.hShowMessage("error", errMsg);
                    helper.hCloseWindow();
                }

                helper.hShowMessages(data.Msg);

                helper.hSetData(component, "invoices", data.Invoices);
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    getTypeValues : function(component, event, helper) {
        var action = component.get("c.getTypePicklistValues");
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                if (data.length == 0) {
                    helper.hShowMessage("warning", "Connection issue! Program cannot load picklist values!");
                }
                helper.hSetData(component, "typePicklist", data);
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentAuthorization : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentAuthorization");
        action.setParams({ 
            "contractId" : parameters.contractId, 
            "memberId" : parameters.memberId,
            "totalAmount": parameters.totalAmount,
            "firstName": parameters.firstName,
            "lastName": parameters.lastName,
            "street": parameters.street,
            "city": parameters.city,
            "country": parameters.country,
            "postalCode": parameters.postalCode,
            "phone":parameters.phone,
            "email":parameters.email
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                helper.hRunEvent(component, "paymentAuthorization", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentAuthorization", "dmlStatus", { "Msg": { "Messages": [["Authorization could not be processed. Please try the payment later.", "Error", "Authorization could not be processed. Please try the payment later. Error: " + helper.getErrorFromArray(a.getError())]]} }, []);
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentCreate : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentCreate");
        action.setParams({ 
            "num" : parameters.num,
            "numberOfPayments" : parameters.numberOfPayments,
            "paymentTransactionId" : parameters.paymentTransactionId, 
            "amount" : parameters.amount,
            "invoiceType": parameters.invoiceType,
            "invoiceId": parameters.invoiceId
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                helper.hRunEvent(component, "paymentCreate", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentCreate", "dmlStatus", { "Msg": { "Messages": [["Payment record could not be initialized in the Salesforce. Please try the payment later.", "Error", "Payment record could not be initialized in the Salesforce. Error: " + helper.getErrorFromArray(a.getError())]]} }, []);
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentSession : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentSession");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId,
            "firstName": parameters.firstName,
            "lastName": parameters.lastName,
            "street": parameters.street,
            "city": parameters.city,
            "country": parameters.country,
            "postalCode": parameters.postalCode,
            "phone":parameters.phone,
            "email":parameters.email
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                helper.hRunEvent(component, "paymentSession", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentSession", "dmlStatus", { "Msg": { "Messages": [["Program could not retrieve payment session. Please try the payment later.", "Error", "Program could not retrieve payment session. Please try the payment later. Error: " + helper.getErrorFromArray(a.getError())]]} }, []);
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentStatus : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentStatus");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                helper.hRunEvent(component, "paymentStatus", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentStatus", "dmlStatus", { "Msg": { "Messages": [["Status of payment is unknown. Please check the payment.", "Error", "Status of payment is unknown. Please check the payment. Error: " + helper.getErrorFromArray(a.getError())]]} }, []);
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentAllocation : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        console.log('DO PAYMENT ALLOCATION',parameters.paymentLines);
        var paymentLines = parameters.paymentLines;
        console.log('paymentLines',paymentLines.length,paymentLines);

        if (paymentLines.length){
            paymentLines.forEach(function(line){
                console.log('line',line);
            });
        }

        var action = component.get("c.paymentAllocation");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId,
            "paymentLines" : parameters.paymentLines
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                helper.hRunEvent(component, "paymentAllocation", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentAllocation", "dmlStatus", { "Msg": { "Messages": [["Status of payment is unknown. Please check the payment.", "Error", "Status of payment is unknown. Please check the payment. Error: " + helper.getErrorFromArray(a.getError())]]} }, []);
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doShowLogWindow : function(component, event, helper) {
        var action = component.get("c.showLogWindow");
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                helper.hRunEvent(component, "showLogWindow", "dmlStatus", { "ShowLog":a.getReturnValue() }, []);
            } else {
                helper.hRunEvent(component, "showLogWindow", "dmlStatus", { "ShowLog":false }, []);
            }
        });
        $A.enqueueAction(action);
    }
})
/* BACKUP
({
    showMessage : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        helper.hShowMessage(parameters.messageType, parameters.messageText);
    },
    showError : function(component, event, helper) {
        helper.hShowError();
    },
    closeWindow : function(component, event, helper) {
        helper.hCloseWindow();
    },
    getFullName : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        return (parameters.firstName == undefined || parameters.firstName == null || parameters.firstName == "" ? "" : parameters.firstName + " ") + (parameters.lastName == undefined || parameters.lastName == null ? "" : parameters.lastName);
    },
    openWindow : function(component, event, helper) {
        var parameters = event.getParam("arguments");
        helper.hOpenWindow(component, parameters.windowName, parameters.windowData);
    },
    createComponent : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        if (parameters.componentName == null || parameters.componentName == undefined || parameters.componentName == "") {
            return;
        }

        $A.createComponent(
            "c:" + parameters.componentName,
            (parameters.componentParameters == null || parameters.componentParameters == undefined ? {} : parameters.componentParameters),
            function(newComponent, status, errorMessage) {
                if (status === "SUCCESS") {
                    helper.hInsertWindow(component, parameters.componentName, newComponent);
                }
                else if (status === "INCOMPLETE") {
                    helper.hShowError();
                    console.log("No response from server or client is offline.")
                }
                else if (status === "ERROR") {
                    helper.hShowError();
                    console.log("Error: " + errorMessage);
                }
            }
        );
    },
    getInitData : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.getCardholderInformations");
        action.setParams({ "accountId" : parameters.recordId });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                if (data.AllowPayment == undefined || data.AllowPayment == null || !data.AllowPayment) {
                    helper.hShowMessage("error", "Payment is allowed only for Contract account.");
                    helper.hCloseWindow();
                } else if (data.AccountName == undefined || data.AccountName == null || data.AccountName == "" || data.Members == undefined || data.Members == null) {
                    helper.hShowMessage("error", "Input data are not selected properly! Please refresh the page.");
                    helper.hCloseWindow();
                } else if (data.Members.length == 0) {
                    helper.hShowMessage("warning", "The Contract Account does not contain any Member(s)! Please fill out the name and address.");
                }
                helper.hSetData(component, "cardholder", {
                    "AccountName": data.AccountName,
                    "Members": data.Members
                });
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    getInvoices : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.getAvailableInvoices");
        action.setParams({ "accountId" : parameters.recordId, "memberId" : parameters.AccountId });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                if (data.length == 0) {
                    helper.hShowMessage("warning", "Does not exist any invoice which is assigned to the current member or to the contract.");
                }
                helper.hSetData(component, "invoices", data);
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    getTypeValues : function(component, event, helper) {
        var action = component.get("c.getTypePicklistValues");
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = JSON.parse(a.getReturnValue());
                if (data.length == 0) {
                    helper.hShowMessage("warning", "Connection issue! Program cannot load picklist values!");
                }
                helper.hSetData(component, "typePicklist", data);
            } else {
                helper.hShowError();
                helper.hCloseWindow();
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentAuthorization : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentAuthorization");
        action.setParams({ 
            "contractId" : parameters.contractId, 
            "memberId" : parameters.memberId,
            "totalAmount": parameters.totalAmount,
            "firstName": parameters.firstName,
            "lastName": parameters.lastName,
            "street": parameters.street,
            "city": parameters.city,
            "country": parameters.country,
            "postalCode": parameters.postalCode,
            "phone":parameters.phone,
            "email":parameters.email
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = a.getReturnValue();
                helper.hRunEvent(component, "paymentAuthorization", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentAuthorization", "dmlStatus", { "ErrorMessage":a.getError() }, []);
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentCreate : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentCreate");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId, 
            "amount" : parameters.amount,
            "invoiceType": parameters.invoiceType
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = a.getReturnValue();
                helper.hRunEvent(component, "paymentCreate", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentCreate", "dmlStatus", { "ErrorMessage":a.getError() }, []);
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentSession : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentSession");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = a.getReturnValue();
                helper.hRunEvent(component, "paymentSession", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentSession", "dmlStatus", { "ErrorMessage":a.getError() }, []);
            }
        });
        $A.enqueueAction(action);
    },
    doPaymentStatus : function(component, event, helper) {
        var parameters = event.getParam("arguments");

        var action = component.get("c.paymentStatus");
        action.setParams({ 
            "paymentTransactionId" : parameters.paymentTransactionId
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                var data = a.getReturnValue();
                helper.hRunEvent(component, "paymentStatus", "dmlStatus", data, []);
            } else {
                helper.hRunEvent(component, "paymentStatus", "dmlStatus", { "ErrorMessage":a.getError() }, []);
            }
        });
        $A.enqueueAction(action);
    },
    doIsUserSysAdmin : function(component, event, helper) {
        var action = component.get("c.isUserSA");
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS") {
                helper.hRunEvent(component, "isUserSysAdmin", "dmlStatus", { "ErrorMessage":"OK", "SysAdmin":a.getReturnValue() }, []);
            } else {
                helper.hRunEvent(component, "isUserSysAdmin", "dmlStatus", { "ErrorMessage":a.getError(), "SysAdmin":false }, []);
            }
        });
        $A.enqueueAction(action);
    } 
}) */