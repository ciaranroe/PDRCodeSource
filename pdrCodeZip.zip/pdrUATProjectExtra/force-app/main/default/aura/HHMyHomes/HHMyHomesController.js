({
    
  // get data for the current account
  getData: function($C, $E, $H) {
      
    var accountId = window.location.search.split('?accountId=')[1];
    var recordId = accountId != undefined ? accountId.split('&')[0] : null;
      
      
    var action = $C.get("c.getAcctDetails");
    action.setParams({ recordId: recordId });
    action.setCallback(this, function (response) {
      var state = response.getState();   
      if (state === "SUCCESS") {        
        console.log("?", response.getReturnValue());
        var data = response.getReturnValue();
        $C.set('v.valid', data.length > 0);
        $C.set('v.recordData', data[0]);
        $C.set('v.loaded', true);
      } else {
        console.error(response.getError());
        $C.set('v.valid', false);
        $C.set('v.loaded', true);
      }
    });
    $H.checkHash($C, $H);
    $A.enqueueAction(action); 
  },
    
  // set tab, loading component
  setTab: function($C, $E, $H) {
    var index = $E.currentTarget.getAttribute("data-index");
    $C.set('v.tab', Number(index));
    window.location.hash = (Number(index)+1) + "";
  }
    
})