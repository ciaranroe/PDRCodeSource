({
    
  // handle hash changes for tab
  checkHash: function($C, $H) {
    var hash = window.location.hash;
    var params = '';
      


    // if (){
    if (hash.length > 2){
      params = hash.substring(2,hash.length -1).replace('?','&');
      hash = hash.substring(0,2);
    }

    // console.log('after check hash is ',hash);
    // console.log('*** additional params to add back after check hash is ',params);

    var current_index = ($C.get("v.tab") + 1) + "";
    if (hash == "") {
      console.log("[HHMyHomes.checkHash] Hash Default");
      window.location.hash = "1";
    }
    var current_hash = hash.replace('#', "");
    if (Number(current_index) != Number(current_hash)) {
      console.log(window.location.hash, Number(current_index), Number(current_hash))
      var nhash = Number(current_hash)-1;
      if ($C.get('v.tab') != nhash) {
        console.log("[HHMyHomes.checkHash] Change to tab index", nhash);
        $C.set("v.tab", nhash);
      }
    }
    
    if (params){
        
        
      var url = window.location.origin + window.location.pathname + window.location.search + params + hash;
        
      console.log('[HHMyHomes.checkHash] Page reload with new params!', url);
      var urlEvent = $A.get("e.force:navigateToURL");
      urlEvent.setParams({ "url": url });
      urlEvent.fire();

      // console.log('PARAMS TO ADD');
      // window.location.search = window.location.search.replace('#' + hash,'') + params;
      // window.location.hash = hash;
    }
    
    setTimeout(function() {
      $H.checkHash($C, $H);    
    }, 100);
  }
    
})