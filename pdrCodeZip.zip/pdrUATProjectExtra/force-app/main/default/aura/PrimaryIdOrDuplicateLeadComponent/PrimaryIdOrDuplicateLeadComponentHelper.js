({
  // Client-side function that invokes the subscribe method on the
  // empApi component.
  subscribe: function(component, event, helper) {
    // Get the empApi component.
    const empApi = component.find("empApi");
    // Get the channel from the attribute.
    const channel = component.get("v.channel");
    // Subscription option to get only new events.
    const replayId = -1;
    // Callback function to be passed in the subscribe call.
    // After an event is received, this callback prints the event
      const callback = function(message) {
      console.log("Event Received : " + JSON.stringify(message));
      helper.onReceiveNotification(component, message);
    };
    // Subscribe to the channel and save the returned subscription object.
    empApi.subscribe(channel, replayId, $A.getCallback(callback)).then(
      $A.getCallback(function(newSubscription) {
        console.log("Subscribed to channel " + channel);
        component.set("v.subscription", newSubscription);
      })
    );
  },

  // Client-side function that displays the platform event message
  onReceiveNotification: function(component, message) {
    // Extract notification from platform event 

    var Id = JSON.parse(message.data.payload.Salesforce_Id__c);
    console.log("onReceiveNotification triggered. Id is:" + Id);
    if (Id) {
       var recordId = component.get("v.recordId");

           	if (recordId == Id) {
              console.log("Id found.");
              $A.get("e.force:refreshView").fire();
            }
    }
  }
});