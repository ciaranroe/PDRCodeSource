({
    init : function(component, event, helper) {
        if (component.get("v.LastName") == undefined || component.get("v.LastName") == null || component.get("v.LastName") == "") {
            component.find("sharedMethods").getInitData(component.get("v.recordId"));
        }

        var invoices = component.get('v.Invoices');	
        var ledger = component.get('v.Ledger');	
        
        //var paymentOptions = [
        //    {"label": "Invoices (" + invoices + ")", "value": "Invoices"},
        //    {"label": "Payment on Account", "value": "PaymentAccount"}
        //];
        //component.set("v.paymentOptions", paymentOptions);        
    },
    loadInitData : function(component, event, helper) {
        var dataSetName = event.getParam("key");
        var type = event.getParam("type");
        var data = event.getParam("data");

        console.log('ON LOAD INIT DATA',JSON.stringify(data));
        if (type === "setData" && dataSetName === "cardholder") {
            component.set("v.AccountName", data.AccountName);
            component.set("v.Members", data.Members);
            component.set("v.Invoices",data.Invoices);
            component.set("v.Ledger",data.Ledger);
            component.set("v.Errors",data.Errors);

            if (data.Errors && data.Errors.length){

            } else if (data.Members.length > 0) {
                component.find("Member").set("v.value", data.Members[0].AccountId);
                component.set("v.AccountId", data.Members[0].AccountId);
            } else {
                console.log('TRY THIS');
                component.set("v.thirdPartyPayee", true);
                component.find("Member").set("v.disabled", true);
                component.find("ThirdPartyPayee").set("v.disabled", true);
                console.log('FINISH TRY THIS');
            }
            
            var paymentOptions = [];
            if (data.Invoices > 0){
                paymentOptions.push({"label": data.Ledger + " Ledger Invoices (" + data.Invoices + " with an outstanding balance)", "value": "Invoices"});
            }
            paymentOptions.push({"label": "Payment on Account " + data.Ledger + " Ledger", "value": "PaymentAccount"});
            component.set("v.paymentOptions", paymentOptions); 
            
        }
    },
    setFieldsForAddress : function(component, event, helper) {
        var thirdPartyPayee = component.get("v.thirdPartyPayee");
        
        if (thirdPartyPayee) {
            component.set("v.AccountId", "");
        } else {
            var accountId = component.find("Member").get("v.value");
            if (accountId != undefined && accountId != null && accountId != "") {
                component.set("v.AccountId", accountId);
            }
        }
    },
    loadMemberInfo : function(component, event, helper) {
        component.set("v.FirstName", "");
        component.set("v.LastName", "");
        component.set("v.Street", "");
        component.set("v.City", "");
        component.set("v.Country", "");
        component.set("v.PostalCode", "");
        component.set("v.Phone", "");
        component.set("v.Email", "");

        var accountId = component.get("v.AccountId");
        if (accountId == "") { return; }

        var members = component.get("v.Members");
        for (var i = 0; i < members.length; i++) {
            if (members[i].AccountId == accountId) {
                component.set("v.FirstName", members[i].FirstName);
                component.set("v.LastName", members[i].LastName);
                component.set("v.Street", members[i].Street);
                component.set("v.City", members[i].City);
                component.set("v.Country", members[i].Country);
                component.set("v.PostalCode", members[i].PostalCode);
                component.set("v.Phone", members[i].Phone);
                component.set("v.Email", members[i].Email);
            }
        }
    },
    setMember : function(component, event, helper) {
        var accountId = event.getSource().get("v.value");
        component.set("v.AccountId", (accountId == undefined || accountId == null ? "" : accountId));
    },
    closeWindow : function(component, event, helper) {
        component.find("sharedMethods").closeWindow();
    },
    nextWindow : function(component, event, helper) {
        if (component.get("v.FirstName") != undefined && component.get("v.FirstName") != null && component.get("v.FirstName") != "" &&
            component.get("v.LastName") != undefined && component.get("v.LastName") != null && component.get("v.LastName") != "" &&
            component.get("v.Street") != undefined && component.get("v.Street") != null && component.get("v.Street") != "" &&
            component.get("v.City") != undefined && component.get("v.City") != null && component.get("v.City") != "" &&
            component.get("v.Country") != undefined && component.get("v.Country") != null && component.get("v.Country") != "" &&
            component.get("v.PostalCode") != undefined && component.get("v.PostalCode") != null && component.get("v.PostalCode") != "" &&
            component.get("v.Phone") != undefined && component.get("v.Phone") != null && component.get("v.Phone") != "" &&
            component.get("v.Email") != undefined && component.get("v.Email") != null && component.get("v.Email") != "") {

                
            var eventParameters = {
                "recordId":component.get("v.recordId"),
                "AccountName":component.get("v.AccountName"),
                "Members":component.get("v.Members"),
                "AccountId":component.get("v.AccountId"),
                "FirstName":component.get("v.FirstName"),
                "LastName":component.get("v.LastName"),
                "Street":component.get("v.Street"),
                "City":component.get("v.City"),
                "Country":component.get("v.Country"),
                "PostalCode":component.get("v.PostalCode"),
                "Phone":component.get("v.Phone"),
                "Email":component.get("v.Email"),
                "thirdPartyPayee":component.get("v.thirdPartyPayee")
            };
            if (component.get("v.paymentOption") === "Invoices") {
                component.find("sharedMethods").openWindow("PaymentInvoices", eventParameters);  
            } else if (component.get("v.paymentOption") === "PaymentAccount") {
                component.find("sharedMethods").openWindow("PaymentOnAccount", eventParameters);
            }            
        } else {
            component.find("sharedMethods").showMessage("warning", "Name and address cannot be empty!");
        }
    }
})