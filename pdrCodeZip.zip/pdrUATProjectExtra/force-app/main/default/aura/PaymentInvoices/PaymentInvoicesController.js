({
    init : function(component, event, helper) {
        component.set("v.MemberName", component.find("sharedMethods").getFullName(component.get("v.FirstName"), component.get("v.LastName"))); 

        var availableInvoicesColumnsDefinition = [{
                label: "Select", 
                type: "button", 
                initialWidth: 100, 
                typeAttributes: { 
                    label: "Add",
                    title: "Add",
                    name: "addInvoice",
                    iconName: "utility:add"
                } 
            }, {
                label: "Invoice",
                fieldName: "Name",
                type: "text",
                sortable: false,
                hideDefaultActions: true
            }, {
                label: "Date Due",
                fieldName: "DueDate",
                type: "date",
                sortable: false,
                hideDefaultActions: true
            }, {
                label: "Type",
                fieldName: "InvoiceType",
                type: "text",
                sortable: false,
                hideDefaultActions: true
            }, {
                label: "Oustanding",
                fieldName: "Balance",
                type: "decimal",
                sortable: false,
                hideDefaultActions: true,
                type: 'currency',
                typeAttributes: { currencyCode: 'GBP'}
            }, {
                label: "Amount",
                fieldName: "Amount",
                type: "decimal",
                sortable: false,
                hideDefaultActions: true,
                type: 'currency',
                typeAttributes: { currencyCode: 'GBP'}
            }
        ];
        component.set("v.availableInvoicesColumnsDefinition", availableInvoicesColumnsDefinition);

        var selectedInvoicesColumnsDefinition = [{
                label: "Remove", 
                type: "button", 
                initialWidth: 100, 
                typeAttributes: { 
                    label: "Remove",
                    title: "Remove",
                    name: "removeInvoice",
                    iconName: "utility:close"
                } 
            }, {
                label: "Invoice",
                fieldName: "Name",
                type: "text",
                sortable: false,
                hideDefaultActions: true
            }, {
                label: "Type",
                fieldName: "InvoiceType",
                type: "text",
                sortable: false,
                hideDefaultActions: true
            }, {
                label: "Oustanding",
                fieldName: "Balance",
                type: "text",
                sortable: false,
                hideDefaultActions: true,
                type: 'currency',
                typeAttributes: { currencyCode: 'GBP'}
            }, {
                label: "Action", 
                type: "button", 
                initialWidth: 60, 
                typeAttributes: { 
                    label: {fieldName: "lockButtonLabel"},
                    title: {fieldName: "lockButtonLabel"},
                    name: "setFullAmount",
                    //iconName: {fieldName: "lockButton"}
                }
            }, {
                label: "Pay Amount",
                fieldName: "pay_amount",
                type: "decimal",
                sortable: false,
                hideDefaultActions: true,
                editable: true,
                type: 'currency',
                typeAttributes: { currencyCode: 'GBP'}
            }
        ];
        component.set("v.selectedInvoicesColumnsDefinition", selectedInvoicesColumnsDefinition);

        component.set("v.availableInvoicesData", []);
        component.set("v.selectedInvoicesData", []);

        component.find("sharedMethods").getInvoices(component.get("v.recordId"), component.get("v.AccountId"));
    },
    loadInvoices : function(component, event, helper) {
        var dataSetName = event.getParam("key");
        var type = event.getParam("type");
        var data = event.getParam("data");

        if (type === "setData" && dataSetName === "invoices") {
            component.set("v.availableInvoicesData", data);
        }
    },
    closeWindow : function(component, event, helper) {
        component.find("sharedMethods").closeWindow();
    },
    previousWindow : function(component, event, helper) {
        var eventParameters = {
            "recordId":component.get("v.recordId"),
            "AccountName":component.get("v.AccountName"),
            "Members":component.get("v.Members"),
            "AccountId":component.get("v.AccountId"),
            "FirstName":component.get("v.FirstName"),
            "LastName":component.get("v.LastName"),
            "Street":component.get("v.Street"),
            "City":component.get("v.City"),
            "Country":component.get("v.Country"),
            "PostalCode":component.get("v.PostalCode"),
            "Phone":component.get("v.Phone"),
            "Email":component.get("v.Email"),
            "thirdPartyPayee":component.get("v.thirdPartyPayee"),
            "paymentOption":"Invoices"
        };
        component.find("sharedMethods").openWindow("PaymentCardholderInformation", eventParameters);
    },
    nextWindow : function(component, event, helper) {
        var selectedInvoicesData = component.get("v.selectedInvoicesData");
        var paymentLines = [];

        for (var i = 0; i < selectedInvoicesData.length; i++) {
            paymentLines.push({
                "invoiceName":selectedInvoicesData[i].Name,
                "invoiceType":"",
                "amount": parseFloat(selectedInvoicesData[i].pay_amount),
                "invoiceId" : selectedInvoicesData[i].InvoiceId
            });
        }

        var paymentData = {
            "contractId": component.get("v.recordId"),
            "memberId": component.get("v.AccountId"),
            "contractName": component.get("v.AccountName"),
            "totalAmount": parseFloat(component.get("v.TotalPayment")),
            "firstName":component.get("v.FirstName"),
            "lastName":component.get("v.LastName"),
            "street":component.get("v.Street"),
            "city":component.get("v.City"),
            "country":component.get("v.Country"),
            "postalCode":component.get("v.PostalCode"),
            "phone":component.get("v.Phone"),
            "email":component.get("v.Email"),
            "paymentLines":paymentLines
        };

        var eventParameters = { "paymentData": paymentData };
        component.find("sharedMethods").openWindow("PaymentRunStatusWindow", eventParameters);
    },
    invoiceAction : function(component, event, helper) {
        var actionName = event.getParam("action").name;
        var invoiceNumber = event.getParam("row").Name;

        var availableInvoicesData = component.get("v.availableInvoicesData");
        var selectedInvoicesData = component.get("v.selectedInvoicesData");
        var selectedRowNumber = -1;

        if (actionName == "setFullAmount") {
            for (var i = 0; i < selectedInvoicesData.length; i++) {
                if (selectedInvoicesData[i].Name == invoiceNumber) {
                    if (selectedInvoicesData[i].lockButtonLabel == "Full") {
                        selectedInvoicesData[i].pay_amount = parseFloat(selectedInvoicesData[i].Balance);
                        selectedInvoicesData[i].lockButtonLabel = "Reset";
                        //selectedInvoicesData[i].lockButton = "utility:lock";
                        selectedInvoicesData[i].editAmount = false;
                    } else {
                        selectedInvoicesData[i].pay_amount = 0;
                        selectedInvoicesData[i].lockButtonLabel = "Full";
                        //selectedInvoicesData[i].lockButton = "utility:unlock";
                        selectedInvoicesData[i].editAmount = true;
                    }
                    break;
                }
            }
        } else if (actionName == "addInvoice") {
            for (var i = 0; i < availableInvoicesData.length; i++) {
                if (availableInvoicesData[i].Name == invoiceNumber) {
                    selectedRowNumber = i;
                    break;
                }
            }

            if (selectedRowNumber == -1) { return; }

            selectedInvoicesData.push({
                Name: availableInvoicesData[selectedRowNumber].Name,
                DueDate: availableInvoicesData[selectedRowNumber].DueDate,
                InvoiceType: availableInvoicesData[selectedRowNumber].InvoiceType,
                Balance: availableInvoicesData[selectedRowNumber].Balance,
                Amount: availableInvoicesData[selectedRowNumber].Amount,
                InvoiceId : availableInvoicesData[selectedRowNumber].InvoiceId,
                lockButton: "utility:unlock",
                lockButtonLabel: "Full",
                editAmount: true,
                pay_amount: 0
            });

            availableInvoicesData.splice(selectedRowNumber, 1);
        } else if (actionName == "removeInvoice") {
            for (var i = 0; i < selectedInvoicesData.length; i++) {
                if (selectedInvoicesData[i].Name == invoiceNumber) {
                    selectedRowNumber = i;
                    break;
                }
            }

            if (selectedRowNumber == -1) { return; }

            availableInvoicesData.push({
                Name: selectedInvoicesData[selectedRowNumber].Name,
                DueDate: selectedInvoicesData[selectedRowNumber].DueDate,
                InvoiceType: selectedInvoicesData[selectedRowNumber].InvoiceType,
                Balance: selectedInvoicesData[selectedRowNumber].Balance,
                Amount: selectedInvoicesData[selectedRowNumber].Amount,
                InvoiceId: selectedInvoicesData[selectedRowNumber].InvoiceId
            });

            selectedInvoicesData.splice(selectedRowNumber, 1);
        } else { return; }

        component.set("v.selectedInvoicesData", selectedInvoicesData);
        component.set("v.availableInvoicesData", availableInvoicesData);

        var totalPayment = 0;
        for (var i = 0; i < selectedInvoicesData.length; i++) {
            totalPayment += parseFloat(selectedInvoicesData[i].pay_amount);
        }

        if (totalPayment > 0) {
            component.find("startPaymentButton").set("v.disabled", false);
        } else {
            component.find("startPaymentButton").set("v.disabled", true);
        }

        component.set("v.TotalPayment", totalPayment);
    },
    changedCell : function(component, event, helper) {
        var selectedInvoicesData = component.get("v.selectedInvoicesData");
        for (var j = 0; j < event.getParams("draftValues").draftValues.length; j++) {
            for (var i = 0; i < selectedInvoicesData.length; i++) {
                if (selectedInvoicesData[i].Name == event.getParams("draftValues").draftValues[j].Name) {
                    selectedInvoicesData[i].pay_amount = parseFloat(event.getParams("draftValues").draftValues[j].pay_amount);
                    if (selectedInvoicesData[i].pay_amount >= selectedInvoicesData[i].Balance) {
                        selectedInvoicesData[i].pay_amount = parseFloat(selectedInvoicesData[i].Balance);
                        //selectedInvoicesData[i].lockButton = "utility:lock";
                        selectedInvoicesData[i].lockButtonLabel = "Reset";
                    } else {
                        selectedInvoicesData[i].lockButton = "utility:unlock";
                        selectedInvoicesData[i].lockButtonLabel = "Full";
                        if (selectedInvoicesData[i].pay_amount < 0) {
                            selectedInvoicesData[i].pay_amount = 0;
                        }
                    }
                }
            }
        }

        component.set("v.selectedInvoicesData", selectedInvoicesData);
        component.find("selectedInvoiceDataTable").set("v.draftValues", null);

        var totalPayment = 0;
        for (var i = 0; i < selectedInvoicesData.length; i++) {
            totalPayment += parseFloat(selectedInvoicesData[i].pay_amount);
        }

        if (totalPayment > 0) {
            component.find("startPaymentButton").set("v.disabled", false);
        } else {
            component.find("startPaymentButton").set("v.disabled", true);
        }

        component.set("v.TotalPayment", totalPayment);
    }
})