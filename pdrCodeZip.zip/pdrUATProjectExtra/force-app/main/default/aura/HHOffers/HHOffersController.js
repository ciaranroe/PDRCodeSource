({
  doInit: function($C, $E, $H) {
        
    var action = $C.get("c.getOffers");
    action.setCallback(this, function(response) {
      console.log(response);
      if (response.getState() == "SUCCESS") {
        $C.set("v.offers", response.getReturnValue());    
      }
    });
    $A.enqueueAction(action);
      
  }
})