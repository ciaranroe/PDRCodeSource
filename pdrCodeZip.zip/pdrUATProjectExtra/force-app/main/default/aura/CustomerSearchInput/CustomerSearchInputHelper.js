({
  searchButton: function(component, event, helper) {
    let lastName = component.get("v.lastName");
    let email = component.get("v.email");
    let postcode = component.get("v.postcode");
    let phone = component.get("v.phone");
    let mobile = component.get("v.mobile");

   if (lastName && (email || phone || mobile || email || postcode)) {
      component.set("v.isSearchButtonActive", false);
   	 } 
    else {
      component.set("v.isSearchButtonActive", true);
    }
  }
});