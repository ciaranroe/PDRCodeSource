({
  searchRecords: function(component, event, helper) {
    var params = {
      firstName: component.get("v.firstName"),
      lastName: component.get("v.lastName"),
      email: component.get("v.email"),
      postcode: component.get("v.postcode"),
      phone: component.get("v.phone"),
      mobile: component.get("v.mobile")
    };
     component.set("v.params", JSON.stringify(params));
     component.set("v.title", 'Lead Results');
      
     component.set("v.divHeight", '5');
     var cmpTarget = component.find('leadSearchHideUnhide');
     $A.util.removeClass(cmpTarget, 'slds-visible');
     $A.util.addClass(cmpTarget, 'slds-hidden');
     var cardButton = component.find("cardButton");
     cardButton.set("v.iconName", "utility:up");
  },
    checkSearchButton: function(component, event, helper) {
        helper.searchButton(component, event, helper);
    },
    hideUnhideSearch: function(component, event, helper) {
        var currentButton = event.getSource(); 
        var iconName = currentButton.get('v.iconName');
	  
        if(iconName=='utility:up')
        {
            currentButton.set("v.iconName", "utility:down");
            component.set("v.divHeight", '400');
    		var cmpTarget = component.find('leadSearchHideUnhide');
    		$A.util.removeClass(cmpTarget, 'slds-hidden');
    		$A.util.addClass(cmpTarget, 'slds-visible');             
        }
        else
        {
            currentButton.set("v.iconName", "utility:up");
            component.set("v.divHeight", '5');
    		var cmpTarget = component.find('leadSearchHideUnhide');
    		$A.util.removeClass(cmpTarget, 'slds-visible');
    		$A.util.addClass(cmpTarget, 'slds-hidden');   
        }
    
    }
});