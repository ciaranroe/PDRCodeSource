({
    
    getDefaultCurrencySymbolH: function(component, event, helper){
        var action = component.get("c.getOrgCurrencySymbol");        
        action.setCallback(this, function (response) {            
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result = response.getReturnValue();     
                component.set('v.orgCurrencySymbol', result);
            }
        });
        $A.enqueueAction(action);
    },    
    
    parsePageUrlParameterH: function(component, event, helper){
        console.log('[h:parsePageUrlParameter] Start');
        
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        console.log('[h:parsePageUrlParameter] Page URL:', sPageURL);
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var referrerURL = document.referrer;
        var invoiceIds = [];
        var verifoneTransactionId;
        var i; 
        
        console.log('[h:parsePageUrlParameter] URL Variables: ', sURLVariables);
        console.log('[h:parsePageUrlParameter] Referrer URL: ', referrerURL);
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');             
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            } else if (sParameterName[0] === 'invoiceIds'){              
                    invoiceIds = sParameterName[1];               
            } else if (sParameterName[0] ===  'transaction_id'){                            
                     verifoneTransactionId = sParameterName[1];                     
            }
        }        
        if (referrerURL.includes('verifone.cloud') && !verifoneTransactionId){ 
            // console.log('WHEN VERIFONE ID NOT FOUND',decodeURIComponent(window.location.search.substring(1)));
            
        }
        else {            
            if(invoiceIds && verifoneTransactionId){       
                
                
                component.set('v.showButton', false);
                component.set('v.paidInvoiceIds',invoiceIds);                 
                component.set('v.verifoneTransactionId',verifoneTransactionId);
                
                console.log('[h:parsePageUrlParameter] Invoice IDs + Transation Id Present!', invoiceIds, verifoneTransactionId);
                
                component.set('v.paymentSuccess',true); 
                setTimeout(function() {
                  component.set('v.showButton', true);
                }, 3000);
                
				//if (window.location.href.substr(-2) !== "?r") {
                //    console.log('[h:parsePageUrlParameter] URL does not contain ?r, redirecting?');
        		//	window.location = window.location.href + "?r";
    			//}
				//this.gettransactionDetails(component, event, helper);
                /*var toastEvent = $A.get("e.force:showToast");                
				toastEvent.setParams({
    				title: "Success!",
    				message: 'Thank you for your payment. Your transaction reference is ' + verifoneTransactionId,
    				type: "success",
                    mode: 'sticky'
				});
				toastEvent.fire(); */ 
                				
            }         
            
            console.log('[h:parsePageUrlParameter] Loading Outstanding Invoice');   
            this.loadOutstandingInvoiceH(component, event, helper);
            console.log('[h:parsePageUrlParameter] Payment Success', component.get('v.paymentSuccess'));
            if(component.get('v.paymentSuccess') === true){ 
            	console.log('[h:parsePageUrlParameter] Getting Checkout Details');               
				this.getCheckoutDetailsH(component, event, helper);
                
		    }				
        }
        
    },
    getCheckoutDetailsH: function(component, event, helper){
        console.log('[h:getCheckoutDetails] Start', new Date().toISOString());
        
        var accountId = component.get('v.accountId');       
        var PinvoiceIds = component.get('v.paidInvoiceIds');
		var chekId =  sessionStorage.getItem('ScheckoutId'); 
        console.log('[h:getCheckoutDetails] Stored ScheckoutId is: ', chekId);     
        console.log('[h:getCheckoutDetails] Paid Invoice Ids: ', component.get('v.paidInvoiceIds'));    
        console.log('[h:getCheckoutDetails] Account Id: ', component.get('v.accountId'));    

        if (chekId != null){
            
            console.log("[h:getCheckoutDetails] Have checkout id stored lets go!", chekId)
            var accountId = component.get('v.accountId');

            var action = component.get("c.Processtransactionpayments");              
            var params = {
                "checkoutId": chekId, 
                "accountId": accountId,            
                "selectedInvcId": [component.get('v.paidInvoiceIds').toString()],
                "personContactVal": null       		
            };
            console.log('[h:getCheckoutDetails] Process Transation Params:', params);
            action.setParams(params);        
            action.setCallback(this, function (response) {            
                var state = response.getState();
                if (state === "SUCCESS") {                
                    console.log('[h:getCheckoutDetails] Process Succeeded');
                } else if (state === "ERROR") {
                    var errors = response.getError();
                    console.error('[h:getCheckoutDetails] Process Failed', errors);
                }
            });
            $A.enqueueAction(action); 

        }

        // var action = component.get("c.Processtransactionpayments");              
        // var params = {
		// 	"checkoutId": chekId, 
        //     "accountId": component.get('v.accountId'),            
        //     "selectedInvcId": component.get('v.paidInvoiceIds').toString()           
        //     //"amountVal": component.get("v.amountToPay")			
        // };
        // console.log('params',params);
        // action.setParams(params);        
        // action.setCallback(this, function (response) {            
        //     var state = response.getState();
        //     if (state === "SUCCESS") {                
        //         console.log('SUCESS');
        //     } else if (state === "ERROR") {
        //         var errors = response.getError();
        //         console.error(errors);
        //     }
        // });
        // $A.enqueueAction(action); 

	},		
    getAcctDetailsH: function(component, event, helper){
        var action = component.get("c.getAcctDetails");
        action.setParams({recordId:component.get("v.accountId")});        
        action.setCallback(this, function (response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                component.set('v.acctList', records);
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error('[h:getAcctDetails] Get Details Failed', errors);
            }
        });
        $A.enqueueAction(action);         
    },
    
    getRelatedAccountListH: function(component, event, helper){
        var action = component.get("c.getAccountHolderList");
        action.setParams({accountId:component.get("v.accountId")});
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                component.set('v.relatedAcctHolder', records);   
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error('[h:getRelatedAccountList] Get Related Failed', errors);
            }
        });
        $A.enqueueAction(action); 
    },    
    
    loadOutstandingInvoiceH: function(component, event, helper){
        console.log('[h:loadOutstandingInvoice] Start', new Date().toISOString());
        var accountId = component.get('v.accountId');        
        console.log('[h:loadOutstandingInvoice] Account Id: ', accountId);
        var action = component.get("c.getRelatedInvoiceList");        
        action.setParams({"accountId": accountId});        
        action.setCallback(this, function(response){            
            var state = response.getState(); 
            if (state == 'SUCCESS') { 
                var invRecords =  response.getReturnValue();
                var totalUnpaid = 0.00;
                var toPayAmnt = 0.00;
                var invoiceIds = component.get('v.paidInvoiceIds').toString();
                
                var verifoneTransactionId = component.get('v.verifoneTransactionId');
                               
                console.log('[h:loadOutstandingInvoice] Invoice Records:', invRecords);
                console.log('[h:loadOutstandingInvoice] Invoice IDs:', invoiceIds);
                console.log('[h:loadOutstandingInvoice] Verifone Transaction ID:', verifoneTransactionId);
                
                invRecords.forEach(function(inv){
                    if (invoiceIds && invoiceIds.includes(inv.Id) && verifoneTransactionId){     
                        inv.Hide = true;                        
                    } else {
                        totalUnpaid += inv.blng__Balance__c ?  inv.blng__Balance__c : 0;
                    }
                });
                component.set("v.invoiceList", invRecords);
                console.log('[h:loadOutstandingInvoice] Total unpaid amount is : ', totalUnpaid);
                component.set("v.totalUnpaidAmount", totalUnpaid.toFixed(2));
                component.set("v.amountToPay", toPayAmnt.toFixed(2));                
            }
        });
        
        $A.enqueueAction(action); 
    },

    // Make payment for the invoices selected.
    makePaymentHelperH : function(component, event, helper) {
        console.log('[h:makePaymentHelper] Start');


        component.set('v.responsePending',true);
        var currentPageUrl = window.location.href; 

        var action = component.get("c.processInvoicePayments");
        
        var pageUrl = currentPageUrl.toString().substr(0, currentPageUrl.indexOf('/s/'));  
        
        pageUrl += '/s/hh-details-page?accountId=' + component.get('v.accountId');

        var selectedInvoiceIds = component.get('v.selectedInvoiceList');

        pageUrl += '&invoiceIds=';

        for (var x = 0; x < selectedInvoiceIds.length; x++){

            pageUrl += selectedInvoiceIds[x];

            if (x < (selectedInvoiceIds.length - 1)){
                pageUrl += ',';
            }

        }

        pageUrl += '#2';

        console.log('[h:makePaymentHelper] Redirect URL:', pageUrl);

        var params = {
            "accountId": component.get('v.accountId'),
            "selectedInvcId": selectedInvoiceIds,
            "amountVal": component.get("v.amountToPay"),
            "redirectUrl": pageUrl,
            "personContactVal": null
        };

        console.log('[h:makePaymentHelper] Process Invoice Params',params);
        action.setParams(params);
        action.setCallback(this, function(response) {
            console.log('[h:makePaymentHelper] Callback:',response.getState(),response.getReturnValue());
            var state = response.getState();
            component.set('v.responsePending',false);
            if (state === "SUCCESS" && !response.getReturnValue().startsWith('error:')) {                
                var responseData = response.getReturnValue();
                var checkout = responseData.toString();
                
                // pull session id from URL to set in the session
                var checkoutId = checkout.split('checkout/view/')[1].split('.html')[0];
                component.set("v.checkoutId", checkoutId);
                sessionStorage.setItem('ScheckoutId', checkoutId);                   
                console.log('[h:makePaymentHelper] Stored ScheckoutId:', checkoutId);  
                
                console.log('[h:makePaymentHelper] Opening Window:', responseData);
                
               	window.open(responseData, "_self");
                
			} else {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "type" : "error",
                    "message": response.getReturnValue()
                });
                toastEvent.fire();
              console.error(response.getErrors());
                
            }
            
        });
        $A.enqueueAction(action);
    },
    
    // Calculate the total amount to be paid for selected invoices
    calculateToPayAmntH : function(component, selectedListofInv) { 
        
        var allInvList =  component.get("v.invoiceList");
        var allInvlistLength = allInvList.length;
        var selectedInvlistLength = selectedListofInv.length;
        var payableAmount = 0;

        for (var i = 0; i < allInvlistLength; i++) {
            for(var j = 0; j < selectedInvlistLength; j++) {
                if(allInvList[i].Id == selectedListofInv[j]){
                    payableAmount += allInvList[i].blng__Balance__c;
                }
            }
        }
        
        console.log('[h:calculateToPayAmnt] Payable amount is: ', payableAmount);
        component.set('v.amountToPay', payableAmount.toFixed(2));        
    }
})