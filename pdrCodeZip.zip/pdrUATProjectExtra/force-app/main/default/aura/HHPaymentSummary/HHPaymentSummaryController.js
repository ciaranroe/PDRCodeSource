({
    doInit : function(component, event, helper) {
      if (component.get('v.hasInit') == false) {
        console.log('[c:doInit] Start');
        //helper.loadOutstandingInvoice(component, event, helper);
        helper.parsePageUrlParameterH(component, event, helper);
        helper.getAcctDetailsH(component, event, helper);
        helper.getRelatedAccountListH(component, event, helper);
        helper.getDefaultCurrencySymbolH(component, event, helper); 
      }
    },    
    handleCheckBoxChange: function(component, event, helper) {
        
        var checkBoxFieldValue = event.getSource().get("v.checked");
        var action = event.getSource();  
        var invoiceId = action.get("v.value");
        
        var selectedInvList = component.get("v.selectedInvoiceList");
        
        // Add Invoice to selected list when checkbox is checked
        if(checkBoxFieldValue === true) {
            selectedInvList.push(invoiceId); 
            component.set("v.selectedInvoiceList", selectedInvList); 
        }
        
        // Remove Invoice from selected list when checkbox is unchecked
        if(checkBoxFieldValue === false) {
            const index = selectedInvList.indexOf(invoiceId);
            
            if (index > -1) {
                selectedInvList.splice(index, 1);
            }
            
            component.set("v.selectedInvoiceList", selectedInvList); 
        }  
        
        helper.calculateToPayAmntH(component, selectedInvList);
    }, 

    submitAmountDetails: function(component, event, helper) {
        helper.makePaymentHelperH(component, event, helper);               
    },
    
    hidePaymentSuccess : function(component, event, helper){
          component.set('v.paymentSuccess',false);
          sessionStorage.removeItem('ScheckoutId');
          var closeURL = window.location.href.split('&invoiceIds=')[0] + '#2';
          window.open(closeURL, '_self');
    },    
})