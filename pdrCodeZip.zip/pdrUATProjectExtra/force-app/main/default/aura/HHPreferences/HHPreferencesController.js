({
    doInit: function(component, event, helper) {
        component.set("v.valid", false);
        component.set("v.status", "Save Preferences");
        component.set("v.error", "");
        helper.getAccPreferences(component, event, helper);
    },

    updatePreferenceDetails:function(component, event, helper){
        helper.updatePreferences(component, event, helper);
    },
    
    makeChange: function(component, event, helper) {
        component.set("v.status", "Save Preferences");
        component.set("v.valid", true);
    }
    
})