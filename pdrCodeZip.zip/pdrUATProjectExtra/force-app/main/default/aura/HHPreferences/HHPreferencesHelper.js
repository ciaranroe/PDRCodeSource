({
    getAccPreferences : function(component, event, helper) {
        var action = component.get("c.getAcctPreferences");

        action.setCallback(this, function(actionResult){
            var state = actionResult.getState();
            console.log(JSON.stringify(actionResult.getReturnValue()));
            if(component.isValid() && state === "SUCCESS"){
                component.set("v.acctList", actionResult.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },

    updatePreferences: function(component, event, helper){
    
        component.set("v.error", "");
        component.set("v.status", "Saving..");
        component.set("v.valid", false);
        //Marketing Preferences
        var marEmail = component.find("marEmail").get('v.checked');
        var marSMS = component.find("marSMS").get('v.checked');
        var marPost = component.find("marPost").get('v.checked');
        var marTel = component.find("marTel").get('v.checked');

        console.log('checkbox values',marEmail,marSMS,marPost,marTel);

        var action = component.get("c.updateAcctPreferences");
        action.setParams({"marketingEmail": marEmail,
                            "marketingSMS": marSMS,
                            "marketingPost": marPost,
                            "marketingTel": marTel,
                            "serviceEmail": false,
                            "serviceSMS": false,
                            "servicePost": false,                 
                            "contractEmail": false,
                            "contractSMS": false,
                            "contractPost": false,
                            "statementEmail": false});
            
        action.setCallback(this, function(actionResult){
            console.log('c.updateAcctPreferences',actionResult.getState(),actionResult.getReturnValue());
            var state = actionResult.getState();

            if(state === "SUCCESS"){
                component.set("v.status", "Saved!");
            } else {
                component.set("v.error", response.getError()[0].message);
                component.set("v.status", "Failed!");
            }
        });
        $A.enqueueAction(action);
    }
})