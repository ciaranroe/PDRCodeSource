({
    setColWidths : function($C) {

        $C.set('v.Columns',{
            TransDate : 11, // 9
            DueDate : 8, // 18
            Status : 5, // 24
            Ledger : 5, // 29
            Type : 9, // 36
            SubType : 10, // 46
            Reference : 9, // 55
            WizardRef : 8, // 64
            Amount : 8, // 72
            Allocated : 8, // 80
            Balance : 8, // 88
            Running : 9 // 96
            // Disputed : 4 // 100
        });
    }, 
    prepLedgerEntries: function($C) {
        var entries = $C.get('v.Entries');
        var reportData = [];
        var regx = new RegExp("&#39;", 'g');

        entries.forEach(function(element) {
            reportData.push({
                // 'Posting Detail': ' ',
                'Posting Master Id': element.PostingMasterId ? '"' + element.PostingMasterId.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Transaction Date': element.TransactionDate ? element.TransactionDate : '',
                'Due Date': element.DueDate ? element.DueDate : '',
                'Ledger': element.Ledger ? '"' + element.Ledger.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Type': element.Type ? '"' + element.Type.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Sub Type': element.SubType ? '"' + element.SubType.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Reference': element.TransactionRef ? '"' + element.TransactionRef.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Wizard Reference': element.WizardTransactionRef ? '"' + element.WizardTransactionRef.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
                'Amount': element.Amount, 
                'Allocated': element.Allocated,
                'Balance': element.Balance, 
                'Running Balance': element.RunningBalance, 
                'Disputed': element.Disputed ? element.Disputed  : ''
            });

            // if (element.SubEntries && element.SubEntries.length){
            //     element.SubEntries.forEach(function(subElement){
            //         reportData.push({
            //             'Posting Detail': subElement.PostingDetail ? '"' + subElement.PostingDetail.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
            //             'Posting Master Id': ' ',
            //             'Transaction Date': ' ',
            //             'Due Date':  ' ',
            //             'Ledger': ' ',
            //             'Type': subElement.Type ? '"' + subElement.Type.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
            //             'Sub Type': subElement.TransactionRef ? '"' + subElement.TransactionRef.replace(regx, '?').replace(/&/, '').replace(/\"/g, "\"\"") + '"' : ' ',
            //             'Reference': ' ',
            //             'Wizard Reference': ' ',
            //             'Amount': subElement.Amount, 
            //             'Allocated': subElement.Allocated,
            //             'Balance': subElement.Balance, 
            //             'Running Balance': ' ', 
            //             'Disputed': ' '
            //         });
            //     });
            // }

        });
        return reportData;
    },
    convertArrayOfObjectsToCSV: function(args) {
        var result, ctr, keys, columnDelimiter, lineDelimiter, data;
        data = args.data || null;
        if (data == null || !data.length) {
            return null;
        }
        columnDelimiter = args.columnDelimiter || ',';
        lineDelimiter = args.lineDelimiter || '\n';
        keys = Object.keys(data[0]);
        result = '';
        result += keys.join(columnDelimiter);
        result += lineDelimiter;
        data.forEach(function(item) {
            ctr = 0;
            keys.forEach(function(key) {
                if (ctr > 0) result += columnDelimiter;
                result += item[key];
                ctr++;
            });
            result += lineDelimiter;
        });
        return result;
    }
})