({
    doInit : function($C,$E,$H) {

        var getAccountDetailsApex = $C.get('c.getAccountDetailsApex');
        getAccountDetailsApex.setParams({ recordId : $C.get('v.recordId')});
        getAccountDetailsApex.setCallback(this, function(response){
            console.log('c.getAccountDetailsApex',response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                $C.set('v.Account',response.getReturnValue());
            }
        });
        $A.enqueueAction(getAccountDetailsApex);
        $H.setColWidths($C);

    }, 
    setShowLedger : function($C,$E,$H){
        $C.set('v.ShowModal',true);

        if (!$C.get('v.EntriesLoaded')){
            var getLedgerDetailsApex = $C.get('c.getLedgerDetailsApex');
            getLedgerDetailsApex.setParams({ recordId : $C.get('v.recordId')});
            getLedgerDetailsApex.setCallback(this, function(response){
    
                console.log('c.getLedgerDetailsApex', response.getReturnValue());

                var entries = response.getReturnValue();
    
                if (entries.length){
                    entries.sort(function(a, b) {
                        return new Date(b.TransactionDate) - new Date(a.TransactionDate);
                    });
        
                    var runningBalance = 0;
        
                    entries.reverse().forEach(function(entry){
    
                        entry.Visible   = true;
    
                        if (entry.Status !== 'Draft' && entry.Status != 'Cancelled' && entry.Status !== 'Initiated'){
                            runningBalance += entry.RunningBalance;
                            entry.RunningBalance = runningBalance;
                        } else {
                            entry.Visible = false;
                        }
    
                        entry.Expanded  = false;
    
                        if (entry.Ledger == 'SL'){
                            entry.Ledger = 'Sales';
                        } else if (entry.Ledger == 'RL'){
                            entry.Ledger = 'Rent';
                        }
                    });
        
                    entries = entries.reverse();
                }

                $C.set('v.Entries',entries);
                $C.set('v.From', entries.length ? entries[entries.length -1].TransactionDate : null);
                $C.set('v.To', entries.length ? entries[0].TransactionDate : null);
            });
            $A.enqueueAction(getLedgerDetailsApex);
        }
    }, 
    evalEntries : function($C,$E,$H){

        var fromDate        = $C.get('v.From');
        var toDate          = $C.get('v.To');
        var transType       = $C.get('v.Type');
        var ledgerType      = $C.get('v.Ledger');
        var disputedOnly    = $C.get('v.DisputedOnly');
        var includeDraft    = $C.get('v.IncludeDraft');
        var balance         = $C.get('v.OutstandingBalance');

        var entries = $C.get('v.Entries');

        entries.forEach(function(entry){
          
            var fromDateValid      = !fromDate || entry.TransactionDate >= fromDate;
            var toDateValid        = !toDate || entry.TransactionDate <= toDate;
            var transTypeValid     = !transType || transType === 'Any' || entry.Type === transType;
            var ledgerTypeValid    = !ledgerType || ledgerType === 'Any' || entry.Ledger === ledgerType;
            var disputedOnlyValid  = !disputedOnly || entry.Disputed;
            var includeDraftValid  = includeDraft || entry.Status !== 'Draft' && entry.Status != 'Cancelled' && entry.Status !== 'Initiated'; 
            var balanceValid       = !balance || entry.Balance;
            

            entry.Visible = fromDateValid && toDateValid && transTypeValid && ledgerTypeValid && disputedOnlyValid && includeDraftValid && balanceValid;
        });

        $C.set('v.Entries',entries);

    },
    togglExpand : function($C,$E,$H){

        var entries     = $C.get('v.Entries');
        var entryIndex  = $E.currentTarget.dataset.index;

        entries[entryIndex].Expanded = !entries[entryIndex].Expanded;
        $C.set('v.Entries',entries);

    },
    setHideLedger : function($C,$E,$H){
        $C.set('v.ShowModal',false);
    }, 
    exportLedgerEntries : function($C,$E,$H){
        var account = $C.get('v.Account');
        var args = $H.prepLedgerEntries($C); 
        var data, filename, link; 
        var csv = $H.convertArrayOfObjectsToCSV({ data: args }); 
        if (csv == null) return;
        var today = new Date(); 
        filename = account.AccountNumber + ' Ledger - ' + today.toDateString() + '.csv'; 
        if (!csv.match(/^data:text\/csv/i)) { 
            csv = 'data:text/csv;charset=utf-8,' + csv; 
        } 
        data = encodeURI(csv); 
        link = document.createElement('a'); 
        link.setAttribute('href', data); 
        link.setAttribute('download', filename); 
        link.click();
    }
})