({
  loadQuote: function($C, $E, $H) {
        
  }
})