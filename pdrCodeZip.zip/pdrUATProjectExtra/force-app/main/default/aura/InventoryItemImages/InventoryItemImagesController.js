({
    doInit : function($C) {

        var getImagesApex = $C.get('c.getImagesApex');
        getImagesApex.setParams({ recordId : $C.get('v.recordId')});
        getImagesApex.setCallback(this, function(response){
            if (response.getState() === 'SUCCESS'){
                $C.set('v.images',response.getReturnValue());
            }
        });
        $A.enqueueAction(getImagesApex);
    }
})