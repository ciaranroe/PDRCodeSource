({
    doInit : function($C, $E, $H) {

        var getPitchInfoApex = $C.get('c.getPitchInfoApex');
        getPitchInfoApex.setParams({recordId : $C.get('v.recordId')});
        getPitchInfoApex.setCallback(this, function(response){ 
            if (response.getState() === 'SUCCESS'){ 
                console.log('$C.get(c.getPitchInfoApex)', response.getReturnValue());

                var content         = response.getReturnValue();

                if (content.Map && content.Map.length){
                    var park            = content.Park;
                    var mapURL          = '/resource/' + content.Map[0].Name;
                    var jsonString      = park.Pitch_Locations__c;
                    var areas           = content.Areas;
                    var locations       = [];
    
                    if (areas.length){
                        $C.set('v.areaId',areas[0].Id);
                    }
                    
                    if (jsonString){
                        locations = JSON.parse(jsonString);
                        // locations.sort(function(a, b) {
                        //     const nameA = a.Name.toUpperCase();
                        //     const nameB = b.Name.toUpperCase();
                          
                        //     let comparison = 0;
                        //     if (nameA > nameB) {
                        //       comparison = 1;
                        //     } else if (nameA < nameB) {
                        //       comparison = -1;
                        //     }
                        //     return comparison;
                        // });
                    }
    
                    var currentAreas    = [];
                    var currentPitches  = [];
                    
                    for (var x = 0; x < locations.length; x++){
                        currentAreas.push(locations[x].Name);

                        for (var y = 0; y < locations[x].Pitches.length; y++){
                            currentPitches.push(locations[x].Name + '' + locations[x].Pitches[y].Id);
                        }
                    }
    
                    for (var x = 0; x < areas.length; x++){ 
    
                        if (!currentAreas.includes(areas[x].Name)){
                            locations.push({
                                Id : areas[x].Id,
                                Name : areas[x].Name,
                                Pitches : []
                            });
                        }
    
                        if (areas[x].Pitches__r){
                            for (var y = 0; y < areas[x].Pitches__r.length; y++){
    
                                var pitch = areas[x].Pitches__r[y];
    
                                if (!currentPitches.includes(pitch.Areas__r.Name + '' + pitch.Id)){
                                    locations[x].Pitches.push({
                                        Number : pitch.Number__c, 
                                        Id : pitch.Id,
                                        X : null, 
                                        Y : null
                                    });
                                }               
                            }
                        }
                    }
    
                    console.log('locations',locations);

                    console.log('areas is ',areas);

                    $C.set('v.mapURL',mapURL);
                    $C.set('v.locations',locations);
                    $C.set('v.areas',areas);
                    $C.set('v.areaIndex',0);

                    if (locations.length && locations[0].Pitches && locations[0].Pitches.length){
                        $C.set('v.pitchId', locations[0].Pitches[0].Id);
                    } else {
                        $C.set('v.pitchId', null);
                    }

                } else {
                    $C.set('v.message', 'It looks like we\'re missing a map image for this park');
                }
            }
        });
        $A.enqueueAction(getPitchInfoApex);
    },
    togglPlot : function($C){ 
        $C.set('v.plot',!$C.get('v.plot'));
        if ($C.get('v.plot')) $C.set('v.mode','pitch');
    },
    setPitchIndex : function($C,$E){ 
        $C.set('v.pitchId',$E.currentTarget.dataset.id);
        $C.set('v.mode','pitch');
    },
    areaChange : function($C,$E){

        var areaIndex = $C.find('select').get('v.value');
        var locations = $C.get('v.locations');

        $C.set('v.areaIndex',areaIndex);
        $C.set('v.areaId',locations[areaIndex].Id);

        if (locations[areaIndex].Pitches && locations[areaIndex].Pitches.length){
            $C.set('v.pitchId', locations[areaIndex].Pitches[0].Id);
        } else {
            $C.set('v.pitchId', null);
        }
    },
    checkXY : function($C,$E,$H){ 

        if ($C.get('v.mode') === 'pitch'){ 
            var mapElement      = $C.find('map').getElement();
            var boundingRect    = mapElement.getBoundingClientRect();
    
            var offsetTop       = boundingRect.top;
            var offsetLeft      = boundingRect.left;
            var actualTop       = $E.clientY - offsetTop;
            var actualLeft      = $E.clientX - offsetLeft;
            
            var elementWidth    = mapElement.clientWidth;
            var elementHeight   = mapElement.clientHeight;
    
            var percentLeft     = ((actualLeft / elementWidth) * 100);
            var percentTop      = ((actualTop / elementHeight) * 100);
    
            var areaIndex       = $C.get('v.areaIndex');
            var pitchId         = $C.get('v.pitchId');
            var locations       = $C.get('v.locations');

            locations[areaIndex].Pitches.forEach(function(pitch){
                if (pitch.Id == pitchId){
                    pitch.X = percentLeft.toFixed(3);
                    pitch.Y = percentTop.toFixed(3);
                }
            });

            for (var x = 0; x < locations[areaIndex].Pitches.length; x ++){

                if (locations[areaIndex].Pitches[x].Id == pitchId){

                    locations[areaIndex].Pitches[x].X = percentLeft.toFixed(3);
                    locations[areaIndex].Pitches[x].Y = percentTop.toFixed(3);

                    if (locations[areaIndex].Pitches[x + 1]){
                        pitchId = locations[areaIndex].Pitches[x + 1].Id;
                    }

                    break;
                } 
            }

            $C.set('v.pitchId',pitchId);
            $C.set('v.locations',locations);
            $A.enqueueAction($C.get('c.saveSelection'));
        }
    },
    clearPitch : function($C,$E){
        var locations = $C.get('v.locations');
        var areaIndex = $C.get('v.areaIndex');
        var pitchIndex = $E.currentTarget.dataset.index;

        locations[areaIndex].Pitches.forEach(function(pitch){
            if (pitch.Number == pitchIndex){
                pitch.X = null;
                pitch.Y = null;
            }
        });

        $C.set('v.locations',locations);
        $A.enqueueAction($C.get('c.saveSelection'));
    },
    saveSelection : function($C){ 

        var locations = $C.get('v.locations');
        var pitchLocations = JSON.stringify(locations);

        var saveSelectionApex = $C.get('c.saveSelectionApex');
        saveSelectionApex.setParams({ recordId : $C.get('v.recordId'), pitchLocations : pitchLocations});
        saveSelectionApex.setCallback(this, function(response){ 
            if (response.getState() === 'SUCCESS'){
                console.log(response.getReturnValue());
            }
        });
        $A.enqueueAction(saveSelectionApex);
    }
})