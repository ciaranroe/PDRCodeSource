({
    doInit : function($C,$E,$H){
        $C.set('v.ResponsePending', true);
        var doPricingApex = $C.get('c.doPricingApex');
        doPricingApex.setParams({ recordId : $C.get('v.recordId')});
        doPricingApex.setCallback(this, function(response){
            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success'){
                //update toast and close modal on sucess
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "The record has been updated successfully."
                    });
                toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                
            } else {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "type": "error",
                    "mode":"pester",
                    "message": response.getReturnValue()
                    });
                toastEvent.fire();
            }            
            $A.get("e.force:closeQuickAction").fire();
        });
        $A.enqueueAction(doPricingApex);
    },
})