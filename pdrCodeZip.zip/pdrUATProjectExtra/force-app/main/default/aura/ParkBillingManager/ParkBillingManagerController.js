({
    doInit: function ($C, $E, $H) {

        var getPitchFeeInfoApex = $C.get('c.getPitchFeeInfoApex');
        getPitchFeeInfoApex.setParams({ recordId: $C.get('v.recordId') });
        getPitchFeeInfoApex.setCallback(this, function (response) {
            console.log(response.getState(), response.getReturnValue());

            var content = response.getReturnValue();

            if (content.Park) {
                $C.set('v.Park', content.Park[0]);
            }

            if (content.BillingYears) {
                $C.set('v.BillingYears', content.BillingYears);
                if (content.BillingYears.length) {
                    content.BillingYears.forEach(function (year) {
                        if (year.Is_Current_Year__c) {
                            $C.set('v.ActiveYear', year);

                            console.log('setting active year original', JSON.parse(JSON.stringify(year)));
                            $C.set('v.ActiveYearOriginal', JSON.parse(JSON.stringify(year)));
                        }
                    });
                }
            }

            $C.set('v.NewOwnerFeesLoaded', true);
        });
        $A.enqueueAction(getPitchFeeInfoApex);

        var currentYear = new Date().getFullYear();
        $C.set('v.SelectedYear', currentYear);
        $C.set('v.SelectedUtilityYear', currentYear);
        var SelectableYears = [];
        SelectableYears.push(currentYear + 1);
        SelectableYears.push(currentYear);

        for (var x = 0; x < 10; x++) {
            SelectableYears.push(currentYear - (x + 1));
        }

        $C.set('v.SelectableYears', SelectableYears);
        $C.set('v.SelectableUtilityYears', SelectableYears);
    },
    setModeHome: function ($C, $E, $H) {
        var mode = 'home';

        if ($E.currentTarget && $E.currentTarget.dataset && $E.currentTarget.dataset.mode) {
            mode = $E.currentTarget.dataset.mode;
        }

        $C.set('v.Mode', mode);
        $C.set('v.PitchBillingExpanded', false);
        $C.set('v.RenewalsExpanded', false);
    },
    setModeNewOwner: function ($C, $E, $H) {
        $C.set('v.Mode', 'new-owner');
    },
    setModeRenewalForecasts: function ($C, $E, $H) {

        $C.set('v.Mode', 'renewal-forecasts');
        $C.set('v.RenewalsExpanded', true);

        var renewalsLoaded = $C.get('v.RenewalsLoaded');

        if (!renewalsLoaded) {
            $H.getRenewalForecasts($C);
        }
    },
    setEditUplift: function ($C) {
        $C.set('v.RenewalUpliftEdit', true);
    },
    setCancelUplift: function ($C, $E, $H) {
        $C.set('v.RenewalUpliftEdit', false);
        $C.set('v.RenewalUplift', $C.get('v.RenewalUpliftOriginal'));
        $C.set('v.RenewalsPending', true);
        $C.set('v.RenewalPreviewLoaded', false);
        $H.getRenewalForecasts($C);
    },
    previewUpliftChange: function ($C, $E, $H) {
        $C.set('v.RenewalsPending', true);
        var uplift = $C.get('v.RenewalUplift');
        $H.getRenewalForecasts($C, (uplift * 100));

    },
    saveUpliftChange: function ($C, $E, $H) {
        $C.set('v.RenewalsPending', true);
        var uplift = $C.get('v.RenewalUplift');
        var billingYearId = $C.get('v.BillingYearId');

        console.log('billing year id is ', billingYearId);
        var saveRenewalInfoApex = $C.get('c.saveRenewalInfoApex');
        saveRenewalInfoApex.setParams({ recordId: billingYearId, upliftValue: (uplift * 100) });
        saveRenewalInfoApex.setCallback(this, function (response) {

            console.log(response.getState(), response.getReturnValue());
            $C.set('v.RenewalsPending', false);
            $C.set('v.RenewalUpliftEdit', false);
            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success') {
                $C.set('v.RenewalUpliftOriginal', uplift);
            } else {

            }
        });
        $A.enqueueAction(saveRenewalInfoApex);
    },


    setModeYearlyBilling2: function ($C, $E, $H) {

        $C.set('v.Mode', 'pitch-billing2');
        // var pitchBillingLoaded = $C.get('v.PitchBilling2Loaded');
        // if (!pitchBillingLoaded) {
        //     var selectedYear = $C.get('v.SelectedYear');
        //     var productType = $C.get('v.BillingType');
        //     $H.getPitchBillingData2($C, selectedYear, productType);
        // }
    },

    getYearlyBilling: function ($C, $E, $H) {
        var selectedYear = $C.get('v.SelectedYear');
        var productType = $C.get('v.BillingType');
        $H.getPitchBillingData($C, selectedYear, productType);
    },
    toggleExpandPitchFeeAccount: function ($C, $E, $H) {

        var accIndex = $E.currentTarget.dataset.index;

        var billing = $C.get('v.Billing');
        billing.Accounts[accIndex].Expanded = !billing.Accounts[accIndex].Expanded;
        $C.set('v.Billing', billing);

    },
    togglEditingPitchFees: function ($C, $E, $H) {
        $C.set('v.EditingPitchFees', !$C.get('v.EditingPitchFees'));

        if (!$C.get('v.EditingPitchFees')) {
            var original = $C.get('v.ActiveYearOriginal');
            console.log('active year original ', JSON.parse(JSON.stringify(original)));
            $C.set('v.ActiveYear', JSON.parse(JSON.stringify(original)));
            $C.set('v.PitchFeesChanged', false);
        }
    },
    evalPitchFees: function ($C, $E, $H) {

        $C.set('v.PitchFeesChanged', true);

        var billingYear = $C.get('v.ActiveYear');

        var bandings = ['Starter', 'Standard', 'Premium', 'Platinum', 'Lodge'];

        bandings.forEach(function (banding) {
            if (billingYear[banding + '_Pitch_Fees_This_Year__c'] != null) {

                if (billingYear[banding + '_Uplift_Type__c'] && billingYear[banding + '_Uplift_Value__c']) {

                    if (billingYear[banding + '_Uplift_Type__c'] == '%') {
                        billingYear[banding + '_Pitch_Fees_Next_Year__c'] = parseFloat(billingYear[banding + '_Pitch_Fees_This_Year__c']) + (parseFloat(billingYear[banding + '_Pitch_Fees_This_Year__c']) * (parseFloat(billingYear[banding + '_Uplift_Value__c']) / 100));
                    } else if (billingYear[banding + '_Uplift_Type__c'] == '£') {
                        console.log('setting uplift value');
                        billingYear[banding + '_Pitch_Fees_Next_Year__c'] = parseFloat(billingYear[banding + '_Pitch_Fees_This_Year__c']) + parseFloat(billingYear[banding + '_Uplift_Value__c']);
                    } else if (billingYear[banding + '_Uplift_Type__c'] == 'Fixed') {
                        billingYear[banding + '_Pitch_Fees_Next_Year__c'] = parseFloat(billingYear[banding + '_Uplift_Value__c']);
                    }
                } else {
                    billingYear[banding + '_Uplift_Value__c'] = null;
                    billingYear[banding + '_Pitch_Fees_Next_Year__c'] = null;
                }
            } else {
                billingYear[banding + '_Uplift_Value__c'] = null;
                billingYear[banding + '_Pitch_Fees_Next_Year__c'] = null;
            }
        });

        $C.set('v.ActiveYear', billingYear);
    },
    savePitchFees: function ($C, $E, $H) {

        $C.set('v.ResponsePending', true);

        var billingYear = $C.get('v.ActiveYear');

        console.log('billign year is ',billingYear);
        var savePitchFeesApex = $C.get('c.savePitchFeesApex');
        savePitchFeesApex.setParams({ billingYear: billingYear });
        savePitchFeesApex.setCallback(this, function (response) {

            console.log(response.getState(), response.getReturnValue());
            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success') {
                $C.set('v.EditingPitchFees', false);
                $C.set('v.ActiveYearOriginal', billingYear);
                $C.set('v.PitchFeesChanged', false);
                $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "The record has been updated successfully." }).fire();
            } else {
                $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getReturnValue() }).fire();
            }
        });
        $A.enqueueAction(savePitchFeesApex);
    },
    togglEditingRates: function ($C, $E, $H) {
        $C.set('v.EditingRates', !$C.get('v.EditingRates'));

        if (!$C.get('v.EditingRates')) {
            var original = $C.get('v.ActiveYearOriginal');
            console.log('active year original ', JSON.parse(JSON.stringify(original)));
            $C.set('v.ActiveYear', JSON.parse(JSON.stringify(original)));
            $C.set('v.RatesChanged', false);
        }
    },
    evalRates: function ($C, $E, $H) {
        $C.set('v.RatesChanged', true);
    },
    saveRates: function ($C, $E, $H) {
        $C.set('v.ResponsePending', true);

        var billingYear = $C.get('v.ActiveYear');
        var saveRatesApex = $C.get('c.saveRatesApex');
        saveRatesApex.setParams({ billingYear: billingYear });
        saveRatesApex.setCallback(this, function (response) {

            console.log(response.getState(), response.getReturnValue());
            $C.set('v.ResponsePending', false);
            if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success') {
                $C.set('v.EditingRates', false);
                $C.set('v.ActiveYearOriginal', billingYear);
                $C.set('v.RatesChanged', false);
                $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "The record has been updated successfully." }).fire();
            } else {
                $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getReturnValue() }).fire();
            }
        });
        $A.enqueueAction(saveRatesApex);
    },
    togglExpandUpliftAccounts: function ($C, $E, $H) {
        var pitchType = $E.currentTarget.dataset.type;
        var renewals = $C.get('v.Renewals');
        renewals[pitchType + 'Expanded'] = !renewals[pitchType + 'Expanded'];
        $C.set('v.Renewals', renewals);
    },
    togglRenewalsExpanded: function ($C, $E, $H) {
        $C.set('v.RenewalsExpanded', !$C.get('v.RenewalsExpanded'));
    },
    togglPitchBillingExpanded: function ($C, $E, $H) {
        $C.set('v.PitchBillingExpanded', !$C.get('v.PitchBillingExpanded'));
    },
    filterBillingData: function ($C, $E, $H) {

        var billingFilter = $C.get('v.BillingFilter');
        var billing = $C.get('v.Billing');

        if (billing.Accounts.length) {
            billing.Accounts.forEach(function (bill) {
                bill.Show = !billingFilter || bill.Status === billingFilter;
                bill.Selected = false;
            });
        }

        $C.set('v.Billing', billing);
    },
    // TO RECONFIGURE AS METHODS SPECIFIC TO 'DRAFT INVOICE' AND 'POST INVOICE'
    toggleSelectAll: function ($C, $E, $H) {

        var selectAll = $C.get('v.SelectAll');
        var billingFilter = $C.get('v.BillingFilter');
        var billing = $C.get('v.Billing');
        var selectedRecords = 0;

        billing.Accounts.forEach(function (acc) {
            if (acc.Status === billingFilter && acc.Account.Permitted_for_Billing__c == 'Permitted') {
                acc.Selected = selectAll;
            } else {
                acc.Selected = false;
            }

            selectedRecords += acc.Selected ? 1 : 0;
        });

        $C.set('v.Billing', billing);
        $C.set('v.BillingRecordsSelected', selectAll);
        $C.set('v.BillingRecords', selectedRecords);

    },
    setBillingButton: function ($C, $E, $H) {

        var billing = $C.get('v.Billing');
        var billingRecords = 0;

        billing.Accounts.forEach(function (acc) {
            billingRecords += acc.Selected ? 1 : 0;
        });

        $C.set('v.BillingRecords', billingRecords);
    },
    createDraftInvoices: function ($C, $E, $H) {

        $C.set('v.BillingProcessing', true);

        var billing = $C.get('v.Billing');
        var pendingBillingRecords = $C.get('v.PendingBillingRecords');

        if (!pendingBillingRecords) {
            pendingBillingRecords = {};
        }

        var priorContractIds = [];
        var orderIds = [];

        for (var x = 0; x < billing.Accounts.length; x++) {
            if (billing.Accounts[x].Selected && billing.Accounts[x].Status === 'Unbilled') {
                if (billing.Accounts[x].OrderId) {
                    orderIds.push(billing.Accounts[x].OrderId)
                } else if (billing.Accounts[x].PriorContractId) {
                    priorContractIds.push(billing.Accounts[x].PriorContractId);
                }

                pendingBillingRecords[billing.Accounts[x].Account.Id] = x;
                billing.Accounts[x].Processing = true;
                billing.Accounts[x].TargetStatusChange = 'Unbilled';
                billing.Accounts[x].Selected = false;
            }
        }

        $C.set('v.Billing', billing);

        console.log('priorContractIds', priorContractIds, 'orderIds', orderIds);

        var createDraftInvoicesApex = $C.get('c.createDraftInvoicesApex');
        createDraftInvoicesApex.setParams({ parkId: $C.get('v.recordId'), subscriptionType: $C.get('v.BillingType'), listContractSubset: priorContractIds, orderIds: orderIds });
        createDraftInvoicesApex.setCallback(this, function (response) {

            $C.set('v.BillingProcessing', false);
            console.log('createDraftInvoicesApex', response.getState(), response.getReturnValue());

            var returnValue = response.getReturnValue();

            if (response.getState() === 'SUCCESS' && returnValue === 'success') {

                for (var x = 0; x < billing.Accounts.length; x++) {

                    if (billing.Accounts[x].Selected && billing.Accounts[x].Status === 'Unbilled') {
                        pendingBillingRecords[billing.Accounts[x].Account.Id] = x;
                        billing.Accounts[x].Processing = true;
                        billing.Accounts[x].TargetStatusChange = 'Unbilled';
                        billing.Accounts[x].Selected = false;
                    }
                }

                $C.set('v.Billing', billing);
                $C.set('v.PendingBillingRecords', pendingBillingRecords);

                $A.enqueueAction($C.get('c.beginPoll'));
                $C.set('v.BillingRecords', 0);
                $A.get("e.force:showToast").setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "Draft invoices being generated for " + (priorContractIds.length + orderIds.length) + " accounts."
                }).fire();
            } else {
                $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": returnValue }).fire();
            }
        });
        $A.enqueueAction(createDraftInvoicesApex);

    },
    cancelDraftInvoices: function ($C, $E, $H) {
        $A.get("e.force:showToast").setParams({ "title": "UNDER DEVELOPMENT", "warn": "error", "message": "This function is still under development" }).fire();
    },
    postInvoices: function ($C, $E, $H) {

        $C.set('v.BillingProcessing', true);

        var billing = $C.get('v.Billing');

        var pendingBillingRecords = $C.get('v.PendingBillingRecords');

        if (!pendingBillingRecords) {
            pendingBillingRecords = {};
        }

        var invoiceIds = [];

        for (var x = 0; x < billing.Accounts.length; x++) {
            if (billing.Accounts[x].Selected && billing.Accounts[x].Status === 'Draft') {
                invoiceIds.push(billing.Accounts[x].InvoiceId);
            }
        }

        $C.set('v.Billing', billing);

        if (invoiceIds.length) {

            var postInvoicesApex = $C.get('c.postInvoicesApex');
            postInvoicesApex.setParams({ listInvoiceIds: invoiceIds });
            postInvoicesApex.setCallback(this, function (response) {

                $C.set('v.BillingProcessing', false);
                console.log('postInvoicesApex', response.getState(), response.getReturnValue());

                if (response.getState() === 'SUCCESS' && response.getReturnValue() === 'success') {

                    for (var x = 0; x < billing.Accounts.length; x++) {

                        if (billing.Accounts[x].Selected && billing.Accounts[x].Status === 'Draft') {
                            pendingBillingRecords[billing.Accounts[x].Account.Id] = x;
                            billing.Accounts[x].Processing = true;
                            billing.Accounts[x].TargetStatusChange = 'Draft';
                            billing.Accounts[x].Selected = false;
                        }
                    }

                    $C.set('v.Billing', billing);
                    $C.set('v.PendingBillingRecords', pendingBillingRecords);
                    $A.enqueueAction($C.get('c.beginPoll'));
                    $C.set('v.BillingRecords', 0);
                    $A.get("e.force:showToast").setParams({ "title": "Success!", "type": "success", "message": "Posting invoices for " + invoiceIds.length + " accounts" }).fire();
                } else {
                    $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": response.getReturnValue() }).fire();
                }
            });
            $A.enqueueAction(postInvoicesApex);
        } else {
            $C.set('v.BillingProcessing', false);
            $A.get("e.force:showToast").setParams({ "title": "Error!", "type": "error", "message": "It looks like no records were sent for processing" }).fire();
        }
    },
    exportInvoicingData: function ($C, $E, $H) {

    },
    loadInvoicePreview: function ($C, $E, $H) {
        $C.set('v.InvoicePreviewId', $E.currentTarget.dataset.invoiceid);
        $C.set('v.WeaverTemplateId', $E.currentTarget.dataset.templateid);
    },
    cancelInvoicePreview: function ($C, $E, $H) {
        $C.set('v.InvoicePreviewId', '');
        $C.set('v.WeaverTemplateId', '');
    },
    loadInvoiceDocumentPreview: function ($C, $E, $H) {
        $C.set('v.InvoiceDocumentPreviewId', $E.currentTarget.dataset.invoiceid);
        console.log('invoice id is ', $E.currentTarget.dataset.invoiceid);
    },
    cancelInvoiceDocumentPreview: function ($C, $E, $H) {
        $C.set('v.InvoiceDocumentPreviewId', '');
    },
    beginPoll: function ($C, $E, $H) {

        var pendingBillingRecords = $C.get('v.PendingBillingRecords');
        var billing = $C.get('v.Billing');

        if (pendingBillingRecords) {

            var accountIdList = Object.keys(pendingBillingRecords);

            if (accountIdList.length) {

                var getPitchBillingInfoApex = $C.get('c.getPitchBillingInfoApex');
                getPitchBillingInfoApex.setParams({ recordId: $C.get('v.recordId'), accountIdList: accountIdList, yearFilter: $C.get('v.SelectedYear'), productType: $C.get('v.BillingType') });
                getPitchBillingInfoApex.setCallback(this, function (response) {
                    console.log('getPitchBillingInfoApex', response.getState(), response.getReturnValue());

                    var content = response.getReturnValue();

                    if (content.Accounts.length) {
                        content.Accounts.forEach(function (acc) {

                            if (pendingBillingRecords[acc.Account.Id]) {

                                var index = pendingBillingRecords[acc.Account.Id];

                                if (billing.Accounts[index]) {

                                    var pageState = billing.Accounts[index];

                                    if (acc.Status != pageState.TargetStatusChange) {
                                        delete pendingBillingRecords[acc.Account.Id];
                                        acc.Processing = false;
                                        // billing.Accounts[index] = acc;
                                    } else {
                                        // acc.Status = 'Processing';
                                        acc.Processing = true;
                                    }
                                    acc.Show = true;
                                    acc.Expanded = false;
                                    acc.TargetStatusChange = billing.Accounts[index].TargetStatusChange;
                                    billing.Accounts[index] = acc;
                                }
                            }
                        });
                    }

                    $C.set('v.Billing', billing);
                    var remaningRecords = Object.keys(pendingBillingRecords);

                    if (remaningRecords.length) {
                        window.setTimeout(
                            $A.getCallback(function () {
                                console.log('POLLING CONTINUED', remaningRecords);
                                $A.enqueueAction($C.get('c.beginPoll'));
                            }), 10000
                        );
                    } else {
                        console.log('POLLING STOPPED');
                    }

                });
                $A.enqueueAction(getPitchBillingInfoApex);
            }
        }
    },
    filterPitchBilling: function ($C, $E, $H) {

        var searchString = $C.get('v.BillingSearch');
        var billingFilter = $C.get('v.BillingFilter');
        var billing = $C.get('v.Billing');

        if (billing.Accounts.length) {
            billing.Accounts.forEach(function (bill) {
                bill.Show = (!billingFilter || bill.Status === billingFilter) &&
                    (!searchString ||
                        (bill.Account.Name && bill.Account.Name.toUpperCase().includes(searchString.toUpperCase())) ||
                        (bill.Account.Pitch_Name_Fx__c && bill.Account.Pitch_Name_Fx__c.toUpperCase().includes(searchString.toUpperCase())));
            });
        }

        $C.set('v.Billing', billing);
    },
    display: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;

        console.log('display called', dataset.id);
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    },
    displayOut: function ($C, $E, $H) {
        var dataset = $E.currentTarget.dataset;
        var toggleText = document.getElementById(dataset.id);
        $A.util.toggleClass(toggleText, "toggle");
    },
    setModeUtilityBilling: function ($C, $E, $H) {

        $C.set('v.Mode', 'utility');
        $C.set('v.UtilityBillingExpanded', true);
        var utilityBillingLoaded = $C.get('v.UtilityBillingLoaded');
        if (!utilityBillingLoaded) {
            var selectedYear = $C.get('v.SelectedUtilityYear');
            var productType = $C.get('v.UtilityBillingType');
            $H.getUtilityBillingStatus($C, selectedYear, productType);
        }
    },
    getUtilityBilling: function ($C, $E, $H) {
        var selectedYear = $C.get('v.SelectedUtilityYear');
        var productType = $C.get('v.UtilityBillingType');
        $H.getUtilityBillingStatus($C, selectedYear, productType);
    },
    filterUtilityBilling: function ($C, $E, $H) {

        // var searchString = $C.get('v.UtilityBillingSearch');
        // var billingFilter = $C.get('v.UtilityBillingFilter');
        // var utility = $C.get('v.Utility');

        // if (utility.length){
        //     utility.forEach(function(pitch){
        //         pitch.Show =  (!billingFilter || pitch.Status === billingFilter) && 
        //                         (!searchString || 
        //                         (bill.Account.Name && bill.Account.Name.toUpperCase().includes(searchString.toUpperCase())) || 
        //                         (bill.Account.Pitch_Name_Fx__c && bill.Account.Pitch_Name_Fx__c.toUpperCase().includes(searchString.toUpperCase())));
        //     });
        // }

        // $C.set('v.Utility',utility);
    },
    setModeInsuranceRenewals: function ($C, $E, $H) {

        $C.set('v.Mode', 'insurance-renewals');
        $C.set('v.InsuranceRenewalsExpanded', true);
        var parks = [];
        parks.push($C.get('v.recordId'));
        $C.set('v.SelectedParks', parks);
        var insuranceInfoLoaded = $C.get('v.InsuranceInfoLoaded');
        if (!insuranceInfoLoaded) {
            // var selectedDocument = $C.get('v.SelectedDocument');
            $H.getInsurancePolicyDefintions($C);
            $H.getParksInfo($C);
            $H.getInsuranceWarmUpLetterData($C);
        }
    },
    checkboxSelect: function (component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.checked");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.set("v.SelectAllInsurance", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.set("v.SelectAllInsurance", true);
        }
    },
    parkCheckboxSelect: function (component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.checked");
        var getSelectedNumber = component.get("v.selectedParksCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.set("v.SelectAllParksInsurance", false);
        }
        component.set("v.selectedParksCount", getSelectedNumber);
        //if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalParksCount")) {
            component.set("v.SelectAllParksInsurance", true);
        }
    },
    selectAllCheckbox: function (component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.checked");
        var updatedAllRecords = [];
        let selectedCount = 0;
        var listOfAllAccounts = component.get("v.Insurance");
        // loop on all records list 
        for (var i = 0; i < listOfAllAccounts.length; i++) {
            // check if header checkbox is 'true' then update all checkbox with true and update selected records count
            // else update all records with false and set selectedCount with 0  
            if (selectedHeaderCheck == true) {
                if (listOfAllAccounts[i].isShown == true) {
                    listOfAllAccounts[i].isChecked = true;
                    selectedCount++;
                }

            } else {
                listOfAllAccounts[i].isChecked = false;
                // component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listOfAllAccounts[i]);
        }
        component.set("v.selectedCount", selectedCount);
        component.set("v.SelectAllInsurance", selectedHeaderCheck);
        component.set("v.Insurance", updatedAllRecords);
    },
    selectAllParksCheckbox: function (component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.checked");
        var updatedAllRecords = [];
        let selectedCount = 0;
        var listOfAllParks = component.get("v.AllParks");
        // loop on all records list 
        for (var i = 0; i < listOfAllParks.length; i++) {
            // check if header checkbox is 'true' then update all checkbox with true and update selected records count
            // else update all records with false and set selectedCount with 0  
            if (selectedHeaderCheck == true) {
                listOfAllParks[i].isChecked = true;
                selectedCount++;
            } else {
                listOfAllParks[i].isChecked = false;
                // component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listOfAllParks[i]);
        }
        component.set("v.selectedParksCount", selectedCount);
        component.set("v.SelectAllParksInsurance", selectedHeaderCheck);
        component.set("v.AllParks", updatedAllRecords);
    },
    selectInsuranceDoc: function ($C, $E, $H) {

        let docSelected = $E.getSource().get('v.value');
        switch (docSelected) {
            case 'warm-up':
                $H.getInsuranceWarmUpLetterData($C);
                break;
            case "renewal-quote":
                $H.getRenewalQuoteLetterData($C);
                break;
            case "reminder-1":
                $H.getReminderLetterData($C, 1);
                break;
            case "lapsed-letter":
                $H.getLapsedLetterData($C);
                break;
        }
        $C.set('v.SelectedDocument', docSelected);
        $C.set('v.TypeOfCoverFilter', '');
        $C.set('v.ExpiryDateFrom', '');
        $C.set('v.ExpiryDateTo', '');
        $C.set('v.TypeFilter', '');


    },
    sendInsuranceDocs: function ($C, $E, $H) {
        let docToSend = $C.get("v.SelectedDocument");
        let allAccs = $C.get("v.Insurance");
        let accountsToSendTo = [];
        let nfoMap = {};
        let mvMap = {};


        allAccs.forEach(acc => {
            if (acc.isChecked) {
                if (docToSend == 'renewal-quote') {
                    let startDate = new Date(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                    startDate.setDate(startDate.getDate() + 1);
                    let insuranceDetails = $H.getInsuranceDetails(acc.objAccount.Holiday_Home__r.Holiday_Home__r, startDate, $C, $H);
                    nfoMap[acc.objAccount.Id] = insuranceDetails.NewForOldId;
                    mvMap[acc.objAccount.Id] = insuranceDetails.MarketValueId;
                }
                accountsToSendTo.push(acc.objAccount);
            }
        })


        var createInsuranceDocsApex = $C.get('c.createInsuranceDocsApex');
        createInsuranceDocsApex.setParams({
            docType: docToSend, accounts: accountsToSendTo, mvMap: mvMap, nfoMap: nfoMap
        });
        createInsuranceDocsApex.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "type": "success",
                    "mode": "dismissable"
                });

                switch (docToSend) {
                    case 'warm-up':
                        toastEvent.setParams({
                            "message": "Warm Up Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getInsuranceWarmUpLetterData($C);
                        break;
                    case 'renewal-quote':
                        toastEvent.setParams({
                            "message": "Renewal Quote Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getRenewalQuoteLetterData($C);
                        break;
                    case "reminder-1":
                        toastEvent.setParams({
                            "message": "1st Reminder Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getReminderLetterData($C, 1);
                        break;
                    case "lapsed-letter":
                        toastEvent.setParams({
                            "message": "Insurance Lapsed Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getLapsedLetterData($C);
                        break;
                }
                toastEvent.fire();
            }
        });
        $A.enqueueAction(createInsuranceDocsApex);
    },
    filterInsuranceDataByCoverType: function ($C, $E, $H) {
        let coverFilter = $E.getSource().get('v.value');
        let expiryTo = $C.get('v.ExpiryDateTo');
        let expiryFrom = $C.get('v.ExpiryDateFrom');
        let typeFilter = $C.get('v.TypeFilter');

        $H.filterInsurance(expiryFrom, expiryTo, coverFilter, typeFilter, $C);
        $C.set('v.TypeOfCoverFilter', coverFilter);
    },
    filterInsuranceDataByExpiry: function ($C, $E, $H) {
        let expiryDateFilter = $E.getSource().get('v.value');
        console.log('expiryDateFilter: ' + expiryDateFilter);
        let triggerField = $E.getSource().get("v.name");
        console.log('triggerField: ' + triggerField);
        let expiryFrom;
        let expiryTo;
        if (triggerField == 'expiry-from') {
            expiryFrom = $E.getSource().get('v.value');
            expiryTo = $C.get('v.ExpiryDateTo');
            console.log('expiryTo: ' + expiryTo);
            $C.set('v.ExpiryDateFrom', expiryFrom);
        }
        else if (triggerField == 'expiry-to') {
            expiryTo = $E.getSource().get('v.value');
            expiryFrom = $C.get('v.ExpiryDateFrom');
            $C.set('v.ExpiryDateTo', expiryTo);
        }

        let coverFilter = $C.get('v.TypeOfCoverFilter');
        let typeFilter = $C.get('v.TypeFilter');

        $H.filterInsurance(expiryFrom, expiryTo, coverFilter, typeFilter, $C);
        // $C.set('v.ExpiryDateFilter', expiryDateFilter);
    },
    filterInsuranceDataByType: function ($C, $E, $H) {
        let typeFilter = $E.getSource().get('v.value');
        let coverFilter = $C.get('v.TypeOfCoverFilter');
        let expiryTo = $C.get('v.ExpiryDateTo');
        let expiryFrom = $C.get('v.ExpiryDateFrom');

        $H.filterInsurance(expiryFrom, expiryTo, coverFilter, typeFilter, $C);
        $C.set('v.TypeFilter', typeFilter);
    },
    handleShowParkFilter: function ($C, $E, $H) {
        let parkFilterStatus = $C.get('v.showParkFilter')
        if (parkFilterStatus == false) { $C.set('v.showParkFilter', true); }
        else $C.set('v.showParkFilter', false);
    },
    handleParkCancel: function ($C, $E, $H) {
        let parkFilterStatus = $C.get('v.showParkFilter');
        let selectedParks = $C.get('v.SelectedParks');
        let parkCheckboxes = $C.get('v.AllParks');
        parkCheckboxes.forEach(parkWrap => {
            if (selectedParks.includes(parkWrap.park.Id)) { parkWrap.isChecked = true }
            else { parkWrap.isChecked = false }
        })

        if (parkFilterStatus == false) { $C.set('v.showParkFilter', true); }
        else {
            $C.set('v.selectedParksCount', selectedParks.length);
            $C.set('v.AllParks', parkCheckboxes);
            $C.set('v.showParkFilter', false);
        }
    },
    setParks: function ($C, $E, $H) {
        let allParkWrappers = $C.get("v.AllParks")
        let selectedParks = [];
        allParkWrappers.forEach(parkWrap => { if (parkWrap.isChecked == true) { selectedParks.push(parkWrap.park.Id) } })
        $C.set("v.SelectedParks", selectedParks);
        let docSelected = $C.get('v.SelectedDocument');
        switch (docSelected) {
            case 'warm-up':
                $H.getInsuranceWarmUpLetterData($C);
                break;
            case "renewal-quote":
                $H.getRenewalQuoteLetterData($C);
                break;
            case "reminder-1":
                $H.getReminderLetterData($C, 1);
                break;
            case "lapsed-letter":
                $H.getLapsedLetterData($C);
                break;
        }
        $C.set("v.showParkFilter", false);
        $C.set('v.TypeOfCoverFilter', '');
        $C.set('v.ExpiryDateFrom', '');
        $C.set('v.ExpiryDateTo', '');
        $C.set('v.TypeFilter', '');
    },
    handleShowConfirmModal: function (component) {
        var selectedCount = component.get("v.selectedCount");
        var SelectedDocument = component.get("v.SelectedDocument");
        let msgStr = '';
        switch (SelectedDocument) {
            case 'warm-up':
                msgStr = 'Insurance Renewal Warm-Up Letter(s)';
                break;
            case 'renewal-quote':
                msgStr = 'Insurance Renewal Quote Letter(s)';
                break;
            case "reminder-1":
                msgStr = 'Insurance Expiry First Reminder Letter(s)';
                break;
            case "lapsed-letter":
                msgStr = 'Insurance Lapsed Letter(s)';
                break;
        }
        $A.createComponent("c:OverlayLibraryModal", {},
            function (content, status) {
                if (status === "SUCCESS") {
                    var modalBody = content;
                    component.find('overlayLib').showCustomModal({
                        header: "Would you like to send " + msgStr + " to " + selectedCount + " account(s)?",
                        body: modalBody,
                        showCloseButton: false,
                        closeCallback: function (ovl) {
                            console.log('Overlay is closing');
                        }
                    }).then(function (overlay) {
                        console.log("Overlay is made");
                    });
                }
            });
    },
    handleApplicationEvent: function ($C, $E, $H) {
        var message = $E.getParam("message");
        // alert('@@@ ==> ' + message);
        if (message == 'Ok') {
            $H.sendInsuranceDocs($C, $E, $H)
        }
        else if (message == 'Cancel') {
            // if the user clicked the Cancel button do your further Action here for canceling
        }
    }
})