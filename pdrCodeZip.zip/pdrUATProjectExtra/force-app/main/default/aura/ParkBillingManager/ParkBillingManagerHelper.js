({
    getPitchBillingData: function ($C, year, productType) {

        var productType = $C.get('v.BillingType');
        $C.set('v.PitchBillingProcessing', true);
        var getYearlyInfoApex = $C.get('c.getPitchBillingInfoApex');
        getYearlyInfoApex.setParams({ recordId: $C.get('v.recordId'), accountIdList: [], yearFilter: year, productType: productType });
        getYearlyInfoApex.setCallback(this, function (response) {
            console.log('c.getPitchBillingInfoApex', response.getState(), response.getReturnValue());
            $C.set('v.PitchBillingProcessing', false);
            var content = response.getReturnValue();

            if (content.Accounts && content.Accounts.length) {
                content.Accounts.forEach(function (acc) {
                    acc.Show = true;
                    acc.Expanded = false;
                    acc.Processing = false;

                    if (acc.Status === 'Unbilled') {
                        acc.DisplayOrder = 1;
                    } else if (acc.Status === 'Draft') {
                        acc.DisplayOrder = 2;
                    } else if (acc.Disputed) {
                        acc.DisplayOrder = 3;
                    } else if (acc.Status === 'Posted') {
                        acc.DisplayOrder = 4;
                    } else if (acc.Status === 'Paid') {
                        acc.DisplayOrder = 5;
                    } else if (acc.Status === 'Overdue') {
                        acc.DisplayOrder = 6;
                    } else if (acc.Status === 'Error') {
                        acc.DisplayOrder = 7;
                    } else {
                        acc.DisplayOrder = 8;
                    }
                });

                content.Accounts.sort((a, b) => a.DisplayOrder > b.DisplayOrder ? 1 : -1);
            }

            $C.set('v.BillingSearch', '');
            $C.set('v.BillingFilter', '');
            $C.set('v.PendingBillingRecords', null);
            $C.set('v.Billing', content);
            $C.set('v.PitchBillingLoaded', true);
        });
        $A.enqueueAction(getYearlyInfoApex);

    },
    // getPitchBillingData2 : function ($C, year, productType) {

    //     var productType = $C.get('v.BillingType');
    //     $C.set('v.PitchBilling2Processing', true);
    //     var getYearlyInfoApex = $C.get('c.getPitchBillingInfoApexNew');
    //     getYearlyInfoApex.setParams({ recordId: $C.get('v.recordId'), accountIdList: [], yearFilter: year, productType: productType });
    //     getYearlyInfoApex.setCallback(this, function (response) {
    //         console.log('c.getPitchBillingInfoApex', response.getState(), response.getReturnValue());
    //         // $C.set('v.PitchBillingProcessing', false);
    //         // var content = response.getReturnValue();

    //         // if (content.Accounts && content.Accounts.length) {
    //         //     content.Accounts.forEach(function (acc) {
    //         //         acc.Show = true;
    //         //         acc.Expanded = false;
    //         //         acc.Processing = false;

    //         //         if (acc.Status === 'Unbilled') {
    //         //             acc.DisplayOrder = 1;
    //         //         } else if (acc.Status === 'Draft') {
    //         //             acc.DisplayOrder = 2;
    //         //         } else if (acc.Disputed) {
    //         //             acc.DisplayOrder = 3;
    //         //         } else if (acc.Status === 'Posted') {
    //         //             acc.DisplayOrder = 4;
    //         //         } else if (acc.Status === 'Paid') {
    //         //             acc.DisplayOrder = 5;
    //         //         } else if (acc.Status === 'Overdue') {
    //         //             acc.DisplayOrder = 6;
    //         //         } else if (acc.Status === 'Error') {
    //         //             acc.DisplayOrder = 7;
    //         //         } else {
    //         //             acc.DisplayOrder = 8;
    //         //         }
    //         //     });

    //         //     content.Accounts.sort((a, b) => a.DisplayOrder > b.DisplayOrder ? 1 : -1);
    //         // }

    //         // $C.set('v.BillingSearch', '');
    //         // $C.set('v.BillingFilter', '');
    //         // $C.set('v.PendingBillingRecords', null);
    //         // $C.set('v.Billing', content);
    //         // $C.set('v.PitchBillingLoaded', true);
    //     });
    //     $A.enqueueAction(getYearlyInfoApex);

    // },
    getRenewalForecasts: function ($C, uplift) {
        var getRenewalInfoApex = $C.get('c.getRenewalInfoApex');
        getRenewalInfoApex.setParams({ recordId: $C.get('v.recordId'), upliftValue: uplift });
        getRenewalInfoApex.setCallback(this, function (response) {
            console.log('RENEWALS', response.getState(), response.getReturnValue());

            var content = response.getReturnValue();
            $C.set('v.Renewals', content);

            if (content.BillingYearId) {
                $C.set('v.BillingYearId', content.BillingYearId);

            }

            $C.set('v.RenewalsPending', false);

            console.log('content.BillingYearId', content.BillingYearId);

            if (uplift == null) {
                $C.set('v.RenewalUpliftOriginal', (content.Uplift / 100));
                $C.set('v.RenewalUplift', (content.Uplift / 100));
                console.log('renewals.accounts', content.Accounts);
                $C.set('v.RenewalsLoaded', true);
            } else {
                $C.set('v.RenewalPreviewLoaded', true);
            }

        });
        $A.enqueueAction(getRenewalInfoApex);
    },
    getUtilityBillingStatus: function ($C, year, productType) {

        var productType = $C.get('v.UtilityBillingType');
        $C.set('v.UtilityBillingProcessing', true);
        var getUtilityBillingStatusApex = $C.get('c.getUtilityBillingStatusApex');
        getUtilityBillingStatusApex.setParams({ recordId: $C.get('v.recordId'), yearFilter: year, productType: productType });
        getUtilityBillingStatusApex.setCallback(this, function (response) {

            console.log('c.getUtilityBillingStatusApex', response.getState(), response.getReturnValue());

            var content = response.getReturnValue();
            $C.set('v.UtilityBillingPeriods', content.Months);


            if (content.Pitches && content.Pitches.length) {
                content.Pitches.forEach(function (pitch) {
                    pitch.Show = true;
                    pitch.Expanded = false;
                    pitch.Processing = false;

                    if (pitch.Meter_Readings__r) {

                        for (var x = 0; x < pitch.Meter_Readings__r.length; x++) {

                            if (x < (pitch.Meter_Readings__r.length - 1)) {

                                var priorReadingDate = new Date(pitch.Meter_Readings__r[x + 1].Meter_Reading_Date__c);
                                var start = new Date(priorReadingDate.getFullYear(), 0, 0);
                                var diff = priorReadingDate - start;
                                var oneDay = 1000 * 60 * 60 * 24;
                                var day = Math.floor(diff / oneDay) - 1;

                                var yearEndOffset = (day / 365) * 100;
                                console.log('id', pitch.Meter_Readings__r[x].Id, 'date', priorReadingDate, 'day', day, 'yearEndOffset', yearEndOffset);

                                pitch.Meter_Readings__r[x].StartOffset = yearEndOffset.toFixed(2);
                                pitch.Meter_Readings__r[x].PriorDate = priorReadingDate;
                            } else {
                                pitch.Meter_Readings__r[x].StartOffset = 0;
                                pitch.Meter_Readings__r[x].PriorDate = new Date(year, 0, 0);
                            }


                            var readingDate = new Date(pitch.Meter_Readings__r[x].Meter_Reading_Date__c);
                            var widthStartDate = pitch.Meter_Readings__r[x].PriorDate
                            var widthStartDiff = readingDate - widthStartDate;
                            var widthOneDay = 1000 * 60 * 60 * 24;
                            var widthstartDay = Math.floor(widthStartDiff / widthOneDay);

                            var width = (widthstartDay / 365) * 100;

                            pitch.Meter_Readings__r[x].Width = width - 0.2;// < 2 ? 2 : width - 0.5;
                            pitch.Meter_Readings__r[x].zIndex = x + 1;

                            if (pitch.Meter_Readings__r[x].Invoiced__c) {
                                pitch.Meter_Readings__r[x].Status__c = 'Billed';
                            } else if (pitch.Meter_Readings__r[x].Status__c == 'Converted') {
                                pitch.Meter_Readings__r[x].Status__c = 'Ready to bill'
                            }

                        }
                    }

                });

                content.Pitches.sort((a, b) => (a.Contract_Account_Number__c > b.Contract_Account_Number__c) ? 1 : -1);
            }
            $C.set('v.UtilityBillingSearch', '');
            $C.set('v.UtilityBillingFilter', '');
            $C.set('v.Utility', content.Pitches);
            $C.set('v.UtilityBillingLoaded', true);
            $C.set('v.UtilityBillingProcessing', false);

        });
        $A.enqueueAction(getUtilityBillingStatusApex);
    },
    getInsuranceWarmUpLetterData: function ($C) {
        $C.set('v.InsuranceDataProcessing', true);
        var getInsuranceWarmUpLetterDataApex = $C.get('c.getInsuranceWarmUpLetterDataApex');
        getInsuranceWarmUpLetterDataApex.setParams({ parks: $C.get('v.SelectedParks') });
        getInsuranceWarmUpLetterDataApex.setCallback(this, function (response) {
            // console.log('c.getInsuranceWarmUpLetterDataApex', response.getState(), response.getReturnValue());
            $C.set('v.InsuranceDataProcessing', false);
            var content = response.getReturnValue();
            var totalLength = content.Accounts.length;
            let selectableExpiryDates = new Set();
            let selectableTypes = new Set();

            content.Accounts.forEach(function (acc) {
                selectableExpiryDates.add(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                let accInvItemType = '';
                if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Caravan') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Width__c.toString() + 'ft'
                }
                else if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Chalet' || acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Lodge') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c.toString();
                }
                selectableTypes.add(accInvItemType);
            });
            let expDatesArr = [...selectableExpiryDates];
            let selectableTypesArr = [...selectableTypes];

            $C.set('v.Insurance', content.Accounts);
            $C.set("v.totalRecordsCount", totalLength);
            $C.set("v.selectedCount", 0);
            $C.set("v.SelectAllInsurance", false);
            $C.set('v.SelectableExpiryDates', expDatesArr);
            $C.set('v.SelectableTypes', selectableTypesArr);
            $C.set('v.InsuranceInfoLoaded', true);

        });
        $A.enqueueAction(getInsuranceWarmUpLetterDataApex);
    },
    getRenewalQuoteLetterData: function ($C) {
        console.log('parksList' + $C.get('c.getRenewalQuoteLetterDataApex'));
        $C.set('v.InsuranceDataProcessing', true);
        var getRenewalQuoteLetterDataApex = $C.get('c.getRenewalQuoteLetterDataApex');
        getRenewalQuoteLetterDataApex.setParams({ parks: $C.get('v.SelectedParks') });
        getRenewalQuoteLetterDataApex.setCallback(this, function (response) {
            // console.log('c.getRenewalQuoteLetterDataApex', response.getState(), response.getReturnValue());
            $C.set('v.InsuranceDataProcessing', false);
            var content = response.getReturnValue();
            var totalLength = content.Accounts.length;
            // let selectableExpiryDates = new Set();
            let selectableTypes = new Set();

            content.Accounts.forEach((acc) => {
                // selectableExpiryDates.add(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                let accInvItemType = ''
                if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Caravan') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Width__c.toString() + 'ft'
                }
                else if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Chalet' || acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Lodge') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c.toString();
                }
                selectableTypes.add(accInvItemType);
            });
            // let expDatesArr = [...selectableExpiryDates]
            let selectableTypesArr = [...selectableTypes]

            $C.set('v.Insurance', content.Accounts);
            $C.set("v.totalRecordsCount", totalLength);
            $C.set("v.selectedCount", 0);
            $C.set("v.SelectAllInsurance", false);
            // $C.set('v.SelectableExpiryDates', expDatesArr);
            $C.set('v.SelectableTypes', selectableTypesArr);
            $C.set('v.InsuranceInfoLoaded', true);
        });
        $A.enqueueAction(getRenewalQuoteLetterDataApex);
    },
    getLapsedLetterData: function ($C) {

        $C.set('v.InsuranceDataProcessing', true);
        var getLapsedLetterDataApex = $C.get('c.getLapsedLetterDataApex');
        getLapsedLetterDataApex.setParams({ parks: $C.get('v.SelectedParks') });
        getLapsedLetterDataApex.setCallback(this, function (response) {
            $C.set('v.InsuranceDataProcessing', false);
            var content = response.getReturnValue();
            var totalLength = content.Accounts.length;
            // let selectableExpiryDates = new Set();
            let selectableTypes = new Set();

            content.Accounts.forEach((acc) => {
                // selectableExpiryDates.add(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                let accInvItemType = ''
                if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Caravan') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Width__c.toString() + 'ft'
                }
                else if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Chalet' || acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Lodge') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c.toString();
                }
                selectableTypes.add(accInvItemType);
            });
            // let expDatesArr = [...selectableExpiryDates]
            let selectableTypesArr = [...selectableTypes]

            $C.set('v.Insurance', content.Accounts);
            $C.set("v.totalRecordsCount", totalLength);
            $C.set("v.selectedCount", 0);
            $C.set("v.SelectAllInsurance", false);
            // $C.set('v.SelectableExpiryDates', expDatesArr);
            $C.set('v.SelectableTypes', selectableTypesArr);
            $C.set('v.InsuranceInfoLoaded', true);
        });
        $A.enqueueAction(getLapsedLetterDataApex);
    },
    getReminderLetterData: function ($C, letterNum) {
        $C.set('v.InsuranceDataProcessing', true);
        var getReminderLetterDataApex = $C.get('c.getReminderLetterDataApex');
        getReminderLetterDataApex.setParams({ parks: $C.get('v.SelectedParks'), letterNum: letterNum });
        getReminderLetterDataApex.setCallback(this, function (response) {
            $C.set('v.InsuranceDataProcessing', false);
            var content = response.getReturnValue();
            var totalLength = content.Accounts.length;
            // let selectableExpiryDates = new Set();
            let selectableTypes = new Set();

            content.Accounts.forEach((acc) => {
                // selectableExpiryDates.add(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                let accInvItemType = ''
                if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Caravan') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Width__c.toString() + 'ft'
                }
                else if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Chalet' || acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Lodge') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c.toString();
                }
                selectableTypes.add(accInvItemType);
            });
            // let expDatesArr = [...selectableExpiryDates]
            let selectableTypesArr = [...selectableTypes]

            $C.set('v.Insurance', content.Accounts);
            $C.set("v.totalRecordsCount", totalLength);
            $C.set("v.selectedCount", 0);
            $C.set("v.SelectAllInsurance", false);
            // $C.set('v.SelectableExpiryDates', expDatesArr);
            $C.set('v.SelectableTypes', selectableTypesArr);
            $C.set('v.InsuranceInfoLoaded', true);
        });
        $A.enqueueAction(getReminderLetterDataApex);
    },
    getInsurancePolicyDefintions: function ($C) {

        var getInsurancePolicyDefintionsApex = $C.get('c.getInsurancePolicyDefintionsApex');
        getInsurancePolicyDefintionsApex.setCallback(this, function (response) {
            console.log('c.getInsurancePolicyDefintionsApex', response.getState(), response.getReturnValue());
            var content = response.getReturnValue();
            $C.set('v.InsurancePolicyDefinitions', content);

        });
        $A.enqueueAction(getInsurancePolicyDefintionsApex);
    },
    getParksInfo: function ($C) {
        var getParkssApex = $C.get('c.getParkssApex');
        getParkssApex.setParams({ recordId: $C.get('v.recordId') })
        getParkssApex.setCallback(this, function (response) {
            var content = response.getReturnValue();
            let numOfParks = content.length;
            $C.set('v.AllParks', content);
            $C.set('v.totalParksCount', numOfParks)
        });
        $A.enqueueAction(getParkssApex);
    },
    getPolicyDefIndex: function (insPolDefs, selectedUnit, basisOfCover, $H, startDate) {
        var insuranceCategory = '';
        if (selectedUnit.Type__c == 'Lodge') {
            insuranceCategory = 'Lodge';
        } else if (selectedUnit.Type__c == 'Chalet') {
            insuranceCategory = 'Chalet';
        } else {
            insuranceCategory = selectedUnit.Width__c + 'ft';
        }
        let age = selectedUnit.Age__c;
        console.log('age:    ' + age);

        var insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, selectedUnit.Location__r.Park_Company__r.Name,
            selectedUnit.Location__r.Name, basisOfCover, startDate, age);
        console.log('1');
        if (insPolDefIndex == -1) {
            insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, 'All Companies',
                selectedUnit.Location__r.Name, basisOfCover, startDate, age);
            console.log('2');
            if (insPolDefIndex == -1) {
                insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', selectedUnit.Location__r.Park_Company__r.Name,
                    selectedUnit.Location__r.Name, basisOfCover, startDate, age);
                console.log('3');
                if (insPolDefIndex == -1) {
                    insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', 'All Companies',
                        selectedUnit.Location__r.Name, basisOfCover, startDate, age);
                    console.log('4');
                    if (insPolDefIndex == -1) {
                        insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, selectedUnit.Location__r.Park_Company__r.Name,
                            'All Parks', basisOfCover, startDate, age);
                        console.log('5');
                        if (insPolDefIndex == -1) {
                        insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', selectedUnit.Location__r.Park_Company__r.Name,
                            'All Parks', basisOfCover, startDate, age);
                        console.log('5!');
                        if (insPolDefIndex == -1) {
                            insPolDefIndex = $H.getPolIndex(insPolDefs, insuranceCategory, 'All Companies',
                                'All Parks', basisOfCover, startDate, age);
                            console.log('6');
                            if (insPolDefIndex == -1) {
                                insPolDefIndex = $H.getPolIndex(insPolDefs, 'All', 'All Companies',
                                    'All Parks', basisOfCover, startDate, age);
                                console.log('7');
                            }
                        }
                        }
                    }
                }
            }
        }
        return insPolDefIndex;
    },
    getPolIndex: function (insPolDefs, insuranceCategory, parkCompany, parkName, basisOfCover, startDate, age) {
        if (basisOfCover == 'Market Value') {
            return insPolDefs.findIndex(polDef => polDef.Category__c === insuranceCategory
                && polDef.Company__c === parkCompany
                && polDef.Park__c === parkName
                && polDef.Basis_of_Cover__c === basisOfCover
                && new Date(polDef.Period_Charges_Applicable_To__c) >= startDate
                && new Date(polDef.Period_Charges_Applicable_From__c) <= startDate
                && polDef.Max_Unit_Age__c >= age
                && polDef.Minimum_Unit_Age__c <= age
            );
        }
        else return insPolDefs.findIndex(polDef => polDef.Category__c === insuranceCategory
            && polDef.Company__c === parkCompany && polDef.Park__c === parkName
            && polDef.Basis_of_Cover__c === basisOfCover
            && new Date(polDef.Period_Charges_Applicable_To__c) >= startDate
            && new Date(polDef.Period_Charges_Applicable_From__c) <= startDate
        );
    },
    getInsuranceDetails: function (selectedUnit, startDate, $C, $H) {
        var insPolDefs = $C.get('v.InsurancePolicyDefinitions');
        console.log("startDate in getInsuranceDetails: " + startDate);
        var newForOldIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'New For Old', $H, startDate);
        // console.log('newForOldIndex:' + newForOldIndex);

        // var newForOldInsProRataNetPrice = 0;
        // var newForOldContentProRataNetPrice = 0;
        // var alarmProRataNetPrice = 0;
        var newForOldId;
        var marketValueId;

        //New For Old - record found
        if (newForOldIndex != -1) {
            var insPolDef = insPolDefs[newForOldIndex];
            // console.log('insPolDef:' + JSON.stringify(insPolDef));
            // var insNumOfDays = ($H.getDays(selectedUnit.Presentation__r.CloseDate, insPolDef.Period_Charges_Applicable_To__c) + 1);
            // var insTotalNumOfDays = ($H.getDays(insPolDef.Period_Charges_Applicable_From__c, insPolDef.Period_Charges_Applicable_To__c) + 1);
            // newForOldInsProRataNetPrice = insNumOfDays * (insPolDef.Net_Selling_Price__c / insTotalNumOfDays);
            newForOldId = insPolDef.Id;
            // console.log('days differece: ' + ($H.getDays(insPolDef.Period_Charges_Applicable_From__c, insPolDef.Period_Charges_Applicable_To__c) + 1));

            // if (insPolDef.Add_On__c) {
            //     newForOldContentProRataNetPrice = insNumOfDays * (insPolDef.Add_On__r.Net_Selling_Price__c / insTotalNumOfDays);
            //     console.log(newForOldContentProRataNetPrice + ', New for old content price Finished');
            // }
            //Check the Alarm discount in PBE
            // console.log('alarm price starting');
            // var alarmPBE = $C.get('v.AlarmPBE');
            // if (alarmPBE) {
            //     var alarmIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'Alarm Discount', $H);
            //     if (alarmIndex != -1) {
            //         var alarmPolDef = insPolDefs[alarmIndex];
            //         console.log('alarmPolDef:' + JSON.stringify(alarmPolDef));
            //         alarmProRataNetPrice = insNumOfDays * (alarmPolDef.Net_Selling_Price__c / insTotalNumOfDays);
            //     }
            // }
        }
        var marketValueIndex = $H.getPolicyDefIndex(insPolDefs, selectedUnit, 'Market Value', $H, startDate);
        var marketValueInsProRataNetPrice = 0;
        var marketValueContentProRataNetPrice = 0;
        console.log('MV price starting');
        if (marketValueIndex != -1) {
            var insPolDef = insPolDefs[marketValueIndex];
            marketValueId = insPolDef.Id;
            // console.log('MV Pol Def:' + JSON.stringify(insPolDef));
            // var proRataNumOfDays = ($H.getDays(selectedUnit.Presentation__r.CloseDate, insPolDef.Period_Charges_Applicable_To__c) + 1);

            // var insTotalNumOfDays = ($H.getDays(insPolDef.Period_Charges_Applicable_From__c, insPolDef.Period_Charges_Applicable_To__c) + 1);
            // marketValueInsProRataNetPrice = proRataNumOfDays * (insPolDef.Net_Selling_Price__c / insTotalNumOfDays);
            // //Market Value Content Price 
            // console.log('MV content price starting');
            // if (insPolDef.Add_On__c) {
            //     marketValueContentProRataNetPrice = proRataNumOfDays * (insPolDef.Add_On__r.Net_Selling_Price__c / insTotalNumOfDays);
            // }
        }

        //Total Insurance Price
        // var totalInsPrice = newForOldInsProRataNetPrice + alarmProRataNetPrice;
        var insuranceDetails = {
            // NewForOldInsProRataNetPrice: newForOldInsProRataNetPrice,
            // AlarmProRataNetPrice: alarmProRataNetPrice,
            NewForOldId: newForOldId,
            MarketValueId: marketValueId,
            // TotalInsPrice: totalInsPrice,
            // NewForOldContentProRataNetPrice: newForOldContentProRataNetPrice,
            // MarketValueInsProRataNetPrice: marketValueInsProRataNetPrice,
            // MarketValueContentProRataNetPrice: marketValueContentProRataNetPrice
        };
        return insuranceDetails;
    },
    filterInsurance: function (expiryFrom, expiryTo, coverFilter, typeFilter, $C) {
        let insurance = $C.get('v.Insurance');
        let totalOfAccounts = 0;
        let totalSelected = 0;
        let expiryDatesSet = new Set();
        let typeSet = new Set();

        if (insurance.length) {
            insurance.forEach(function (acc) {
                let accBOC = acc.objAccount.Active_Insurance_Policy__r.Basis_Of_Cover_Type__c;
                let accExp = acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c;
                let accInvItemType = ''

                if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Caravan') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Width__c.toString() + 'ft'
                }
                else if (acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Chalet' || acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c == 'Lodge') {
                    accInvItemType = acc.objAccount.Holiday_Home__r.Holiday_Home__r.Type__c.toString();
                }

                //No filters- show all
                if (coverFilter == '' && !expiryTo && !expiryFrom && typeFilter == '') {
                    acc.isShown = true;
                }
                //No expiry/type filter set- just use cover filter
                else if (!expiryTo && !expiryFrom && typeFilter == '') {
                    if (accBOC == coverFilter) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No cover/type/expFrom filter set- just use expiryTo filter
                else if (coverFilter == '' && typeFilter == '' && !expiryFrom) {
                    if (accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No cover/type/expTo filter set- just use expiryFrom filter
                else if (coverFilter == '' && typeFilter == '' && !expiryTo) {
                    if (accExp >= expiryFrom) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No cover/expiry filter set- just use type filter
                else if (coverFilter == '' && !expiryTo && !expiryFrom) {
                    if (accInvItemType == typeFilter) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No expiry filters set- use cover & type filter
                else if (!expiryTo && !expiryFrom) {
                    if (accBOC == coverFilter && accInvItemType == typeFilter) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No type/expiryTo filters set- use cover & expiryfrom filter
                else if (typeFilter == '' && !expiryTo) {
                    if (accBOC == coverFilter && accExp >= expiryFrom) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }

                //No cover/expiryFrom filters set- use cover & expiryTo filter
                else if (coverFilter == '' && !expiryFrom) {
                    if (accInvItemType == typeFilter && accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No cover/expiryTo filters set- use cover & expiryFrom filter
                else if (coverFilter == '' && !expiryTo) {
                    if (accInvItemType == typeFilter && accExp >= expiryFrom) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No type/expiryFrom filters set- use cover & expiryTo filter
                else if (typeFilter == '' && !expiryFrom) {
                    if (accBOC == coverFilter && accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No type/cover filters set- use expiry filters
                else if (coverFilter == '' && typeFilter == '') {
                    if (accExp <= expiryTo && accExp >= expiryFrom) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No cover filter set- use type & expiry filter
                else if (coverFilter == '') {
                    if (accInvItemType == typeFilter && accExp >= expiryFrom && accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No type filter set- use cover & expiry filter
                else if (typeFilter == '') {
                    if (accBOC == coverFilter && accExp >= expiryFrom && accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No expTo filter set- use cover & type & expfrom
                else if (!expiryTo) {
                    if (accBOC == coverFilter && accInvItemType == typeFilter && accExp >= expiryFrom) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //No expFrom filter set- use cover & type & expTo
                else if (!expiryFrom) {
                    if (accBOC == coverFilter && accInvItemType == typeFilter && accExp <= expiryTo) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                //Use all filters
                else {
                    if (accExp >= expiryFrom && accExp <= expiryTo && accBOC == coverFilter && accInvItemType == typeFilter) {
                        acc.isShown = true;
                    }
                    else {
                        acc.isShown = false;
                        acc.isChecked = false
                    }
                }
                if (acc.isShown) {
                    totalOfAccounts++;
                    // expiryDatesSet.add(accExp);
                    // typeSet.add(accInvItemType);
                }
                if (acc.isChecked) totalSelected++;
            });
        }
        $C.set('v.Insurance', insurance);
        $C.set('v.totalRecordsCount', totalOfAccounts);
        $C.set('v.selectedCount', totalSelected);
        // $C.set('v.SelectableExpiryDates', [...expiryDatesSet])
        // $C.set('v.SelectableTypes', [...typeSet])

    },
    sendInsuranceDocs: function ($C, $E, $H) {
        let docToSend = $C.get("v.SelectedDocument");
        let allAccs = $C.get("v.Insurance");
        let accountsToSendTo = [];
        let nfoMap = {};
        let mvMap = {};

        allAccs.forEach(acc => {
            if (acc.isChecked) {
                if (docToSend == 'renewal-quote') {
                    let startDate = new Date(acc.objAccount.Active_Insurance_Policy__r.Policy_End_Date__c);
                    startDate.setDate(startDate.getDate() + 1);

                    let insuranceDetails = $H.getInsuranceDetails(acc.objAccount.Holiday_Home__r.Holiday_Home__r, startDate, $C, $H);
                    nfoMap[acc.objAccount.Id] = insuranceDetails.NewForOldId;
                    mvMap[acc.objAccount.Id] = insuranceDetails.MarketValueId;
                }
                accountsToSendTo.push(acc.objAccount);
            }
        })


        var createInsuranceDocsApex = $C.get('c.createInsuranceDocsApex');
        createInsuranceDocsApex.setParams({
            docType: docToSend, accounts: accountsToSendTo, mvMap: mvMap, nfoMap: nfoMap
        });
        createInsuranceDocsApex.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "type": "success",
                    "mode": "dismissable"
                });

                switch (docToSend) {
                    case 'warm-up':
                        toastEvent.setParams({
                            "message": "Warm Up Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getInsuranceWarmUpLetterData($C);
                        break;
                    case 'renewal-quote':
                        toastEvent.setParams({
                            "message": "Renewal Quote Letters sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getRenewalQuoteLetterData($C);
                        break;
                    case "reminder-1":
                        toastEvent.setParams({
                            "message": "1st Reminder Letter(s) sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getReminderLetterData($C, 1);
                        break;
                    case "lapsed-letter":
                        toastEvent.setParams({
                            "message": "Lapsed Insurance Letter(s) sent to " + accountsToSendTo.length + " account(s)",
                        });
                        $H.getReminderLetterData($C);
                        break;
                }
                toastEvent.fire();
            }
        });
        $A.enqueueAction(createInsuranceDocsApex);
    }
})