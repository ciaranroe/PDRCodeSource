({
    setNewPassword : function(component, event, helper) {
        
        component.set("v.error", "");   
        component.set("v.status", "Changing..");        
        component.set("v.valid", false);
        
        console.log('Old Paswd', component.get('v.oldPassword'));
        console.log('New Paswd',  component.get('v.newPassword'));
        console.log('Verify Paswd',  component.get('v.confirmNewPassword'));
        
        
            console.log('Password matched');            
            var action = component.get("c.resetPassword");
            
            action.setParams({
                "newPasswordValue": component.get('v.newPassword'),
                "verifyNewPassword": component.get('v.confirmNewPassword'),
                "oldPasswordValue": component.get('v.oldPassword')
            }); 
            
            action.setCallback(this, function(response) {
                
                var state = response.getState();
                
                console.log('STATE-------> ' + state);
                
                if(state === 'ERROR') {
                    console.log('Its an error', response.getError());
                    component.set("v.error", response.getError()[0].message);
                    component.set("v.status", "Failed!");
                }
                
                if (state === "SUCCESS") {
                    
                    
        			component.set("v.status", "Changed!");
                    component.set('v.error', "Password Changed!");
                    setTimeout(function() {
                      component.set('v.status', 'Change Password');
                      component.set('v.error', '');
                      component.set('v.newPassword', '');
                      component.set('v.oldPassword', '');
                      component.set('v.confirmNewPassword', '');
                    }, 2000);
                } 
            });
            
            $A.enqueueAction(action);
        
        
    },
    
    checkForm: function(component, event, helper) {
      component.set("v.status", 'Change Password');
      var errA = component.get('v.errA');
      var errB = component.get('v.errB');
      var errC = component.get('v.errC');
      if (errA == 'valid' && errB == 'valid' && errC == 'valid') {
        component.set('v.valid', true);  
      } else {
        component.set('v.valid', false);  
      }
    }
    
})