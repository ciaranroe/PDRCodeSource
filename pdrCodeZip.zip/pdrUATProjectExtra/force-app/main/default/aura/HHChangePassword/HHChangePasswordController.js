({
    
    doInit: function($C, $E, $H) {
      $C.set("v.status", 'Change Password');
      $C.set("v.pww", "0%");
      $C.set('v.newPassword', "");
      $C.set('v.error', "");
      $C.set('v.confirmNewPassword', "");
    },
    
    changePassword : function(component, event, helper) {
        // Invoke helper method to change the password
        helper.setNewPassword(component, event, helper); 
    },
    
    togglePassword1: function(component, event, helper) {
      var current = component.get("v.pwt1");
      component.set("v.pwt1", current == "password" ? "text" : "password");
    },
    togglePassword2: function(component, event, helper) {
      var current = component.get("v.pwt2");
      component.set("v.pwt2", current == "password" ? "text" : "password");
    },
    togglePassword3: function(component, event, helper) {
      var current = component.get("v.pwt3");
      component.set("v.pwt3", current == "password" ? "text" : "password");
    },
    
    checkOld: function(component, event, helper) {
      var text = component.get("v.oldPassword");
      component.set("v.errA", text.length == 0 ? "error" : 'valid');
      helper.checkForm(component, event, helper);
    },
    
    checkConfirm: function(component, event, helper) {
      var text = component.get("v.confirmNewPassword");
      var match = text == component.get("v.newPassword") && text != "";
      component.set("v.errC", match == true ? "valid" : "error");
      helper.checkForm(component, event, helper);
    },
    
    checkPassword: function(component, event, helper) {
        
        var text = component.get("v.newPassword");
        if (text.length == 0 && event.key != "Tab") {
          component.set("v.errB", "error");
          component.set("v.pwe", "You must enter a password");
        }
        if (text.length > 0) {
          var checkA = text.length >= 8; // min 8
          var checkB = /[a-z]{1,}/g.test(text) && /[A-Z]{1,}/g.test(text); // upper + lower
          var checkC = /[!?@£$%&*]/g.test(text);
          var checkD = /[0-9]/g.test(text);
          component.set("v.valA", checkA == true ? "passed" : "");
          component.set("v.valB", checkB == true ? "passed" : "");
          component.set("v.valC", checkC == true ? "passed" : "");
          component.set("v.valD", checkD == true ? "passed" : "");
          var width = 0;
          if (text.length <= 8) width += (text.length*8);
          if (text.length > 8) width += 64;
          if (checkB == true) width += 12;
          if (checkC == true) width += 12;
          if (checkD == true) width += 12;
          component.set("v.pww", width + "%");
          if (checkA == true && checkB == true && checkC == true && checkD == true) {
            component.set("v.errB", "valid");    
          } else {          
            component.set("v.errB", "error");
            component.set("v.pwe", "This password is not secure enough"); 
          }
        }  
      	helper.checkForm(component, event, helper);
        
    }
})