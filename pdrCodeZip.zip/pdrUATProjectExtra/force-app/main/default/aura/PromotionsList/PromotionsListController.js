({
    doInit : function($C, $E, $H) {

        var getPromotionsApex = $C.get('c.getPromotionsApex');
        getPromotionsApex.setParams({recordId : $C.get('v.recordId'), sObjectName : $C.get('v.sObjectName')});
        getPromotionsApex.setCallback(this, function(response){
            console.log('$C.get(c.getPromotionsApex)',response.getState(), response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                $C.set('v.Quote',response.getReturnValue());
            }
        });
        $A.enqueueAction(getPromotionsApex);

    }
})