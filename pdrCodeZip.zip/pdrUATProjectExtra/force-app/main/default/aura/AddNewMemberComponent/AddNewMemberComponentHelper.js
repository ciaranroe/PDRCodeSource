/**********************************************************************************************
	* @Author: Monali Nagpure
	* @Date: 08/09/2020        
    * @Description: JS helper file for Add Member details
	* @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
***********************************************************************************************/
({
    /**
    * Method Name : getAddressSuggestion
    * Parameters  : None
    * Description : get address from Google API's (Reused from NewLeadComponent) 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    getAddressSuggestion: function (component, event, helper) {
        var location = component.get('v.location');
        if (location && location.length > 3) {
            var params = {
                location: location
            };
            helper.callServer(
                component,
                'c.getAddressSuggestions',
                function (results) {
                    var response = JSON.parse(results);
                    if (response.hasError) {
                        this.showToast('Error', 'Somthing went wrong', 'error');
                    } else {
                        helper.handleAddressSuccess(component, event, helper, JSON.parse(response.message));
                    }
                },
                {
                    parameterString: JSON.stringify(params)
                }
            );
        }
        else {
            component.set('v.predictions', []);
        }
    },

    /**
    * Method Name : getLocationDetails
    * Parameters  : None
    * Description : get address from Google API's (Reused from NewLeadComponent) 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    getLocationDetails: function (component, event, helper) {
        component.set('v.city', '');
        component.set('v.postcode', '');
        component.set('v.street', '');
        component.set('v.locality', '');
        component.find('location').set('v.value', '');
        var selectedItem = event.currentTarget;
        var placeid = selectedItem.dataset.placeid;
        var params = {
            location: placeid
        };
        helper.callServer(
            component,
            'c.getLocationDetails',
            function (results) {
                var response = JSON.parse(results);
                if (response.hasError) {
                    this.showToast('Error', 'Somthing went wrong', 'error');
                } else {
                    helper.handleAddressDetailsSuccess(component, event, helper, JSON.parse(response.message));
                }
            },
            {
                parameterString: JSON.stringify(params)
            }
        );
    },

    /**
    * Method Name : handleAddressDetailsSuccess
    * Parameters  : None
    * Description : get address from Google API's (Reused from NewLeadComponent) 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    handleAddressDetailsSuccess: function (component, event, helper, placeDetails) {
        var streetConcatinate = '';
        var isCountryUK = false;

        for (var i = 0; i < placeDetails.result.address_components.length; i++) {
            if (placeDetails.result.address_components[i].types[0] == 'country') {
                if (placeDetails.result.address_components[i].long_name == 'United Kingdom' || placeDetails.result.address_components[i].long_name == 'UK') {
                    isCountryUK = true;
                }
            }
        }
        for (var i = 0; i < placeDetails.result.address_components.length; i++) {
            if (placeDetails.result.address_components[i].types[0] == 'street_number') {
                streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
            }
            if (placeDetails.result.address_components[i].types[0] == 'route') {
                streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
            }
            if (placeDetails.result.address_components[i].types[0] == 'country') {
                component.set('v.country', placeDetails.result.address_components[i].long_name);
            }
            if (placeDetails.result.address_components[i].types[0] == 'postal_code' || placeDetails.result.address_components[i].types[0] == 'postal_code_prefix') {
                component.set('v.postcode', placeDetails.result.address_components[i].long_name);
            }
            if (placeDetails.result.address_components[i].types[0] == 'postal_town') {
                component.set('v.city', placeDetails.result.address_components[i].long_name);
            }
            if (placeDetails.result.address_components[i].types[0] == 'administrative_area_level_1') {
                component.set('v.state', placeDetails.result.address_components[i].long_name);
            }
            if (placeDetails.result.address_components[i].types[0] == 'locality') {
                streetConcatinate += ' ' + placeDetails.result.address_components[i].long_name;
            } 
            //fill the below details only when the country is UK
            if (isCountryUK) {
                               
            }
        }
        if (streetConcatinate != null) {
            component.set('v.street', streetConcatinate);
        }
        component.set('v.predictions', []);
    },

    /**
    * Method Name : handleAddressSuccess
    * Parameters  : None
    * Description :  get address from Google API's (Reused from NewLeadComponent) 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    handleAddressSuccess: function (component, event, helper, response) {
        component.set('v.predictions', response.predictions);
    },

    /**
    * Method Name : saveMember
    * Parameters  : None
    * Description : Create new member and relate it to current opportunity
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    saveMember: function (component, event, helper, sourceButton) {

        component.set('v.ResponsePending',true);
        var salutation = component.find('salutation').get('v.value');
        var firstName = component.get('v.firstName');
        var lastName = component.get('v.lastName');
        var email = component.get('v.email');
        var street = component.get('v.street');
        var city = component.get('v.city');
        var state = component.get('v.state');
        var country = component.get('v.country');
        var nonUKResident = component.get('v.nonUKResident');
        var postcode = component.get('v.postcode');
        var phone = component.get('v.phone');
        var mobile = component.get('v.mobile');
        var recordId = component.get('v.recordId');
        var action = component.get('c.insertMember');
        action.setParams({
            salutation: salutation, firstName: firstName, lastName: lastName, email: email,
            street: street, city: city, state: state, country: country, postcode: postcode,
            phone: phone, mobile: mobile, oppId: recordId, isNonUK : nonUKResident
        });

        console.log('action.getParams()',nonUKResident);

        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            component.set('v.ResponsePending',false);
            console.log(response.getState(),response.getReturnValue());

            if (state === 'SUCCESS') {         
                if(response.getReturnValue() == 'true'){       
                    if (sourceButton == 'saveMember') {
                        // if clikced on "Save" then close quick action
                        $A.get('e.force:closeQuickAction').fire();
                    } else if (sourceButton == 'saveAndNewMember'){
                        // Firing event to let parent know "Save And New" button is clicked
                        var compEvents = component.getEvent('saveAndNewClicked');
                        compEvents.setParams({ 'saveAndNewClicked' : true });
                        compEvents.fire();
                    }
                    this.showToast('Success', 'Member Created', 'success');
                    $A.get('e.force:refreshView').fire();
                } else{
                    this.showToast('Error', response.getReturnValue(), 'error');
                }        

            } else if (state === 'ERROR') {
                this.showToast('Error', 'Somthing went wrong', 'error');
            }
        }));
        $A.enqueueAction(action);
    },

    /**
    * Method Name : showToast
    * Parameters  : None
    * Description : To show toast messages
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    showToast: function (title, message, type) {
        var toastEvent = $A.get('e.force:showToast');
        toastEvent.setParams({
            title: title,
            message: message,
            duration: ' 5000',
            key: 'info_alt',
            type: type,
            mode: 'dismissible'
        });
        toastEvent.fire();
    }

})