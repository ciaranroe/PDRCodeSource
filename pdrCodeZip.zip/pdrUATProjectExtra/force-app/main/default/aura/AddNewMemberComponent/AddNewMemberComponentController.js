/**********************************************************************************************
	* @Author: Monali Nagpure
	* @Date: 08/09/2020        
    * @Description: JS file for Add Member details
	* @Revision(s): [Date] - [Change Reference] - [Changed By] - [Description] 
***********************************************************************************************/
({
    /**
    * Method Name : init
    * Parameters  : None
    * Description : Disbale enable save button based on auto populated data 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    init: function (component, event, helper) {
        var firstName = component.get('v.firstName');
        var lastName = component.get('v.lastName');
        var mobile = component.get('v.mobile');
        var phone = component.get('v.phone');
        var email = component.get('v.email');
        var postcode = component.get('v.postcode');
        var country = component.get('v.country');
		
        console.log('Object Name::>>', component.get('v.objectName'));
        
        if(lastName) component.set('v.isLastNameDisabled',true);
        if(firstName) component.set('v.isFirstNameDisabled',true);
        if(mobile) component.set('v.isMobileDisabled',true);
        if(phone) component.set('v.isPhoneDisabled',true);
        if(email) component.set('v.isEmailDisabled',true);
        if(postcode) component.set('v.isPostcodeDisabled',true);
        
        if (lastName && (mobile || phone || email || postcode) && country) {
            component.set('v.isSaveButtonActive', false);

            console.log('setting false',lastName,mobile,phone,email ,postcode, country   );
        }else {
            component.set('v.isSaveButtonActive', true);
            console.log('setting true');
        }
    },

    /**
    * Method Name : disableOrEnableSaveButton
    * Parameters  : None
    * Description : Disbale enable save button based on details provided 
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    disableOrEnableSaveButton: function (component, event, helper) {
        var lastName = component.get('v.lastName');
        var mobile = component.get('v.mobile');
        var phone = component.get('v.phone');
        var email = component.get('v.email');
        var postcode = component.get('v.postcode');
        var country = component.get('v.country');

        if (lastName && (mobile || phone || email || postcode)  && country) {
            component.set('v.isSaveButtonActive', false);
            console.log('setting false',lastName,mobile,phone,email ,postcode, country );
        }
        else {
            component.set('v.isSaveButtonActive', true);
            console.log('setting true');
        }
    },

    /**
    * Method Name : getAddress
    * Parameters  : None
    * Description : get address from Google API's (Reused from NewLeadComponent)
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    getAddress: function (component, event, helper) {
        helper.getAddressSuggestion(component, event, helper);
    },

    /**
    * Method Name : getAddressDetails
    * Parameters  : None
    * Description : get address from Google API's (Reused from NewLeadComponent)
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    getAddressDetails: function (component, event, helper) {
        helper.getLocationDetails(component, event, helper);
    },

    /**
    * Method Name : closeModel
    * Parameters  : None
    * Description : To close Add member quick action
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    closeModel: function (component, event, helper) {
        $A.get('e.force:closeQuickAction').fire();
    },

    /**
    * Method Name : saveMember
    * Parameters  : None
    * Description : To save member details
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    saveMember: function (component, event, helper) {
        helper.saveMember(component, event, helper, 'saveMember');
    },

    /**
    * Method Name : saveAndNewMember
    * Parameters  : None
    * Description : To save member details and redirect to Search form
    * Created By  : Monali Nagpure
    * Created On  : 08/09/2020
    **/
    saveAndNewMember: function (component, event, helper) {
        helper.saveMember(component, event, helper, 'saveAndNewMember');
    }
})