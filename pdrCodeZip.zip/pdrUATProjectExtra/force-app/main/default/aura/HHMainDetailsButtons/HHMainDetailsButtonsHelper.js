({
    //get Reserve For Picklist Value
    getReserveForOptionsPicklist: function(component, event) {
        
        console.log('Inside getReserveForOptionsPicklist in Helper');
        
        var action = component.get("c.getReserveForOptions");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var reserveForMap = [];
                for(var key in result){
                    reserveForMap.push({key: key, value: result[key]});
                }
                component.set("v.reserveForMap", reserveForMap);
            }
        });
        $A.enqueueAction(action);
    },
    
    // Validate the other amount entered by user. Should be greater than 0 and less than the full amount
    validateOthrAmount: function(component, event, helper){
        
        console.log('Inside validateOthrAmount in Helper');
        
        var action = component.get("c.validateAmount");
        
        action.setParams({
            "amountVal": component.get("v.amount"),
            "accountId": component.get("v.accountId")
        }); 
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                
                var result = response.getReturnValue();
                console.log('result is : ', result);
                
                if(result == false) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": "Amount cannot exceed outstanding balace and should be greater than 0"
                    });
                    toastEvent.fire();
                }
            }  
        });
        $A.enqueueAction(action);
    },
    
    // Process payment from Verifone
    makePaymentHelper : function(component, event, helper) {
        
        console.log('Inside makePaymentHelper in Helper');
        var accountId = component.get('v.accountId'); 
        var otherAmountVal = component.get("v.amount");
        var amountValue ;
        var currentPageUrl = window.location.href; 
        var reserveForValue = component.get('v.selectedReserveForVal'); 
        
        console.log('selectedReserveFor in makePaymentHelper  : ', reserveForValue);
        
        console.log('current page url is ', currentPageUrl);
        
        if(otherAmountVal != null && otherAmountVal != 'undefined') {
            
            amountValue = otherAmountVal.toString();
            console.log('amountValue in other if is : ', otherAmountVal);
        } 
        else {
            console.log('amount is full : ', amount);
            amountValue = 'FullAmount';
        } 
        
        console.log('Final amount is : ', amountValue)
        var action = component.get("c.makePayment");
        
        action.setParams({
            "accountId": accountId,
            "amountStringVal": amountValue,
            "redirectUrl": currentPageUrl.toString(),
            "reserveForVal": reserveForValue
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state', state);
            if (state === "SUCCESS" ) {
                
                var responseData = response.getReturnValue();
                console.log('responseData :', responseData);
                console.log('Helper method for make payment invoke. In Success condition');
                
                // If API callout to Verifone is failed to process payment then show error message
                 if(responseData == null) {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": "Oops !! Error occurred. Information missing to process the payment. Contact your administrator. "
                    });
                    toastEvent.fire(); 
                }
                // Redirect to checkout URL if Verifone API Callout is successful
                else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "You will now be redirect to checkout page."
                    });
                    toastEvent.fire();
                    
                    // redirect to checkout URL after toast message
                    setTimeout(function() {window.open(responseData, "_blank");}, 3000);
                }
            }
        });
        $A.enqueueAction(action);
    }
})