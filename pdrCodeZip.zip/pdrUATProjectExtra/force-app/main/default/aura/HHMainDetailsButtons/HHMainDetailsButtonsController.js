({
    doInit : function(component, event, helper) {
        component.set("v.selectedReserveForVal", "--None--");
        console.log('Inside do init of Account Payment Component');
        helper.getReserveForOptionsPicklist(component, event);   
    },
    
    agreeToCashMatching: function(component, event) {
        var checkboxVal = component.find("checkbox");
        console.log("v.value", checkboxVal.get("v.value"));
        
    },
    
    reserveForChange : function(component, event, helper){ 
        var selectedOption = event.getSource().get("v.value");
        component.set("v.selectedReserveForVal", selectedOption);
        console.log('selectedReserveFor : ', selectedOption);
    },
    
    viewStatements: function(component, event, helper){
        
        console.log('Inside viewStatements');
        var accountId = component.get("v.recordId");
        
        component.set("v.acctId", accountId);
        
        console.log('accountId in viewStatements', accountId);
        
        var address = component.get("v.statementPageURL") + '?accountId=' + accountId;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isredirect" :false
        });
        urlEvent.fire();
    },
    
    handleMakePaymentClick : function(component, event, helper) {
        console.log('handleMakePaymentClick');
        var action = event.getSource();  
        var accId = component.get("v.recordId");
        
        component.set("v.accountId", accId);
        console.log('accountId in handleMakePaymentClick', accId);
        
        // Set isMainModalOpen attribute to true
        component.set("v.isMainModalOpen", true);
        
    },
    
    validateOtherAmount : function(component, event, helper) { 
        console.log('Inside validateOtherAmount of controller');
        helper.validateOthrAmount(component, event, helper);
    },
    
    closeAmountModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        /* component.set("v.isAmountModalOpen", false);
        component.set("v.otherAmountSelected", false); */
        console.log('Inside closeAmountModel of controller');
        component.set("v.amount", null);
        component.set("v.isMainModalOpen", false);
    },
    
    onAmountSelect: function(component, event, helper) {
        
        console.log('Inside onAmountSelect of controller');
        
        var changeValue = event.getParam("value");
        console.log('changeValue',changeValue);
        
        if(changeValue == 'other') {
            component.set("v.otherAmountSelected", true);
        }
        else {
            component.set("v.otherAmountSelected", false);
            component.set("v.amount", "FullAmount");
        }
    },
    
    submitAmountDetails: function(component, event, helper) {

        // Set isAmountModalOpen attribute to false
        console.log('Inside submitAmountDetails of controller');

        var selectedOption =  component.get('v.selectedReserveForVal'); 
        console.log('selectedReserveFor in submitAmountDetails  : ', selectedOption);
        
        var checkboxVal = component.find("checkbox");
        console.log("checkbox in submitAmountDetails  : ", checkboxVal.get("v.value"));
        
        if((selectedOption == null || selectedOption === '--None--') && checkboxVal.get("v.value") == false) {
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Warning",
                    "message": "Either reserve this payment or agree to apply cash matching rules."
                });
                toastEvent.fire();
            }
        else{
             component.set("v.isAmountModalOpen", false);
            helper.makePaymentHelper(component, event, helper);
        }

    }
})