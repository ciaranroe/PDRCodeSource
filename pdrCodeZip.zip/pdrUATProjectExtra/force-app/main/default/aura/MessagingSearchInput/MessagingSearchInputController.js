({
    doInit: function(component, event, helper) {
       component.set("v.isNewButtonMessage", false);            
       helper.getLeadDetails(component, event, helper);
       
    },
  searchRecords: function(component, event, helper) {
      component.set("v.isNewButtonMessage", false);
      helper.searchLeadRecords(component, event, helper);
   },
  checkSearchButton: function(component, event, helper) {
      component.set("v.isNewButtonMessage", false);
        helper.searchButton(component, event, helper);
    },
  hideUnhideSearch: function(component, event, helper) {
      component.set("v.isNewButtonMessage", false);
      helper.handleUtilityIcon(component, event, helper);
    },
  confirmNewLead: function(component, event, helper) {
        component.set("v.isNewButtonMessage", true);       
  },
  cancelNewLeadDialog: function(component, event, helper) {
        component.set("v.isNewButtonMessage", false);       
  },
  newLead: function(component, event, helper) {
        component.set("v.isNewButtonMessage", false);
        component.set("v.isActionFinished", true);            
      helper.createNewLead(component, event, helper); 
      component.set("v.isActionFinished", false);
  }
});