({
  searchButton: function(component, event, helper) {
    let lastName = component.get("v.lastName");
    let email = component.get("v.email");
    let postcode = component.get("v.postcode");
    let phone = component.get("v.phone");
    let mobile = component.get("v.mobile");
   // This is for search button
   if (lastName || email || phone || mobile || postcode) {
      component.set("v.isSearchButtonActive", false);
   	 } 
    else {
      component.set("v.isSearchButtonActive", true);
    }
    // This is for new button
     if (lastName && (email || phone || mobile || postcode)) {
        console.log('isNewButtonActive false');
      component.set("v.isNewButtonActive", false);
   	 } 
    else {
        console.log('isNewButtonActive true');
      	component.set("v.isNewButtonActive", true);
    }
  },
  searchLeadRecords:  function(component,event,helper){
     helper.setParams(component,event,helper);
     
     component.set("v.title", 'Lead Results');      
     component.set("v.divHeight", '5');
     var cmpTarget = component.find('leadSearchHideUnhide');
     $A.util.removeClass(cmpTarget, 'slds-visible');
     $A.util.addClass(cmpTarget, 'slds-hidden');
     var cardButton = component.find("cardButton");
     cardButton.set("v.iconName", "utility:up");
      console.log('params in msging:' + component.get("v.params"));
  },
  getLeadDetails:  function(component,event,helper){
      var params = {
           Id: component.get("v.recordId")
      };
      console.log('params:' + JSON.stringify(params)); 
      helper.callServer(
                  component,
                  "c.getLeadDetails",
                  function(result) {
                    var serverResult = JSON.parse(result);
                    if (serverResult.hasError) {//Error
                      console.log("Error: " + serverResult.message);
                      component.set("v.isActionFinished", false);
                      component.set("v.serverError", serverResult.message);
                    } else {//Success
						component.set("v.serverError", '');
                        component.set("v.isActionFinished", false);
                        console.log('params received:' + serverResult);                       
                        helper.handleLeadDetailsResult(component, event, helper, serverResult);
                    }
                  },
                  {
                    parameterString: JSON.stringify(params)
                  }
                  );
    },
  handleLeadDetailsResult: function(component, event, helper, result) {
     component.set("v.isResultLoaded",false);
	  component.set("v.firstName",result.firstName);
      component.set("v.lastName",result.lastName);
      component.set("v.email",result.email);
      component.set("v.postcode",result.postcode);
      component.set("v.phone",result.phone);
      component.set("v.mobile",result.mobile);
      helper.setParams(component, event, helper);
      console.log("params at handle lead details:" + component.get("v.params"));
      
      if (result.lastName && (result.email || result.phone || result.mobile)) {
          component.find("cardButton").set("v.iconName","utility:up")
          helper.whenUtilityDown(component, event, helper);
          component.set("v.isNewButtonActive", false);
      }
      else{
          component.find("cardButton").set("v.iconName","utility:down")
          helper.whenUtilityUp(component, event, helper);
      }
  },
   createNewLead:  function(component,event,helper){
       var params = {
          firstName: component.get("v.firstName"),
          lastName: component.get("v.lastName"),
          email: component.get("v.email"),          
          postcode: component.get("v.postcode"),
          phone: component.get("v.phone"),
          mobile: component.get("v.mobile"),
          sourceId: component.get("v.recordId")
       };
      console.log('params:' + JSON.stringify(params)); 
      helper.callServer(
                  component,
                  "c.createRecord",
                  function(result) {
                    var serverResult = JSON.parse(result);
                    if (serverResult.hasError) {//Error
                      console.log("Error: " + serverResult.message);
                      component.set("v.isActionFinished", false);
                      component.set("v.serverError", serverResult.message);
                    } else {//Success
						component.set("v.serverError", '');
                        component.set("v.isActionFinished", false);
                        console.log('lead id:' + serverResult.Id);                        
                        helper.handleNavigateRecord(component, event, helper, serverResult.Id);
                    }
                  },
                  {
                    parameterString: JSON.stringify(params)
                  }
                  );
    },
  handleNavigateRecord: function(component, event, helper, recordId) {
    component.set("v.isResultLoaded",false);
    var navigation = $A.get("e.force:navigateToSObject");
    navigation.setParams({
      recordId: recordId
    });
    navigation.fire();    
  },
  handleUtilityIcon: function(component, event, helper) {
       var currentButton = event.getSource(); 
       var iconName = currentButton.get('v.iconName');
	  
        if(iconName=='utility:up'){
            currentButton.set("v.iconName", "utility:down");
           helper.whenUtilityUp(component, event, helper);
        }
        else{
            	currentButton.set("v.iconName", "utility:up");
				helper.whenUtilityDown(component, event, helper);
        }       
  },
    whenUtilityUp:function(component, event, helper){
       component.set("v.divHeight", '400');
       var cmpTarget = component.find('leadSearchHideUnhide');
       $A.util.removeClass(cmpTarget, 'slds-hidden');
       $A.util.addClass(cmpTarget, 'slds-visible');   
    },
    whenUtilityDown: function(component, event, helper){
       component.set("v.divHeight", '5');
       var cmpTarget = component.find('leadSearchHideUnhide');
       $A.util.removeClass(cmpTarget, 'slds-visible');
       $A.util.addClass(cmpTarget, 'slds-hidden');   
    },
  setParams:function(component, event, helper){
      if(component.get("v.lastName")){                
          var params = {
          firstName: component.get("v.firstName"),
          lastName: component.get("v.lastName"),
          email: component.get("v.email"),
          postcode: component.get("v.postcode"),
          phone: component.get("v.phone"),
          mobile: component.get("v.mobile")
     	};
          component.set("v.params", JSON.stringify(params));
      }
      else{
          component.set("v.params", "");
      }
      
  }
});