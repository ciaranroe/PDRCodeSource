({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        console.log("PAGE URL -->" + sPageURL);
        var sURLVariables = sPageURL.split('&'); 
        console.log("URL VARIABLES -->" + sURLVariables);
        var sParameterName;
        var i;
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'memberMessageId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                //Store the parameter value
                component.set("v.memberMessageId", sParameterName[1]);
            }
            if(sParameterName[0] === 'mtmId'){
                component.set("v.msgToMemberId", sParameterName[1])
            }
        }
    },
    
    displayMemberMessage:function(component, event, helper){
        
        var memberMessageId = component.get('v.memberMessageId');
        
        var action = component.get("c.displayMemberMessageDetails");
        
        action.setParams({"memberMsgId": memberMessageId}); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                component.set("v.memberMessage", response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    tagAsViewedMessage:function(component, event, helper){
        var memberMessageId = component.get('v.msgToMemberId');
        var action = component.get("c.tagAsViewedMessage");
        
        console.log(memberMessageId);
        
        action.setParams({"messageId": memberMessageId}); 
        action.setCallback(this, function(response){
            
            var state = response.getState();
            console.log(state);
            console.log(response.getError());
            
            if(state == 'SUCCESS'){
                component.set("v.messageViewed", true);
            }
        });
        
        $A.enqueueAction(action)
    },
    
    attachedMessageToContentVersion:function(component, event, helper){
        var attachRecord = component.get("c.attachmentMessageMember");
        //var messageId =  component.get("v.memberMessageId");
        console.log('hello');
        attachRecord.setParams({
            recordId: component.get("v.memberMessageId")           
        });    
        attachRecord.setCallback(this, function(response) {     
            var state = response.getState();
            
            
            if(state === "SUCCESS") {
                component.set("v.messageFileId", response.getReturnValue()); 
                console.log('ContentDocumentId ---------------> ' + response.getReturnValue());
                /*  var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been attached successfully."
                });
                toastEvent.fire();*/
                this.downloadMessage(component, event, helper);
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log('error');
            }
        });
        
        //$A.get('e.force:refreshView').fire();
        $A.enqueueAction(attachRecord);  
        
    },
    
    //START PRINT PDF
    attachedMessageToContentVersion2:function(component, event, helper){
        
        var tempRecordId = component.get("v.memberMessageId");
        console.log('recordId: ' + tempRecordId); //check recordId
        var urlString = window.location.href;
        var communitybaseURL = urlString.substring(0,urlString.indexOf("/s"));
        console.log("communitybaseURL", communitybaseURL);
        var url = communitybaseURL + "/apex/MemberMessageDetailsExportToPDF?Id=" + tempRecordId;
        console.log('url is', url); //check url
        window.open(url, "_blank");
        
    },
    //END PRINT PDF
    
    downloadMessage:function(component, event, helper){
        var downloadRecord = component.get("c.downloadMessageMember");
        console.log('hello');
        downloadRecord.setParams({
            contentDocId: component.get("v.messageFileId")
        });
        downloadRecord.setCallback(this, function(response) {
            
            var state = response.getState();
            if(state === "SUCCESS") {
                var messageDL = response.getReturnValue();
                console.log('downloadFile: ', messageDL);
                messageDL.forEach(function(element, i){
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": element
                    });
                    urlEvent.fire();
                });   
                console.log(response.getReturnValue());
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been downloaded successfully."
                });
                toastEvent.fire();
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log('error');
            }        
        });
        $A.enqueueAction(downloadRecord);
    },
    
    printMessage:function(component, event, helper){
        
        var tempRecordId = component.get("v.memberMessageId");
        	console.log('recordId: ' + tempRecordId); //check recordId
        var urlString = window.location.href;
        var communitybaseURL = urlString.substring(0,urlString.indexOf("/s"));
        	console.log("communitybaseURL", communitybaseURL);
        var url = communitybaseURL + "/apex/MemberMessageDetailsPrint?Id=" + tempRecordId;
        console.log('url is', url); //check url
        window.open(url, "_blank");
        
    }
})