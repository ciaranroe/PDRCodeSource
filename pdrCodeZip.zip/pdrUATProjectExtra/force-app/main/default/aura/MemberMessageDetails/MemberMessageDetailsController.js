({
    doInit : function(component, event, helper)  {
        console.log("refresh");
        //helper.parsePageUrlParameter(component, event, helper);
        helper.displayMemberMessage(component, event, helper);
        helper.tagAsViewedMessage(component, event, helper);
        
    },
    
    confirmDeletion: function(component, event, helper) {
      component.set("v.confirmDelete", true);
    },
    
    cancelDelete: function(component, event, helper) {
      component.set("v.confirmDelete", false);
    },
    
    handleDelete : function(component, event, helper) {
        
        var deleteRecord = component.get("c.deleteMessageToMember");
        deleteRecord.setParams({
            recordId: component.get("v.msgToMemberId")
        });
        deleteRecord.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                window.location.reload();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/s/hh-member-message-page"
                });
                urlEvent.fire();
                
            } else if (state === "ERROR") {
                var errors = response.getError();
            }
        });
        
        $A.get('e.force:refreshView').fire();
        $A.enqueueAction(deleteRecord);
        
    },
    
    handlePrint: function(component, event, helper) {
        
        helper.printMessage(component, event, helper); 
        
    },
    
    handleDownload: function(component, event, helper){     
        //helper.attachedMessageToContentVersion(component, event, helper);   
        helper.attachedMessageToContentVersion2(component, event, helper); 
    }
})