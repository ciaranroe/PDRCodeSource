({
    getHHDetails : function(component, event, helper) {
        console.log('***!!!!***account Id ***** ' + component.get("v.recordId"));
        
        var action = component.get("c.getAcctDetails");
        action.setParams({
            "recordId":component.get("v.recordId")  
        });
        
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var acct = response.getReturnValue();
                	component.set("v.expiryDate", acct[0].Insurance_Expiry_Date__c);
                	component.set("v.isAboutToExpire", acct[0].IsInsuranceAboutToExpire__c);
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action);
    },
    
    
})