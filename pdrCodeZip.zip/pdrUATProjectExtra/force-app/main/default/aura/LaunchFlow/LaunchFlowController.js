({
    doInit : function (component, event, helper) {
        helper.getHHDetails(component, event, helper);
    },
    

    startFlow : function(component, event, helper){
        
        var flow = component.find("flowData");  
        
        component.set( "v.showModal", true );
        
        $A.createComponent(
            "lightning:flow",
            {
                "onstatuschange": component.getReference( "c.hideModal" )
            },
            
            ( flow, status, errorMessage ) => {
                if ( status === "SUCCESS" ) {
                component.set( "v.body", flow );
                component.set( "v.flow", flow );
                flow.startFlow("Account_Insurance_Details_Update");
            }
            }
        );
    }, 
    
    hideModal : function( component, event, helper ) {
        if ( event.getParam( "status" ).indexOf( "FINISHED" ) !== -1 ) {
            component.set( "v.showModal", false );
            component.get( "v.flow" ).destroy();
        }
    }
})