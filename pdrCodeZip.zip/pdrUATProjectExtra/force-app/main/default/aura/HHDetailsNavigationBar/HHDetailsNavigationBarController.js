({
	getRelatedAccounts : function(component, event, helper) {
        
    	var action = component.get("c.getRelatedAccountsList");
        var id
        var self = this;
        
        action.setCallback(this, function(actionResult) {
            
            var state = actionResult.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                
                component.set("v.acctList", actionResult.getReturnValue());
                
                var acctListSize = component.get("v.acctList");
                
                console.log('---------> ' + acctListSize.length);
                
                if(acctListSize.length == "1"){
                    console.log("view Single holiday home page");
                    helper.viewSingleHolidayHomePage(component, event, helper);  
                }else{
                    //component.set("v.viewHolidayHomeList", true);
                    console.log('**********MHH');
                    helper.viewMultipleHolidayHomePage(component, event, helper);
                }
            }   
        });
        
        $A.enqueueAction(action);
    },

    closeHHList : function(component, event, helper) {
        component.set("v.viewHolidayHomeList", false);
    },
    
    viewDocs : function(component, event, helper) {
        var accountId = component.get("v.recordId");
        
        component.set("v.acctId", accountId);
        
        var address = component.get("v.documentPageURL") + '?accountId=' + accountId;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isredirect" :false
        });
        urlEvent.fire();
    },
    /* component.set("v.viewDocList", true);
        component.set('v.columns', [
            {label: 'File Name', fieldName: 'linkName', type: 'url',
             typeAttributes: {label: { fieldName: 'Title' },value:{fieldName: 'linkName'}, target: '_self'}},
            {label: 'Type', fieldName: 'FileType', type: 'text'},
            {label: 'Created By', fieldName: 'CreatedBy.Name', type: 'text'},
            {label: 'File Size', fieldName: 'ContentSize', type: 'text'}]);
        
        var action = component.get("c.getRelatedFiles");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/ContentDocument/'+record.Id;
                });
                component.set('v.fileList', records);   
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action); */
    
    
    closeDocList : function(component, event, helper) {
        component.set("v.viewDocList", false);
    },
    
    uploadDocument: function(component, event, helper){
        var evt = $A.get("e.force:navigateToComponent");
        console.log('Event '+evt);
        var accountFromId = component.get("v.recordId");
        console.log(accountFromId);
        evt.setParams({
            componentDef  : "c:FileUpload" ,
            componentAttribute : {
                recordId : accountFromId
            }
        });
        console.log(evt);
        evt.fire();
    },
    
    viewOpenCases : function(component, event, helper) {
        component.set("v.viewCaseList", true);
        component.set('v.columns', [
            {label: 'Case Number', fieldName: 'linkName', type: 'url',
             typeAttributes: {label: { fieldName: 'CaseNumber' },value:{fieldName: 'linkName'}, target: '_self'}},
            {label: 'Subject', fieldName: 'Subject', type: 'text'},
            {label: 'Status', fieldName: 'Status', type: 'text'}]);  
        
        var action = component.get("c.getRelatedCaseList");
        action.setParams({
            recordId:component.get("v.recordId")  
        });
        
        action.setCallback(this, function (response) {
            
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/case/'+record.Id;
                });
                component.set('v.caseList', records);   
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action);
    },
    
    closeCaseList : function(component, event, helper) {
        component.set("v.viewCaseList", false);
    },
    
    viewStatements: function(component, event, helper){
        var accountId = component.get("v.recordId");
        
        component.set("v.acctId", accountId);
        
        var address = component.get("v.statementPageURL") + '?accountId=' + accountId;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": address,
            "isredirect" :false
        });
        urlEvent.fire();
    }
    
    
})