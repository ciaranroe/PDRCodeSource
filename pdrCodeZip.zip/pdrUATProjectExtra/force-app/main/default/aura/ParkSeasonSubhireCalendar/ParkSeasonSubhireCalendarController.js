({
    doInit : function($C, $E, $H) {

        console.log('init called');

        var getTemplateDatesApex = $C.get('c.getParkDatesApex');
        getTemplateDatesApex.setParams({ recordId : $C.get('v.recordId')});
        getTemplateDatesApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            $C.set('v.Changes',false);
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){

                var resMap = response.getReturnValue();
                if (resMap.Dates) {
                    $C.set('v.Dates',resMap.Dates);
                } 
                if (resMap.Season){
                    $C.set('v.Season',resMap.Season[0]);

                    if (resMap.Season[0].Past__c){
                        $C.set('v.IncludePastDates',true);
                    }
                }
            }
        });
        $A.enqueueAction(getTemplateDatesApex);

    },
    setSaveOption : function($C){
        $C.set('v.Changes',true);
    },
    cancel : function($C){
        $C.set('v.ResponsePending',true);
        $A.enqueueAction($C.get('c.doInit')); 
    }, 
    save : function($C){

        var dates = $C.get('v.Dates');

        var saveParkDatesApex = $C.get('c.saveParkDatesApex');
        saveParkDatesApex.setParams({ dates : dates});
        saveParkDatesApex.setCallback(this, function(response){
            $C.set('v.ResponsePending',false);
            $C.set('v.Changes',false);
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){

                if (response.getReturnValue() === 'success'){
                    $A.get('e.force:refreshView').fire();
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": "Template dates updated"
                    }).fire();
                } else {
                    $A.get("e.force:showToast").setParams({
                        "title": "Error!",
                        "type": "error",
                        "message": response.getReturnValue()
                    }).fire();
                }

            }
        });
        $A.enqueueAction(saveParkDatesApex);

    }

})