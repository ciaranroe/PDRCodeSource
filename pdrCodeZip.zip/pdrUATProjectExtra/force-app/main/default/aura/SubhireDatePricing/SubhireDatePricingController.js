({
    doInit : function($C, $E, $H) {

        var updatePricesApex = $C.get('c.updatePricesApex');
        updatePricesApex.setParams({ recordId : $C.get('v.recordId')});
        updatePricesApex.setCallback(this, function(response){
            console.log(response.getReturnValue());
            if (response.getState() === 'SUCCESS'){
                if (response.getReturnValue() === 'success'){
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "success",
                        "message": "Latest prices retrieved from Traveller."
                    }).fire();
                    $A.get('e.force:refreshView').fire();
                } else if (response.getReturnValue().startsWith('success')){
                    $A.get("e.force:showToast").setParams({
                        "title": "Success!",
                        "type": "warn",
                        "message": "Unit missing Traveller grade"
                    }).fire();
                } else {
                    $A.get("e.force:showToast").setParams({
                        "title": "Error!",
                        "type": "error",
                        "message": response.getReturnValue()
                    }).fire();
                }
            }
        });
        $A.enqueueAction(updatePricesApex);
    }
})