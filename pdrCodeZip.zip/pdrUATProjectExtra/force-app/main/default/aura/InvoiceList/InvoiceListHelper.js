({
    parsePageUrlParameter: function(component, event, helper){
        //Get the decoded statement page url
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;
        
        
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
            
            if (sParameterName[0] === 'accountId') { 
                sParameterName[1] === undefined ? 'Not found' : sParameterName[1];
                
                //Store the parameter value
                component.set("v.accountId", sParameterName[1]);
            }
        }
    },
    
    loadOutstandingInvoice: function(component, event, helper){
        var accountId = component.get('v.accountId');
        
        var action = component.get("c.getRelatedInvoiceList");
        
        action.setParams({"accountId": accountId}); 
        
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state == 'SUCCESS') {
                component.set("v.invoiceList", response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action); 
    },
    
    validateOthrAmount: function(component, event, helper){
        
        var action = component.get("c.validateAmount");
        
        action.setParams({
            "amountVal": component.get("v.amount"),
            "invoiceId": component.get("v.invoiceId")
        }); 
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                
                var result = response.getReturnValue();
                console.log('result is : ', result);
                
                if(result == false) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "message": "Amount cannot exceed outstanding balace and should be greater than 0"
                    });
                    toastEvent.fire();
                }
            }  
        });
        $A.enqueueAction(action);
    },
    
    makePaymentHelper : function(component, event, helper) {
        
        var accountId = component.get('v.accountId'); 
        var invoiceId = component.get('v.invoiceId');  
        var otherAmountVal = component.get("v.amount");
        var amountValue ;
        var currentPageUrl = window.location.href; 
        
        console.log('current page url is ', currentPageUrl);
        
        console.log('invoiceId in makePAyment is : ' , invoiceId);
        
        if(otherAmountVal != null && otherAmountVal != 'undefined') {
      
            amountValue = otherAmountVal.toString();
            console.log('amountValue in other if is : ', otherAmountVal);
        } 
        else {
            console.log('amount is full : ', amount);
            amountValue = 'FullAmount';
        } 
        
        console.log('Final amount is : ', amountValue)
        var action = component.get("c.makePayment");
        
        action.setParams({
            "accountId": accountId,
            "invoiceId": invoiceId,
            "amountStringVal": amountValue,
            "redirectUrl": currentPageUrl.toString()
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS" ) {
                
                var responseData = response.getReturnValue();
                console.log('responseData :', responseData);
                console.log('Helper method for make payment invoke. In Success condition');
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "You will now be redirect to checkout page."
                });
                toastEvent.fire();
                
                // redirect to checkout URL after toast message
                setTimeout(function() {window.open(responseData, "_blank");}, 3000);
            }
        });
        $A.enqueueAction(action);
    }
})