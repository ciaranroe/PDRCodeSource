({
    doInit : function(component, event, helper) {
        helper.parsePageUrlParameter(component, event, helper);
        helper.loadOutstandingInvoice(component, event, helper);
    },
    
    handlePayClick : function(component, event, helper) {
        
        var action = event.getSource();  
        var invoiceId = action.get("v.value");
        component.set("v.invoiceId", invoiceId);
        
        switch (action.get("v.name")) {
            case 'Pay':
                console.log('Inside switch case');
                // Set isModalOpen attribute to true
                component.set("v.isAmountModalOpen", true);
                break; 
        }
    },
    
    validateOtherAmount : function(component, event, helper) { 
        helper.validateOthrAmount(component, event, helper);
    },
    
    closeAmountModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isAmountModalOpen", false);
        component.set("v.otherAmountSelected", false);
        component.set("v.amount", null);
    },
    
    onAmountSelect: function(component, event, helper) {
        
        var changeValue = event.getParam("value");
        console.log('changeValue',changeValue);
        
        if(changeValue == 'other') {
            component.set("v.otherAmountSelected", true);
        }
        else {
            component.set("v.otherAmountSelected", false);
            component.set("v.amount", "FullAmount");
        }
    },
    
    submitAmountDetails: function(component, event, helper) {
        // Set isAmountModalOpen attribute to false
        component.set("v.isAmountModalOpen", false);
        helper.makePaymentHelper(component, event, helper);
    }
})