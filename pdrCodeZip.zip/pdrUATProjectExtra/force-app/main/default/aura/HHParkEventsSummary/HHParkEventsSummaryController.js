({
    
  doInit: function($C, $E, $H) {
        
    var action = $C.get("c.getAcctDetails");
    var accountId = window.location.search.split('?accountId=')[1];
    action.setParams({ recordId: accountId });
    action.setCallback(this, function (response) {
      var result = response.getReturnValue();
      var account = result[0];
      console.log(account);
      $C.set("v.calenderLink", account.Location__r.Owner_Event_Calender__c == undefined ? '' : account.Location__r.Owner_Event_Calender__c);
      $C.set("v.newsletterLink", account.Location__r.Owner_Newsletter__c == undefined ? '' : account.Location__r.Owner_Newsletter__c);
      $C.set("v.minutesLink", account.Location__r.Owner_Minutes__c == undefined ? '' : account.Location__r.Owner_Minutes__c);
      $C.set("v.feedbackLink", "https://parkdeanresortsowners.customersure.com/survey/RoeAWjCPBIjH-ZJHtYd_/completion/new");
    });
    $A.enqueueAction(action); 
      
  },
    
  openCalender: function($C, $E, $H) { window.open($C.get("v.calenderLink")); },
  openNewsletter: function($C, $E, $H) { window.open($C.get("v.newsletterLink")); },
  openMinutes: function($C, $E, $H) { window.open($C.get("v.minutesLink")); },  
  openFeedback: function($C, $E, $H) { window.open($C.get("v.feedbackLink")); },
    
})