({
    hRefreshAddButton : function(component, amount) {
        var memberConsented = component.get("v.MemberConsented");
        var reserveForSpecificInvoiceType = component.get("v.ReserveForSpecificInvoiceType");
        var amountCmp = component.find("amount");
    
        if(memberConsented || reserveForSpecificInvoiceType){
            component.find("amount").set("v.disabled", false);

            if(reserveForSpecificInvoiceType){
                component.find("typeOption").set("v.disabled", false);
            }else{
                component.find("typeOption").set("v.disabled", true);
            }
            
            if (amount < 0 || amount == "") {
                component.set("v.amount", '£ 0.00');
            /*} else if () {
                amount = 0;*/
            } else if (amount > 0 && amountCmp.get("v.validity").valid) {
                component.find("addButton").set("v.disabled", false);
            }
            
            if (amount <= 0 || !amountCmp.get("v.validity").valid) {
                component.find("addButton").set("v.disabled", true);
            }
        } else {
            component.find("amount").set("v.disabled", true);
        }
        
        /*
        if (!memberConsented) {
            component.find("typeOption").set("v.disabled", true);
            component.find("addButton").set("v.disabled", true);
            component.find("amount").set("v.disabled", true);
            component.find("ReserveForSpecificInvoiceType").set("v.disabled", true);
        } else {
            component.find("amount").set("v.disabled", false);
            component.find("ReserveForSpecificInvoiceType").set("v.disabled", false);
            if (reserveForSpecificInvoiceType) {
                component.find("typeOption").set("v.disabled", false);
            } else {
                component.find("typeOption").set("v.disabled", true);
            }

            if (amount != "" && amount < 0) {
                component.set("v.amount", 0);
            }
            if (amount == "" || amount <= 0) {
                amount = 0;
            }
            if (memberConsented && amount > 0 && amountCmp.get("v.validity").valid) {
                component.find("addButton").set("v.disabled", false);
            } else if (!memberConsented || amount <= 0 || !amountCmp.get("v.validity").valid) {
                component.find("addButton").set("v.disabled", true);
            }
        }*/
    },

})