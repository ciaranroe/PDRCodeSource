({
    init : function(component, event, helper) {
        component.set("v.MemberName", component.find("sharedMethods").getFullName(component.get("v.FirstName"), component.get("v.LastName"))); 

        var paymentOnAccountColumnsDefinition = [{
            label: "Remove", 
            type: "button", 
            initialWidth: 100, 
            typeAttributes: { 
                label: "Remove",
                title: "Remove",
                name: "remove_line",
                iconName: "utility:close",
            } 
        }, {
            label: "Type",
            fieldName: "InvoiceType",
            type: "text",
            sortable: false,
            hideDefaultActions: true
        }, {
            label: "Reserved",
            fieldName: "reserved",
            type: "text",
            sortable: false,
            hideDefaultActions: true
        }, {
            label: "Amount",
            fieldName: "pay_amount",
            type: 'currency',
            typeAttributes: { currencyCode: 'GBP'},
            sortable: false,
            hideDefaultActions: true
        }];

        component.set("v.paymentOnAccountColumnsDefinition", paymentOnAccountColumnsDefinition);
        component.set("v.paymentOnAccountData", []);

        component.find("sharedMethods").getTypeValues();
    },
    loadTypePicklist : function(component, event, helper) {
        var dataSetName = event.getParam("key");
        var type = event.getParam("type");
        var data = event.getParam("data");

        if (type === "setData" && dataSetName === "typePicklist") {
            if (data.length > 0) {
                component.set("v.typeOptions", data);
                component.set("v.typeOption", data[0].APIName);
            } else {
                component.set("v.typeOptions", []);
                component.set("v.typeOption", "");
            }
        }
    },
    closeWindow : function(component, event, helper) {
        component.find("sharedMethods").closeWindow();
    },
    changedAmount : function(component, event, helper) {
        helper.hRefreshAddButton(component, event.getParam("value"));
    },
    refreshAddButton : function(component, event, helper) {
        helper.hRefreshAddButton(component, component.get("v.amount"));
    },
    setNewAmount : function(component) {
        component.set("v.amount", '£ 0.00');
    },
    falseReserveForSpecificInvoiceType : function(component){
        if (component.get("v.MemberConsented")){
            component.set("v.ReserveForSpecificInvoiceType", false);
            component.set("v.amount", '£ 0.00');
        }
    },
    falseMemberConsented: function(component){
        if (component.get("v.ReserveForSpecificInvoiceType")){
            component.set("v.MemberConsented", false);
            component.set("v.amount", '£ 0.00');
        }
    },
    addLine : function(component, event, helper) {
        var paymentOnAccountData = component.get("v.paymentOnAccountData");

        var invType = (component.get("v.ReserveForSpecificInvoiceType")?component.get("v.typeOption"):"");
        var existingTypeUsed = false;
        for (var i = 0; i < paymentOnAccountData.length; i++) {
            if (paymentOnAccountData[i].InvoiceType == invType) {
                existingTypeUsed = true;
                alert("Change invoice type or remove old line with type: " + invType); 
                break;
            }
        }

        if (!existingTypeUsed) {
            paymentOnAccountData.push({
                InvoiceType: (component.get("v.ReserveForSpecificInvoiceType")?component.get("v.typeOption"):""),
                pay_amount: parseFloat(component.get("v.amount")),
                reserved : (component.get("v.ReserveForSpecificInvoiceType")?"Yes":"")
            });
        }

        component.set("v.paymentOnAccountData", paymentOnAccountData);
        component.set("v.amount", 0);

        var TotalPayment = 0;
        for (var i = 0; i < paymentOnAccountData.length; i++) {
            TotalPayment += parseFloat(paymentOnAccountData[i].pay_amount);
        }
        component.set("v.TotalPayment", TotalPayment);

        if (TotalPayment > 0) {
            component.find("startPaymentButton").set("v.disabled", false);
        } else {
            component.find("startPaymentButton").set("v.disabled", true);
        }
    },
    removeLine : function(component, event, helper) {
        var actionName = event.getParam("action").name;
        var idNumber = event.getParam("row").id;
        var selectedRowNumber = -1;

        var paymentOnAccountData = component.get("v.paymentOnAccountData");

        if (actionName == "remove_line") {
            for (var i = 0; i < paymentOnAccountData.length; i++) {
                if (paymentOnAccountData[i].id == idNumber) {
                    selectedRowNumber = i;
                    break;
                }
            }

            if (selectedRowNumber == -1) { return; }

            paymentOnAccountData.splice(selectedRowNumber, 1);

            component.set("v.paymentOnAccountData", paymentOnAccountData);

            var TotalPayment = 0;
            for (var i = 0; i < paymentOnAccountData.length; i++) {
                TotalPayment += parseFloat(paymentOnAccountData[i].pay_amount);
            }
            component.set("v.TotalPayment", TotalPayment);

            if (TotalPayment > 0) {
                component.find("startPaymentButton").set("v.disabled", false);
            } else {
                component.find("startPaymentButton").set("v.disabled", true);
            }
        }
    },
    nextWindow : function(component, event, helper) {
        var paymentOnAccountData = component.get("v.paymentOnAccountData");
        var paymentLines = [];

        for (var i = 0; i < paymentOnAccountData.length; i++) {
            paymentLines.push({
                "invoiceName":"",
                "invoiceType":paymentOnAccountData[i].InvoiceType,
                "amount": parseFloat(paymentOnAccountData[i].pay_amount),
                "invoiceId" : ""
            });
        }

        var paymentData = {
            "contractId": component.get("v.recordId"),
            "memberId": component.get("v.AccountId"),
            "contractName": component.get("v.AccountName"),
            "totalAmount": parseFloat(component.get("v.TotalPayment")),
            "firstName":component.get("v.FirstName"),
            "lastName":component.get("v.LastName"),
            "street":component.get("v.Street"),
            "city":component.get("v.City"),
            "country":component.get("v.Country"),
            "postalCode":component.get("v.PostalCode"),
            "phone":component.get("v.Phone"),
            "email":component.get("v.Email"),
            "paymentLines":paymentLines
        };

        var eventParameters = { "paymentData": paymentData };
        component.find("sharedMethods").openWindow("PaymentRunStatusWindow", eventParameters);
    },
    previousWindow : function(component, event, helper) {
        var eventParameters = {
            "recordId":component.get("v.recordId"),
            "AccountName":component.get("v.AccountName"),
            "Members":component.get("v.Members"),
            "AccountId":component.get("v.AccountId"),
            "FirstName":component.get("v.FirstName"),
            "LastName":component.get("v.LastName"),
            "Street":component.get("v.Street"),
            "City":component.get("v.City"),
            "Country":component.get("v.Country"),
            "PostalCode":component.get("v.PostalCode"),
            "Phone":component.get("v.Phone"),
            "Email":component.get("v.Email"),
            "thirdPartyPayee":component.get("v.thirdPartyPayee"),
            "paymentOption":"PaymentAccount"
        };
        component.find("sharedMethods").openWindow("PaymentCardholderInformation", eventParameters);
    }
})