({
	callServer : function(component, method, callback, params) {
		
        var action = component.get(method);
        
        if (params) {
            action.setParams(params);
        }
        
        action.setCallback(this, function(response) {
        	var state = response.getState();
            
            if (state === "SUCCESS") {
                callback.call(this, response.getReturnValue());
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                
                if (errors) {
                    errors.forEach(function(error) {
                        console.log(error);
                    })
                }
                else {
                    console.log("Unknown Error");
                }
            }
        });
        
        $A.enqueueAction(action);
	}
})