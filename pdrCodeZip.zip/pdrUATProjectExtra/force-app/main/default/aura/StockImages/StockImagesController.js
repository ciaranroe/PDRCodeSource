({
    doInit : function($C, $E, $H) {

        var getStockImagesApex = $C.get('c.getStockImagesApex');
        getStockImagesApex.setParams({ recordId : $C.get('v.recordId'), sObjectName : $C.get('v.sObjectName')});
        getStockImagesApex.setCallback(this, function(response){
            console.log('c.getStockImagesApex',response.getState(),response.getReturnValue());

            if (response.getState() === 'SUCCESS'){

                $C.set('v.Images',response.getReturnValue());
                $C.set('v.ActiveIndex',0);
            }

        });
        $A.enqueueAction(getStockImagesApex);

    }, 
    plusSlides : function($C, $E, $H) {

        console.log('increase index');
        var activeIndex = $C.get('v.ActiveIndex');
        $C.set('v.ActiveIndex',activeIndex +1);

    },
    minusSlides : function($C, $E, $H) {

        console.log('decrese index');
        var activeIndex = $C.get('v.ActiveIndex');
        $C.set('v.ActiveIndex',activeIndex -1);
    },
    currentSlide : function($C, $E, $H) {

        console.log('index',$E.currentTarget.dataset.index);
        $C.set('v.ActiveIndex',parseInt($E.currentTarget.dataset.index));
    }
})